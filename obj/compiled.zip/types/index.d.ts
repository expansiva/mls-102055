declare module "_102027_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102027_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102027_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function getLocalProjectDependencies(): number[];
    export function setLocalProjectDependencies(dependencies: number[]): void;
    export function deleteLocalProject(): Promise<void>;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function isStorContentEqualTemplateDefault(storFile: mls.stor.IFileInfo): Promise<boolean>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): Promise<void>;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/designSystemBase" {
    import { removeTokensFromSource, type IDesignSystemTokens } from '_102029_/l2/designSystemBase';
    export { removeTokensFromSource, type IDesignSystemTokens };
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
}
declare module "_102055_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102027_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102055_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102055_/l2/molecules/groupenterboolean/ml-toggle-switch-glass" {
    import { ToggleSwitchMolecule } from '_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    export class ToggleSwitchGlass extends ToggleSwitchMolecule {
        private gMsg;
        private gUid;
        private get internals();
        private glassLabel;
        private glassHelper;
        private glassError;
        private glassTrackClasses;
        private glassThumbClasses;
        private glassViewMode;
        render(): any;
    }
}
declare module "_102055_/l2/molecules/groupenterboolean/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102055_/l2/molecules/groupenterboolean/ml-toggle-switch-glass";
    export class GroupEnterBooleanIndex extends StateLitElement {
        private notif;
        private news;
        render(): TemplateResult;
    }
}
declare module "_102055_/l2/molecules/groupenterboolean/ml-toggle-switch-glass.defs" {
    export const group = "groupEnterBoolean";
    export const skill = "# Metadata\n- TagName: groupenterboolean--ml-toggle-switch-glass\n\n# Objective\nA boolean toggle switch in the Glassmorphism model. Same contract/logic as groupenterboolean--ml-toggle-switch (mls-102040): it inherits that component and overrides only the appearance.\n\n# Responsibilities\n- Toggle a boolean value via click/Enter/Space; expose role=\"switch\" with aria-checked.\n- Dispatch change/focus/blur with { value }; render label, helper or error; provide a read-only Yes/No view.\n\n# Constraints\n- No changes while disabled or not editing.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102055). Implemented by inheritance from mls-102040 (override of render() only); appearance lives in the .less scoped to the -glass tag. Translucent track; \"on\" state in indigo accent. Assumes a rich/dark background (container contract).";
}
declare module "_102055_/l2/molecules/groupenterdate/ml-date-picker-glass" {
    import { TemplateResult } from 'lit';
    import { MlDatePickerMolecule } from '_102040_/l2/molecules/groupenterdate/ml-date-picker';
    export class MlDatePickerGlass extends MlDatePickerMolecule {
        protected portalClassName: string;
        private gMsg;
        private gFieldId;
        private get x();
        private fmtDate;
        private getTriggerText;
        private glassTriggerClasses;
        private glassDayClasses;
        private glassLabel;
        private glassHelperOrError;
        protected getPortalTemplate(): TemplateResult;
        render(): any;
    }
}
declare module "_102055_/l2/molecules/groupenterdate/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102055_/l2/molecules/groupenterdate/ml-date-picker-glass";
    export class GroupEnterDateIndex extends StateLitElement {
        private date;
        render(): TemplateResult;
    }
}
declare module "_102055_/l2/molecules/groupenterdate/ml-date-picker-glass.defs" {
    export const group = "groupEnterDate";
    export const skill = "# Metadata\n- TagName: groupenterdate--ml-date-picker-glass\n\n# Objective\nA date picker in the Glassmorphism model. Same contract/logic as groupenterdate--ml-date-picker (mls-102040): it inherits that component and overrides only the appearance (trigger + popover calendar).\n\n# Responsibilities\n- Open a popover calendar; navigate months respecting min/max; select a day; clear; close on outside click.\n- Dispatch change ({ value }), monthChange ({ year, month }), focus and blur; keep a hidden input for forms.\n- Format the trigger/view via Intl.DateTimeFormat; mark today and the selected day.\n\n# Constraints\n- Dates outside min/max are disabled; no changes while disabled, readonly or loading.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102055). Implemented by inheritance from mls-102040 (override of render() only; date math, navigation, range and outside-click are inherited). Appearance lives in the .less scoped to the -glass tag; calendar popover uses rgba(30,27,75,0.85) + blur(18px). Assumes a rich/dark background (container contract).";
}
declare module "_102055_/l2/molecules/groupenterdatetime/ml-datetime-picker-glass" {
    import { TemplateResult } from 'lit';
    import { MlDatetimePickerMolecule } from '_102040_/l2/molecules/groupenterdatetime/ml-datetime-picker';
    export class DatetimePickerGlass extends MlDatetimePickerMolecule {
        protected portalClassName: string;
        private gMsg;
        private get x();
        private glassFormatDisplay;
        private glassTriggerClasses;
        private glassLabelClasses;
        private glassDayClasses;
        private glassTimeClasses;
        private glassLabel;
        private glassHiddenInput;
        private glassHelperOrError;
        private glassTrigger;
        private glassCalendar;
        private glassTime;
        protected getPortalTemplate(): TemplateResult;
        render(): any;
    }
}
declare module "_102055_/l2/molecules/groupenterdatetime/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102055_/l2/molecules/groupenterdatetime/ml-datetime-picker-glass";
    export class GroupEnterDatetimeIndex extends StateLitElement {
        private dt;
        render(): TemplateResult;
    }
}
declare module "_102055_/l2/molecules/groupenterdatetime/ml-datetime-picker-glass.defs" {
    export const group = "groupEnterDatetime";
    export const skill = "# Metadata\n- TagName: groupenterdatetime--ml-datetime-picker-glass\n\n# Objective\nA glassmorphism datetime picker built by INHERITANCE: extends MlDatetimePickerMolecule (mls-102040) and overrides only render() with translucent/glass markup. All business logic (ISO parsing, month navigation, day/hour/minute selection, min/max bounds, minute step, confirm/clear, outside-click) is inherited. The value is an ISO datetime string (YYYY-MM-DDTHH:mm:ss).\n\n# Responsibilities\n- Reuse the inherited popover flow: select a day, then an hour and minute; confirm to commit.\n- Render the trigger, calendar, time columns and actions with glass classes.\n- Format the trigger/view locally via Intl.DateTimeFormat (own i18n map).\n\n# Constraints\n- Logic is NOT reimplemented; only the visual layer (render + glass class helpers) is overridden.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism by inheritance (mls-102055, parent mls-102040). Translucent trigger; popover uses rgba(30,27,75,0.85) + blur(18px); selected day/time in indigo; confirm button is a solid indigo accent. Assumes a rich/dark background (container contract).";
}
declare module "_102055_/l2/molecules/groupentermoney/ml-currency-input-glass" {
    import { GroupEnterMoneyMlCurrencyInputMolecule } from '_102040_/l2/molecules/groupentermoney/ml-currency-input';
    export class CurrencyInputGlass extends GroupEnterMoneyMlCurrencyInputMolecule {
        private gMsg;
        private gUid;
        private get x();
        private glassInputClasses;
        private glassContainerClasses;
        private glassLabel;
        private glassHelperOrError;
        private glassInput;
        private glassViewMode;
        render(): any;
    }
}
declare module "_102055_/l2/molecules/groupentermoney/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102055_/l2/molecules/groupentermoney/ml-currency-input-glass";
    export class GroupEnterMoneyIndex extends StateLitElement {
        private price;
        render(): TemplateResult;
    }
}
declare module "_102055_/l2/molecules/groupentermoney/ml-currency-input-glass.defs" {
    export const group = "groupEnterMoney";
    export const skill = "# Metadata\n- TagName: groupentermoney--ml-currency-input-glass\n\n# Objective\nA currency amount input in the Glassmorphism model. Same contract/logic as groupentermoney--ml-currency-input (mls-102040): inherits it and overrides only the appearance.\n\n# Responsibilities\n- Parse digits as minor units (BigInt-safe), format with Intl (currency/decimal), clamp to min/max on blur.\n- Dispatch input/change/focus/blur with { value }; render label, helper or error, loading overlay and read-only view.\n\n# Constraints\n- Value rounded to decimals and clamped on blur; no changes while disabled or readonly.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102055). Inheritance from mls-102040 (override of render() only). Appearance in the .less scoped to the -glass tag. Assumes a rich/dark background (container contract).";
}
declare module "_102055_/l2/molecules/groupenternumber/ml-number-stepper-glass" {
    import { NumberStepperMolecule } from '_102040_/l2/molecules/groupenternumber/ml-number-stepper';
    export class NumberStepperGlass extends NumberStepperMolecule {
        private gMsg;
        private gUid;
        private get gLabelId();
        private get gHelperId();
        private get gErrorId();
        private get gInputId();
        private get x();
        private glassInputClasses;
        private glassButtonClasses;
        private glassContainerClasses;
        private glassLabel;
        private glassHelperOrError;
        private glassPrefix;
        private glassSuffix;
        private glassViewMode;
        render(): any;
    }
}
declare module "_102055_/l2/molecules/groupenternumber/ml-range-slider-glass" {
    import { RangeSliderMolecule } from '_102040_/l2/molecules/groupenternumber/ml-range-slider';
    export class RangeSliderGlass extends RangeSliderMolecule {
        private gMsg;
        private gUid;
        private get gLabelId();
        private get gErrorId();
        private get gHelperId();
        private get x();
        private glassInputClasses;
        private glassLabel;
        private glassPrefixSuffix;
        private glassHelperOrError;
        private glassLoading;
        private glassEditMode;
        private glassViewMode;
        render(): TemplateResult;
    }
}
declare module "_102055_/l2/molecules/groupenternumber/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102055_/l2/molecules/groupenternumber/ml-number-stepper-glass";
    import "_102055_/l2/molecules/groupenternumber/ml-range-slider-glass";
    export class GroupEnterNumberIndex extends StateLitElement {
        private qty;
        private priceLow;
        private priceHigh;
        render(): TemplateResult;
    }
}
declare module "_102055_/l2/molecules/groupenternumber/ml-number-stepper-glass.defs" {
    export const group = "groupEnterNumber";
    export const skill = "# Metadata\n- TagName: groupenternumber--ml-number-stepper-glass\n\n# Objective\nA numeric stepper input (with +/- buttons) in the Glassmorphism model. Same contract/logic as groupenternumber--ml-number-stepper (mls-102040): inherits it and overrides only the appearance.\n\n# Responsibilities\n- Parse/format the value with locale + decimals, clamp to min/max, increment/decrement by step.\n- Dispatch input/change/focus/blur with { value }; render label, prefix/suffix, helper or error, loading and read-only view.\n\n# Constraints\n- Value clamped to min/max; no changes while disabled, readonly or loading.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102055). Inheritance from mls-102040 (override of render() only). Appearance in the .less scoped to the -glass tag. Assumes a rich/dark background (container contract).";
}
declare module "_102055_/l2/molecules/groupenternumber/ml-range-slider-glass.defs" {
    export const group = "groupEnterNumber";
    export const skill = "# Metadata\n- TagName: groupenternumber--ml-range-slider-glass\n\n# Objective\nA dual-handle range slider in the Glassmorphism model. Same contract/logic as groupenternumber--ml-range-slider (mls-102040): inherits it and overrides only the appearance.\n\n# Responsibilities\n- Render two range inputs bound to value/value-high; clamp the pair so low <= high; format with locale; prefix/suffix.\n- Dispatch input/change/focus/blur with { value: { min, max } }; render label, helper or error, loading and read-only view.\n\n# Constraints\n- low must not exceed high; values clamped to min/max and rounded to decimals; no changes while disabled, readonly or loading.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102055). Inheritance from mls-102040 (override of render() only). Translucent track/thumbs in the .less scoped to the -glass tag. Assumes a rich/dark background (container contract).";
}
declare module "_102055_/l2/molecules/groupentertext/ml-floating-text-input-glass" {
    import { MlFloatingTextInputMolecule } from '_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    export class MlFloatingTextInputGlass extends MlFloatingTextInputMolecule {
        private gUid;
        private get x();
        private glassPrefix;
        private glassSuffix;
        private glassFeedback;
        private glassInlineLabel;
        private glassFloatingLabel;
        private glassContainerClasses;
        private glassInputClasses;
        render(): any;
    }
}
declare module "_102055_/l2/molecules/groupentertext/ml-password-strength-input-glass" {
    import { PasswordStrengthInputMolecule } from '_102040_/l2/molecules/groupentertext/ml-password-strength-input';
    export class PasswordStrengthInputGlass extends PasswordStrengthInputMolecule {
        private gMsg;
        private get x();
        private strengthLabel;
        private glassContainerClasses;
        private glassWrapperClasses;
        private glassInputClasses;
        private glassToggleClasses;
        private glassBarClasses;
        private glassTextClasses;
        private glassCriteriaClasses;
        private glassLabel;
        private glassPrefix;
        private glassSuffix;
        private glassToggleButton;
        private glassInput;
        private glassStrengthIndicator;
        private glassCriteriaItem;
        private glassHelper;
        private glassErrorMsg;
        private glassLoading;
        private glassViewMode;
        render(): any;
    }
}
declare module "_102055_/l2/molecules/groupentertext/ml-tag-input-glass" {
    import { MlTagInputMolecule } from '_102040_/l2/molecules/groupentertext/ml-tag-input';
    export class MlTagInputGlass extends MlTagInputMolecule {
        private gMsg;
        private get x();
        private glassContainerClasses;
        private glassInputClasses;
        private glassRemoveClasses;
        private glassLabel;
        private glassPrefix;
        private glassSuffix;
        private glassTag;
        private glassTags;
        private glassInput;
        private glassTextarea;
        private glassEditMode;
        private glassViewMode;
        private glassHelper;
        private glassLoading;
        render(): any;
    }
}
declare module "_102055_/l2/molecules/groupentertext/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102055_/l2/molecules/groupentertext/ml-floating-text-input-glass";
    import "_102055_/l2/molecules/groupentertext/ml-password-strength-input-glass";
    import "_102055_/l2/molecules/groupentertext/ml-tag-input-glass";
    export class GroupEnterTextIndex extends StateLitElement {
        private fullName;
        private password;
        private tags;
        render(): TemplateResult;
    }
}
declare module "_102055_/l2/molecules/groupentertext/ml-floating-text-input-glass.defs" {
    export const group = "groupEnterText";
    export const skill = "# Metadata\n- TagName: groupentertext--ml-floating-text-input-glass\n\n# Objective\nA text input with floating/inline label in the Glassmorphism model. Same contract/logic as groupentertext--ml-floating-text-input (mls-102040): inherits it and overrides only the appearance.\n\n# Responsibilities\n- Maintain value with optional input mask (#, A, *); float the label when focused/filled; prefix/suffix; loading; read-only view.\n- Dispatch input/change/focus/blur with { value }; render helper or error.\n\n# Constraints\n- No changes while disabled, readonly, loading or not editing.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102055). Inheritance from mls-102040 (override of render() only). Appearance in the .less scoped to the -glass tag. Assumes a rich/dark background (container contract).";
}
declare module "_102055_/l2/molecules/groupentertext/ml-password-strength-input-glass.defs" {
    export const group = "groupEnterText";
    export const skill = "# Metadata\n- TagName: groupentertext--ml-password-strength-input-glass\n\n# Objective\nA password input with live strength meter and criteria checklist in the Glassmorphism model. Same contract/logic as groupentertext--ml-password-strength-input (mls-102040): inherits it and overrides only the appearance.\n\n# Responsibilities\n- Maintain the password value (optional mask), toggle visibility, compute criteria/strength and render bar + checklist.\n- Dispatch input/change/focus/blur with { value }; render label, helper or error, loading and masked view.\n\n# Constraints\n- maxLength limits the value; no changes while disabled, readonly or loading.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102055). Inheritance from mls-102040 (override of render() only; mask and strength logic inherited). Appearance in the .less scoped to the -glass tag. Assumes a rich/dark background (container contract).";
}
declare module "_102055_/l2/molecules/groupentertext/ml-tag-input-glass.defs" {
    export const group = "groupEnterText";
    export const skill = "# Metadata\n- TagName: groupentertext--ml-tag-input-glass\n\n# Objective\nA tag/chip input in the Glassmorphism model. Same contract/logic as groupentertext--ml-tag-input (mls-102040): inherits it and overrides only the appearance.\n\n# Responsibilities\n- Parse value into tags; add on Enter/comma/blur (dedup, min/max length); remove by index; optional multi-line textarea mode with counter.\n- Dispatch input/change/focus/blur with { value }; render label, helper or error, loading and read-only view.\n\n# Constraints\n- Duplicate tags and out-of-range lengths rejected; no edits while disabled, readonly or loading.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102055). Inheritance from mls-102040 (override of render() only). Frosted chips; appearance in the .less scoped to the -glass tag. Assumes a rich/dark background (container contract).";
}
declare module "_102055_/l2/molecules/groupentertime/ml-clock-time-picker-glass" {
    import { ClockTimePickerMolecule } from '_102040_/l2/molecules/groupentertime/ml-clock-time-picker';
    export class ClockTimePickerGlass extends ClockTimePickerMolecule {
        private gMsg;
        private get x();
        private glassFormatTime;
        private glassStepLabel;
        private glassInputClasses;
        private glassOptionClasses;
        private glassLabel;
        private glassHelperOrError;
        private glassClockOptions;
        private glassAmPm;
        render(): any;
    }
}
declare module "_102055_/l2/molecules/groupentertime/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102055_/l2/molecules/groupentertime/ml-clock-time-picker-glass";
    export class GroupEnterTimeIndex extends StateLitElement {
        private time;
        render(): TemplateResult;
    }
}
declare module "_102055_/l2/molecules/groupentertime/ml-clock-time-picker-glass.defs" {
    export const group = "groupEnterTime";
    export const skill = "# Metadata\n- TagName: groupentertime--ml-clock-time-picker-glass\n\n# Objective\nA glassmorphism time picker built by INHERITANCE: extends ClockTimePickerMolecule (mls-102040) and overrides only render() with translucent/glass markup. All business logic (time parsing, hour\u2192minute\u2192second stages, 12/24h with AM/PM, minute step, min/max bounds, confirm/clear, outside-click) is inherited. The value is a time string (HH:mm or HH:mm:ss).\n\n# Responsibilities\n- Reuse the inherited popover flow: pick hour \u2192 minute \u2192 (second); toggle AM/PM in 12-hour mode; confirm to commit.\n- Render the field, clock options, AM/PM toggle and actions with glass classes.\n- Format the field locally via Intl.DateTimeFormat (own i18n map).\n\n# Constraints\n- Logic is NOT reimplemented; only the visual layer (render + glass class helpers) is overridden.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism by inheritance (mls-102055, parent mls-102040). Translucent field; popover uses rgba(30,27,75,0.85) + blur(18px); circular time options, selected in indigo; confirm is a solid indigo accent. Assumes a rich/dark background (container contract).";
}
declare module "_102055_/l2/molecules/groupexpandcontent/ml-accordion-glass" {
    import { MlAccordionMolecule } from '_102040_/l2/molecules/groupexpandcontent/ml-accordion';
    export class MlAccordionGlass extends MlAccordionMolecule {
        private gMsg;
        private get x();
        private glassHeaderClasses;
        private glassContentClasses;
        private glassChevronClasses;
        render(): any;
        private glassLabel;
        private glassLoading;
        private glassSections;
        private glassSection;
    }
}
declare module "_102055_/l2/molecules/groupexpandcontent/ml-collapsible-panel-glass" {
    import { MlCollapsiblePanelMolecule } from '_102040_/l2/molecules/groupexpandcontent/ml-collapsible-panel';
    export class MlCollapsiblePanelGlass extends MlCollapsiblePanelMolecule {
        private gMsg;
        private get x();
        render(): any;
        private glassLabel;
        private glassLoading;
        private glassSections;
        private glassHeaderClasses;
        private glassChevronClasses;
        private glassContentClasses;
    }
}
declare module "_102055_/l2/molecules/groupexpandcontent/ml-reveal-overlay-glass" {
    import { RevealOverlayMolecule } from '_102040_/l2/molecules/groupexpandcontent/ml-reveal-overlay';
    export class MlRevealOverlayGlass extends RevealOverlayMolecule {
        private gMsg;
        private get x();
        private glassHeaderClasses;
        private glassContainerClasses;
        private glassOverlayClasses;
        private glassActionButtonClasses;
        private glassRenderLoading;
        private glassRenderSectionContent;
        render(): any;
    }
}
declare module "_102055_/l2/molecules/groupexpandcontent/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102055_/l2/molecules/groupexpandcontent/ml-accordion-glass";
    import "_102055_/l2/molecules/groupexpandcontent/ml-collapsible-panel-glass";
    import "_102055_/l2/molecules/groupexpandcontent/ml-reveal-overlay-glass";
    export class GroupExpandContentIndex extends StateLitElement {
        render(): TemplateResult;
    }
}
declare module "_102055_/l2/molecules/groupexpandcontent/ml-accordion-glass.defs" {
    export const group = "groupExpandContent";
    export const skill = "# Metadata\n- TagName: groupexpandcontent--ml-accordion-glass\n\n# Objective\nAn accordion of expand/collapse content sections in the Glassmorphism model. Same contract/logic as groupexpandcontent--ml-accordion (mls-102040): inherits it and overrides only the appearance.\n\n# Responsibilities\n- Render each Section slot as a collapsible panel with a clickable header showing its title; toggle on click or keyboard.\n- Support single-expand and multi-expand modes; initialize open sections from the expanded attribute.\n- Dispatch a toggle event (bubbling, composed) with { index, title, expanded }; allow ArrowDown/ArrowUp navigation skipping disabled headers; activate with Enter/Space.\n- Render an optional Label slot, a loading skeleton when loading, and an empty-state message when no sections exist.\n\n# Constraints\n- No toggling while the component-level disabled or loading state is active, or on a per-section disabled header (tabindex=\"-1\").\n- In single-expand mode, at most one section may be open at any time.\n- The component must not contain business logic; section content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102055). Inheritance from mls-102040 (override of render() only). Appearance in the .less scoped to the -glass tag. Assumes a rich/dark background (container contract).";
}
declare module "_102055_/l2/molecules/groupexpandcontent/ml-collapsible-panel-glass.defs" {
    export const group = "groupExpandContent";
    export const skill = "# Metadata\n- TagName: groupexpandcontent--ml-collapsible-panel-glass\n\n# Objective\nA stacked collapsible panel in the Glassmorphism model. Same contract/logic as groupexpandcontent--ml-collapsible-panel (mls-102040): inherits it and overrides only the appearance.\n\n# Responsibilities\n- Parse Section slots; open initially-expanded sections; toggle on header click/Enter/Space.\n- Enforce single vs multiple open mode; support ArrowUp/Down to move focus between headers.\n- Dispatch toggle with { index, title, expanded }; animate content height/opacity.\n\n# Constraints\n- No toggling while disabled or loading; disabled sections cannot open.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102055). Inheritance from mls-102040 (override of render() only). Appearance in the .less scoped to the -glass tag. Assumes a rich/dark background (container contract).";
}
declare module "_102055_/l2/molecules/groupexpandcontent/ml-reveal-overlay-glass.defs" {
    export const group = "groupExpandContent";
    export const skill = "# Metadata\n- TagName: groupexpandcontent--ml-reveal-overlay-glass\n\n# Objective\nHide section content behind a frosted overlay with a reveal action in the Glassmorphism model. Same contract/logic as groupexpandcontent--ml-reveal-overlay (mls-102040): inherits it and overrides only the appearance.\n\n# Responsibilities\n- Render each Section slot with its content covered by an overlay until revealed; toggle open/closed on header or reveal button; dispatch a toggle event (index, title, expanded).\n- In single mode, revealing a section hides the previously revealed one; initialize from the expanded attribute; support Enter/Space and ArrowUp/ArrowDown navigation.\n- Render an optional Label slot as a warning note; apply disabled appearance; render a loading placeholder.\n\n# Constraints\n- A disabled component or section must not toggle.\n- The component must not contain business logic; section content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102055). Inheritance from mls-102040 (override of render() only). Appearance in the .less scoped to the -glass tag. The overlay uses backdrop-filter to frost the content until revealed. Assumes a rich/dark background (container contract).";
}
declare module "_102055_/l2/molecules/groupnavigatemain/ml-sidebar-nav-glass" {
    import { MlSidebarNavMolecule } from '_102040_/l2/molecules/groupnavigatemain/ml-sidebar-nav';
    export class MlSidebarNavGlass extends MlSidebarNavMolecule {
        private gMsg;
        private get x();
        private glassItemClasses;
        private glassIconClasses;
        private glassItemIcon;
        private glassNavItem;
        private glassGroup;
        private glassCollapseToggle;
        private glassLoading;
        render(): any;
    }
}
declare module "_102055_/l2/molecules/groupnavigatemain/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102055_/l2/molecules/groupnavigatemain/ml-sidebar-nav-glass";
    export class GroupNavigateMainIndex extends StateLitElement {
        private navItem;
        private collapsed;
        render(): TemplateResult;
    }
}
declare module "_102055_/l2/molecules/groupnavigatemain/ml-sidebar-nav-glass.defs" {
    export const group = "groupNavigateMain";
    export const skill = "# Metadata\n- TagName: groupnavigatemain--ml-sidebar-nav-glass\n\n# Objective\nA primary application sidebar navigation in the Glassmorphism model. Same contract/logic as groupnavigatemain--ml-sidebar-nav (mls-102040): it inherits that component and overrides only the appearance (translucent glass surface, items, groups and footer).\n\n# Responsibilities\n- Render top-level Item slots, grouped Items inside Group slots (with collapsible group headers), and Footer Items.\n- Each item shows an icon (or initials fallback), label, and optional badge.\n- Track the active item via value; dispatch a change event (value, label, badge) when an enabled item is clicked.\n- Toggle a collapsed (icon-only) mode and dispatch a collapse event; show tooltips and a badge dot when collapsed.\n- Collapse/expand individual groups; show a loading skeleton.\n\n# Constraints\n- Disabled items do not trigger change events; no interaction while disabled.\n- The component must not contain business logic; slot content/icons are rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102055). Implemented by inheritance from mls-102040 (override of render() and presentational helpers only; slot parsing, collapsed-group state and click/collapse handlers are inherited). Appearance lives in the .less scoped to the -glass tag; the sidebar surface and items are translucent glass and the active item uses an indigo tint. Assumes a rich/dark background (container contract).";
}
declare module "_102055_/l2/molecules/groupnavigatesection/ml-tabs-glass" {
    import { MlTabsMolecule } from '_102040_/l2/molecules/groupnavigatesection/ml-tabs';
    export class MlTabsGlass extends MlTabsMolecule {
        private gMsg;
        private get x();
        private glassTabClasses;
        private glassTabListClasses;
        private glassPanelClasses;
        private glassLabel;
        private glassLoading;
        private glassError;
        render(): any;
    }
}
declare module "_102055_/l2/molecules/groupnavigatesection/ml-navigate-pills-glass" {
    import { NavigatePillsMolecule } from '_102040_/l2/molecules/groupnavigatesection/ml-navigate-pills';
    export class NavigatePillsGlass extends NavigatePillsMolecule {
        private gMsg;
        private get x();
        private glassTabClasses;
        private glassLabel;
        private glassLoading;
        render(): any;
    }
}
declare module "_102055_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail-glass" {
    import { BreadcrumbTrailMolecule } from '_102040_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail';
    export class BreadcrumbTrailGlass extends BreadcrumbTrailMolecule {
        private gMsg;
        private get x();
        private glassTabClasses;
        private glassDelimiterClasses;
        private glassOverflowButtonClasses;
        private glassPanelClasses;
        private glassLabelClasses;
        private glassErrorClasses;
        private glassRenderTab;
        private glassRenderOverflowMenu;
        private glassRenderTrail;
        render(): any;
    }
}
declare module "_102055_/l2/molecules/groupnavigatesection/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102055_/l2/molecules/groupnavigatesection/ml-tabs-glass";
    import "_102055_/l2/molecules/groupnavigatesection/ml-navigate-pills-glass";
    import "_102055_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail-glass";
    export class GroupNavigateSectionIndex extends StateLitElement {
        private bc;
        private pill;
        private tab;
        render(): TemplateResult;
    }
}
declare module "_102055_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail-glass.defs" {
    export const group = "groupNavigateSection";
    export const skill = "# Metadata\n- TagName: groupnavigatesection--ml-breadcrumb-trail-glass\n\n# Objective\nA breadcrumb trail in the Glassmorphism model. Same contract/logic as groupnavigatesection--ml-breadcrumb-trail (mls-102040): it inherits that component and overrides only the appearance (translucent links + glass overflow popover).\n\n# Responsibilities\n- Render each Tab slot as a breadcrumb level with optional icon/title, separated by a delimiter; the last level is the current page (non-clickable).\n- Dispatch change ({ value, title }) when an earlier, enabled level is activated; collapse middle levels into an overflow menu on small screens.\n- Keyboard navigation (ArrowLeft/ArrowRight + Enter/Space) is inherited.\n\n# Constraints\n- The last level and disabled levels are not clickable; no interaction while loading or disabled.\n- The component must not contain business logic; content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102055). Implemented by inheritance from mls-102040 (override of render() only; parse, active-value, click, overflow toggle and keyboard logic are inherited). Appearance lives in the .less scoped to the -glass tag; overflow popover uses rgba(30,27,75,0.85) + blur(18px). Assumes a rich/dark background (container contract).";
}
declare module "_102055_/l2/molecules/groupnavigatesection/ml-navigate-pills-glass.defs" {
    export const group = "groupNavigateSection";
    export const skill = "# Metadata\n- TagName: groupnavigatesection--ml-navigate-pills-glass\n\n# Objective\nA pill-style section navigation in the Glassmorphism model. Same contract/logic as groupnavigatesection--ml-navigate-pills (mls-102040): it inherits that component and overrides only the appearance (translucent pills + glass panel).\n\n# Responsibilities\n- Render each Tab slot as a glass pill with optional icon/title; show the active tab's content in a glass panel.\n- Track the active tab via value (default to first enabled); dispatch change ({ value, title }).\n- Keyboard navigation (ArrowLeft/ArrowRight + Enter/Space) is inherited.\n\n# Constraints\n- Disabled tabs cannot be activated; no interaction while loading or disabled.\n- The component must not contain business logic; content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102055). Implemented by inheritance from mls-102040 (override of render() only; parse, active-index, click and keyboard logic are inherited). Appearance lives in the .less scoped to the -glass tag. Assumes a rich/dark background (container contract).";
}
declare module "_102055_/l2/molecules/groupnavigatesection/ml-tabs-glass.defs" {
    export const group = "groupNavigateSection";
    export const skill = "# Metadata\n- TagName: groupnavigatesection--ml-tabs-glass\n\n# Objective\nAn underlined tab navigation in the Glassmorphism model. Same contract/logic as groupnavigatesection--ml-tabs (mls-102040): it inherits that component and overrides only the appearance (tab list, active underline and translucent panel).\n\n# Responsibilities\n- Render each Tab slot as an underlined tab with optional icon/title; show the active tab's content in a glass panel.\n- Track the active tab via value (default to first enabled); dispatch change ({ value, title }).\n- Keyboard navigation (ArrowLeft/ArrowRight + Enter/Space) and roving tabindex are inherited.\n\n# Constraints\n- Disabled tabs cannot be activated; no interaction while loading or disabled.\n- The component must not contain business logic; content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102055). Implemented by inheritance from mls-102040 (override of render() only; parse, active-value, click and keyboard logic are inherited). Appearance lives in the .less scoped to the -glass tag. Assumes a rich/dark background (container contract).";
}
declare module "_102055_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper-glass" {
    import { MlHorizontalStepperMolecule } from '_102040_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper';
    export class MlHorizontalStepperGlass extends MlHorizontalStepperMolecule {
        private gMsg;
        private get x();
        private glassIndicatorClasses;
        private glassTitleClasses;
        private glassDescriptionClasses;
        private glassContainerClasses;
        private glassLoading;
        private glassStep;
        private glassConnector;
        render(): any;
    }
}
declare module "_102055_/l2/molecules/groupnavigatesteps/ml-wizard-steps-glass" {
    import { MlWizardStepsMolecule } from '_102040_/l2/molecules/groupnavigatesteps/ml-wizard-steps';
    export class MlWizardStepsGlass extends MlWizardStepsMolecule {
        private gMsg;
        private get x();
        private glassLabelText;
        private glassStepClasses;
        private glassLoading;
        private glassLabel;
        private glassStep;
        render(): any;
    }
}
declare module "_102055_/l2/molecules/groupnavigatesteps/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102055_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper-glass";
    import "_102055_/l2/molecules/groupnavigatesteps/ml-wizard-steps-glass";
    export class GroupNavigateStepsIndex extends StateLitElement {
        private stepperValue;
        private wizardValue;
        render(): TemplateResult;
    }
}
declare module "_102055_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper-glass.defs" {
    export const group = "groupNavigateSteps";
    export const skill = "# Metadata\n- TagName: groupnavigatesteps--ml-horizontal-stepper-glass\n\n# Objective\nA horizontal step indicator in the Glassmorphism model. Same contract/logic as groupnavigatesteps--ml-horizontal-stepper (mls-102040): it inherits that component and overrides only the appearance (glass circular indicators + connectors).\n\n# Responsibilities\n- Parse Step slots; mark steps before value (or flagged completed) as completed and value as active.\n- Allow click/keyboard navigation respecting linear mode (only up to value+1) and disabled steps.\n- Dispatch change with { value, title } on navigation; render connectors between steps.\n\n# Constraints\n- In linear mode the user cannot skip ahead beyond the next step; disabled steps are not navigable.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102055). Implemented by inheritance from mls-102040 (override of render() only; parsing, navigation, keyboard and reactive state are inherited). Appearance lives in the .less scoped to the -glass tag; glass circular indicators, active is indigo, completed is emerald. Assumes a rich/dark background (container contract).";
}
declare module "_102055_/l2/molecules/groupnavigatesteps/ml-wizard-steps-glass.defs" {
    export const group = "groupNavigateSteps";
    export const skill = "# Metadata\n- TagName: groupnavigatesteps--ml-wizard-steps-glass\n\n# Objective\nA wizard step navigator in the Glassmorphism model. Same contract/logic as groupnavigatesteps--ml-wizard-steps (mls-102040): it inherits that component and overrides only the appearance (frosted step cards with index/check indicator).\n\n# Responsibilities\n- Parse Step slots (title/description/completed/disabled); highlight the active and completed steps.\n- Enforce linear navigation (can only reach the next step when the current is completed) and skip disabled steps.\n- Dispatch change with { value, title } on navigation; support arrow/Enter/Space keyboard control.\n\n# Constraints\n- In linear mode forward navigation requires the current step to be completed; disabled steps are not navigable.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102055). Implemented by inheritance from mls-102040 (override of render() only; parsing, navigation rules, keyboard and reactive state are inherited). Appearance lives in the .less scoped to the -glass tag; frosted step cards, active is indigo, completed is emerald. Assumes a rich/dark background (container contract).";
}
declare module "_102055_/l2/molecules/groupnotifyuser/ml-alert-modal-glass" {
    import { MlAlertModalMolecule } from '_102040_/l2/molecules/groupnotifyuser/ml-alert-modal';
    export class MlAlertModalGlass extends MlAlertModalMolecule {
        private gMsg;
        private get x();
        private glassHandleDismiss;
        private glassHandleActionClick;
        private glassContainerClasses;
        private glassIconWrapperClasses;
        private glassDefaultIcon;
        private glassIcon;
        private glassTitle;
        private glassMessage;
        private glassActions;
        private glassDismiss;
        render(): any;
    }
}
declare module "_102055_/l2/molecules/groupnotifyuser/ml-notify-banner-glass" {
    import { NotifyBannerMolecule } from '_102040_/l2/molecules/groupnotifyuser/ml-notify-banner';
    export class MlNotifyBannerGlass extends NotifyBannerMolecule {
        private gLocalMsg;
        private get x();
        private glassDismiss;
        private glassActionClick;
        private glassContainerClasses;
        private glassDefaultIcon;
        private glassIcon;
        private glassTitle;
        private glassMessage;
        private glassAction;
        private glassDismissButton;
        render(): any;
    }
}
declare module "_102055_/l2/molecules/groupnotifyuser/ml-toast-notification-glass" {
    import { ToastNotificationMolecule } from '_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class MlToastNotificationGlass extends ToastNotificationMolecule {
        private gMsg;
        private get x();
        private gHandleDismiss;
        private gHandleActionClick;
        private glassContainerClasses;
        private glassPositionClasses;
        private glassAnimationClasses;
        private glassEntryAnimationClass;
        private glassExitAnimationClass;
        private glassAriaRole;
        private glassAriaLive;
        private glassRenderIcon;
        private glassRenderDefaultIcon;
        private glassRenderTitle;
        private glassRenderMessage;
        private glassRenderAction;
        private glassRenderCloseButton;
        render(): any;
    }
}
declare module "_102055_/l2/molecules/groupnotifyuser/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102055_/l2/molecules/groupnotifyuser/ml-alert-modal-glass";
    import "_102055_/l2/molecules/groupnotifyuser/ml-notify-banner-glass";
    import "_102055_/l2/molecules/groupnotifyuser/ml-toast-notification-glass";
    export class GroupNotifyUserIndex extends StateLitElement {
        private bannerVisible;
        private toastVisible;
        private modalOpen;
        render(): TemplateResult;
    }
}
declare module "_102055_/l2/molecules/groupnotifyuser/ml-alert-modal-glass.defs" {
    export const group = "groupNotifyUser";
    export const skill = "# Metadata\n- TagName: groupnotifyuser--ml-alert-modal-glass\n\n# Objective\nA centered modal alert dialog over a blurred scrim in the Glassmorphism model. Same contract/logic as groupnotifyuser--ml-alert-modal (mls-102040): inherits it and overrides only the appearance.\n\n# Responsibilities\n- Render nothing when visible is false; render scrim + glass dialog when visible is true.\n- Apply type-specific accent/icon (info, success, warning, error); normalize \"danger\" to \"error\".\n- Render Icon/Title/Message/Action slots (with fallback message); dispatch action and dismiss custom events (bubbling, composed).\n- Auto-dismiss timer and position handling inherited from the parent.\n\n# Constraints\n- The dialog must render no DOM output while visible is false; the dismiss button only appears when dismissible is true.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102055). Inheritance from mls-102040 (override of render() only). The scrim uses backdrop-filter to blur the page behind it; the dialog is a translucent glass panel. Appearance in the .less scoped to the -glass tag. Assumes a rich/dark background (container contract).";
}
declare module "_102055_/l2/molecules/groupnotifyuser/ml-notify-banner-glass.defs" {
    export const group = "groupNotifyUser";
    export const skill = "# Metadata\n- TagName: groupnotifyuser--ml-notify-banner-glass\n\n# Objective\nA contextual inline or floating notification banner in the Glassmorphism model. Same contract/logic as groupnotifyuser--ml-notify-banner (mls-102040): inherits it and overrides only the appearance.\n\n# Responsibilities\n- Render only when visible is true; nothing when false. Apply type-specific tint/icon (info, success, warning, error).\n- Render optional Title/Action/Icon slots and the Message slot (fallback text when absent); dispatch action/dismiss custom events (bubbling, composed).\n- Show a dismiss button when dismissible; auto-dismiss via inherited timer when visible and duration > 0; apply position classes.\n\n# Constraints\n- No DOM output while visible is false; dismiss button only when dismissible is true.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102055). Inheritance from mls-102040 (override of render() only; lifecycle/timers untouched). Appearance in the .less scoped to the -glass tag. Assumes a rich/dark background (container contract).";
}
declare module "_102055_/l2/molecules/groupnotifyuser/ml-toast-notification-glass.defs" {
    export const group = "groupNotifyUser";
    export const skill = "# Metadata\n- TagName: groupnotifyuser--ml-toast-notification-glass\n\n# Objective\nA transient toast notification in the Glassmorphism model. Same contract/logic as groupnotifyuser--ml-toast-notification (mls-102040): inherits it and overrides only the appearance.\n\n# Responsibilities\n- Render the toast only when visible (or while animating out); apply type-specific tint (info, success, warning, error) and a default icon.\n- Render optional Title, Message, Action and Icon slots; dispatch action on Action click and dismiss on close; auto-dismiss via inherited timer.\n\n# Constraints\n- No DOM output while not visible and not animating out; dismiss button only when dismissible is true.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102055). Inheritance from mls-102040 (override of render() only; lifecycle/timers untouched). Appearance in the .less scoped to the -glass tag. Assumes a rich/dark background (container contract).";
}
declare module "_102055_/l2/molecules/grouprateitem/ml-star-rating-glass" {
    import { MlStarRatingMolecule } from '_102040_/l2/molecules/grouprateitem/ml-star-rating';
    export class StarRatingGlass extends MlStarRatingMolecule {
        private get internals();
        private glassLabel;
        private glassHelperOrError;
        private glassHiddenInput;
        private glassStarIcon;
        private glassOption;
        private glassEditMode;
        private glassViewMode;
        render(): any;
    }
}
declare module "_102055_/l2/molecules/grouprateitem/ml-emoji-mood-scale-glass" {
    import { EmojiMoodScaleMolecule } from '_102040_/l2/molecules/grouprateitem/ml-emoji-mood-scale';
    export class EmojiMoodScaleGlass extends EmojiMoodScaleMolecule {
        private gMsg;
        private get internals();
        private glassLabel;
        private glassHelperOrError;
        private glassContainerClasses;
        private glassOptionClasses;
        private glassOption;
        private glassViewMode;
        render(): any;
    }
}
declare module "_102055_/l2/molecules/grouprateitem/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102055_/l2/molecules/grouprateitem/ml-star-rating-glass";
    import "_102055_/l2/molecules/grouprateitem/ml-emoji-mood-scale-glass";
    export class GroupRateItemIndex extends StateLitElement {
        private rating;
        private mood;
        render(): TemplateResult;
    }
}
declare module "_102055_/l2/molecules/grouprateitem/ml-emoji-mood-scale-glass.defs" {
    export const group = "groupRateItem";
    export const skill = "# Metadata\n- TagName: grouprateitem--ml-emoji-mood-scale-glass\n\n# Objective\nA mood/sentiment emoji scale in the Glassmorphism model. Same contract/logic as grouprateitem--ml-emoji-mood-scale (mls-102040): it inherits that component and overrides only the appearance.\n\n# Responsibilities\n- Build options from Item slots or min/max/step and render them as a radiogroup; handle click/hover/keyboard selection; dispatch change/focus/blur with { value }.\n- Render label, helper or error, and a read-only summary of the chosen option.\n\n# Constraints\n- No selection while disabled or readonly; required with no value shows a validation message.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102055). Implemented by inheritance from mls-102040 (override of render() only); appearance lives in the .less scoped to the -glass tag. Frosted emoji buttons; selected/hover highlighted in indigo. Assumes a rich/dark background (container contract).";
}
declare module "_102055_/l2/molecules/grouprateitem/ml-star-rating-glass.defs" {
    export const group = "groupRateItem";
    export const skill = "# Metadata\n- TagName: grouprateitem--ml-star-rating-glass\n\n# Objective\nA star rating control in the Glassmorphism model. Same contract/logic as grouprateitem--ml-star-rating (mls-102040): it inherits that component and overrides only the appearance.\n\n# Responsibilities\n- Build rating options from Item slots or min/max/step; handle click/hover/keyboard selection as a radiogroup; dispatch change/focus/blur with { value }.\n- Render label, helper or error, a hidden input, and a read-only summary.\n\n# Constraints\n- No selection while disabled or readonly; required with no value marks the group invalid.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102055). Implemented by inheritance from mls-102040 (override of render() only); appearance lives in the .less scoped to the -glass tag. Translucent container; active stars glow gold. Assumes a rich/dark background (container contract).";
}
declare module "_102055_/l2/molecules/groupsearchcontent/ml-search-bar-glass" {
    import { MlSearchBarMolecule } from '_102040_/l2/molecules/groupsearchcontent/ml-search-bar';
    export class MlSearchBarGlass extends MlSearchBarMolecule {
        private gMsg;
        private gComponentId;
        private get x();
        private glassInputClasses;
        private glassPanelClasses;
        private glassSuggestionClasses;
        private glassLabel;
        private glassHelperOrError;
        private glassSuggestions;
        render(): any;
    }
}
declare module "_102055_/l2/molecules/groupsearchcontent/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102055_/l2/molecules/groupsearchcontent/ml-search-bar-glass";
    export class GroupSearchContentIndex extends StateLitElement {
        private query;
        private lastSearch;
        render(): TemplateResult;
    }
}
declare module "_102055_/l2/molecules/groupsearchcontent/ml-search-bar-glass.defs" {
    export const group = "groupSearchContent";
    export const skill = "# Metadata\n- TagName: groupsearchcontent--ml-search-bar-glass\n\n# Objective\nA search input in the Glassmorphism model. Same contract/logic as groupsearchcontent--ml-search-bar (mls-102040): it inherits that component and overrides only the appearance (translucent input + frosted suggestion panel).\n\n# Responsibilities\n- Track the query, debounce 'search' events, and dispatch 'change' on commit (Enter or suggestion click) and 'clear' when emptied.\n- Render suggestions from Suggestion slots; support ArrowUp/Down/Enter/Escape and mouse selection.\n- Show loading and empty states inside the suggestion panel; show label, helper or error.\n\n# Constraints\n- No interaction while disabled.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102055). Implemented by inheritance from mls-102040 (override of render() only; query/debounce/keyboard navigation and events are inherited). Appearance lives in the .less scoped to the -glass tag; suggestion panel uses rgba(30,27,75,0.85) + blur(18px). Assumes a rich/dark background (container contract).";
}
declare module "_102055_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone-glass" {
    import { MlFileUploadDropzoneMolecule } from '_102040_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone';
    export class MlFileUploadDropzoneGlass extends MlFileUploadDropzoneMolecule {
        private gMsg;
        private gLabelId;
        private gErrorId;
        private get x();
        private glassTriggerContent;
        private glassFileList;
        render(): any;
    }
}
declare module "_102055_/l2/molecules/groupselectfileforupload/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102055_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone-glass";
    export class GroupSelectFileForUploadIndex extends StateLitElement {
        render(): TemplateResult;
    }
}
declare module "_102055_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone-glass.defs" {
    export const group = "groupSelectFileForUpload";
    export const skill = "# Metadata\n- TagName: groupselectfileforupload--ml-file-upload-dropzone-glass\n\n# Objective\nA drag-and-drop file selection zone in the Glassmorphism model. Same contract/logic as groupselectfileforupload--ml-file-upload-dropzone (mls-102040): it inherits that component and overrides only the appearance (translucent dashed dropzone + frosted file cards).\n\n# Responsibilities\n- Open the native file picker on click/Enter/Space; accept files via drag-and-drop with a dragging highlight.\n- Validate files against accept, max-size-kb and max-files; dispatch 'reject' with the rejected files and reason.\n- Update value with valid files (replace in single mode, append in multiple mode) and allow removing files.\n- Render label, helper or error, loading state and the selected-file list.\n\n# Constraints\n- No interaction while disabled or loading.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102055). Implemented by inheritance from mls-102040 (override of render() only; drag-and-drop, validation by type/size/count, file processing and events are inherited). Appearance lives in the .less scoped to the -glass tag. Assumes a rich/dark background (container contract).";
}
declare module "_102055_/l2/molecules/groupselectmany/ml-multi-select-dropdown-glass" {
    import { TemplateResult } from 'lit';
    import { MultiSelectDropdownMolecule } from '_102040_/l2/molecules/groupselectmany/ml-multi-select-dropdown';
    export class MlMultiSelectDropdownGlass extends MultiSelectDropdownMolecule {
        protected portalClassName: string;
        private gMsg;
        private gUid;
        private gLabelId;
        private gHelperId;
        private gErrorId;
        private gPanelId;
        private get x();
        private glassTriggerClasses;
        private glassItemClasses;
        private glassLabel;
        private glassHelperOrError;
        private glassSelectedTags;
        private glassTriggerContent;
        private glassOptionButton;
        private glassOptionList;
        protected getPortalTemplate(): TemplateResult;
        private glassViewMode;
        render(): any;
    }
}
declare module "_102055_/l2/molecules/groupselectmany/ml-popover-multi-select-glass" {
    import { TemplateResult } from 'lit';
    import { MlPopoverMultiSelectMolecule } from '_102040_/l2/molecules/groupselectmany/ml-popover-multi-select';
    export class MlPopoverMultiSelectGlass extends MlPopoverMultiSelectMolecule {
        protected portalClassName: string;
        private gMsg;
        private gUid;
        private gLabelId;
        private gErrorId;
        private gPanelId;
        private get x();
        private glassTriggerClasses;
        private glassItemClasses;
        private glassLabel;
        private glassHelper;
        private glassError;
        private glassSelectedTag;
        private glassTriggerContent;
        private glassEmpty;
        private glassOptionButton;
        private glassGroup;
        private glassItems;
        protected getPortalTemplate(): TemplateResult;
        private glassViewMode;
        render(): any;
    }
}
declare module "_102055_/l2/molecules/groupselectmany/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102055_/l2/molecules/groupselectmany/ml-multi-select-dropdown-glass";
    import "_102055_/l2/molecules/groupselectmany/ml-popover-multi-select-glass";
    export class GroupSelectManyIndex extends StateLitElement {
        private skills;
        private langs;
        render(): TemplateResult;
    }
}
declare module "_102055_/l2/molecules/groupselectmany/ml-multi-select-dropdown-glass.defs" {
    export const group = "groupSelectMany";
    export const skill = "# Metadata\n- TagName: groupselectmany--ml-multi-select-dropdown-glass\n\n# Objective\nA multi-select dropdown in the Glassmorphism model. Same contract/logic as groupselectmany--ml-multi-select-dropdown (mls-102040): it inherits that component and overrides only the appearance (trigger with chips + popover list).\n\n# Responsibilities\n- Open a popover; select/deselect multiple Items (optionally grouped); optional search; respect min/max selection; close on outside click.\n- Dispatch change ({ value }) as a comma-joined list; emit focus/blur; keep a hidden input for forms.\n- Show selected chips (or a count when many) on the trigger; render a view mode when not editing.\n\n# Constraints\n- No changes while disabled, readonly or loading; disabled Items and max-reached options are not selectable.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102055). Implemented by inheritance from mls-102040 (override of render() only; selection, parsing, search, keyboard and outside-click are inherited via a typed internals cast). Appearance lives in the .less scoped to the -glass tag; popover uses rgba(30,27,75,0.85) + blur(18px). Assumes a rich/dark background (container contract).";
}
declare module "_102055_/l2/molecules/groupselectmany/ml-popover-multi-select-glass.defs" {
    export const group = "groupSelectMany";
    export const skill = "# Metadata\n- TagName: groupselectmany--ml-popover-multi-select-glass\n\n# Objective\nA popover multi-select in the Glassmorphism model. Same contract/logic as groupselectmany--ml-popover-multi-select (mls-102040): it inherits that component and overrides only the appearance (trigger with chips + frosted popover with keyboard navigation).\n\n# Responsibilities\n- Open a popover; select/deselect multiple Items (optionally grouped); optional search; respect min/max selection; navigate options with arrow keys and toggle with Enter/Space; close on Escape/outside click.\n- Dispatch change ({ value }) as a comma-joined list; emit focus/blur.\n- Show up to two selected chips plus a +N counter on the trigger; render a view mode when not editing.\n\n# Constraints\n- No changes while disabled, readonly or loading; disabled Items and max-reached options are not selectable.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102055). Implemented by inheritance from mls-102040 (override of render() only; selection, parsing, search, keyboard activeIndex and outside-click are inherited via a typed internals cast). Option buttons keep data-ml-item + data-index so the inherited focusActiveItem keyboard nav works. Appearance lives in the .less scoped to the -glass tag; popover uses rgba(30,27,75,0.85) + blur(18px). Assumes a rich/dark background (container contract).";
}
declare module "_102055_/l2/molecules/groupselectone/ml-select-dropdown-glass" {
    import { TemplateResult } from 'lit';
    import { MlSelectDropdownMolecule } from '_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    export class MlSelectDropdownGlass extends MlSelectDropdownMolecule {
        protected portalClassName: string;
        private gMsg;
        private get x();
        private glassTriggerClasses;
        private glassDropdownClasses;
        private glassItemClasses;
        private glassSearchClasses;
        private glassLabel;
        private glassTriggerContent;
        private glassChevron;
        private glassTrigger;
        private glassSearchInput;
        private glassItems;
        private glassEmpty;
        protected getPortalTemplate(): TemplateResult;
        private glassHelper;
        private glassError;
        private glassFeedback;
        private glassViewMode;
        render(): any;
    }
}
declare module "_102055_/l2/molecules/groupselectone/ml-radio-group-glass" {
    import { MlRadioGroupMolecule } from '_102040_/l2/molecules/groupselectone/ml-radio-group';
    export class MlRadioGroupGlass extends MlRadioGroupMolecule {
        private gMsg;
        private gLabelId;
        private gErrorId;
        private get x();
        private glassContainerClasses;
        private glassOptionClasses;
        private glassRadioClasses;
        private glassTextClasses;
        private glassLabel;
        private glassRadioIndicator;
        private glassOption;
        private glassGroup;
        private glassRadioOptions;
        private glassLoading;
        private glassFeedback;
        private glassViewMode;
        render(): any;
    }
}
declare module "_102055_/l2/molecules/groupselectone/ml-segmented-control-glass" {
    import { SegmentedControlMolecule } from '_102040_/l2/molecules/groupselectone/ml-segmented-control';
    export class SegmentedControlGlass extends SegmentedControlMolecule {
        private gMsg;
        private get x();
        private glassContainerClasses;
        private glassSegmentClasses;
        private glassLabelClasses;
        private glassHelperClasses;
        private glassErrorClasses;
        private glassViewModeClasses;
        private glassViewMode;
        private glassEditMode;
        private glassLabel;
        private glassLoading;
        private glassSegments;
        private glassSegment;
        private glassEmpty;
        private glassFeedback;
        render(): TemplateResult;
    }
}
declare module "_102055_/l2/molecules/groupselectone/ml-combobox-glass" {
    import { TemplateResult } from 'lit';
    import { MlComboboxMolecule } from '_102040_/l2/molecules/groupselectone/ml-combobox';
    export class MlComboboxGlass extends MlComboboxMolecule {
        protected portalClassName: string;
        private gMsg;
        private get x();
        private glassInputClasses;
        private glassOptionClasses;
        private glassCheckmark;
        private glassOption;
        protected getPortalTemplate(): TemplateResult;
        private glassLoading;
        render(): any;
    }
}
declare module "_102055_/l2/molecules/groupselectone/ml-card-selector-glass" {
    import { TemplateResult } from 'lit';
    import { MlCardSelectorMolecule } from '_102040_/l2/molecules/groupselectone/ml-card-selector';
    export class MlCardSelectorGlass extends MlCardSelectorMolecule {
        protected portalClassName: string;
        private gMsg;
        private get x();
        private glassTriggerClasses;
        private glassPanelClasses;
        private glassCardClasses;
        private glassSearchInputClasses;
        private glassGroupLabelClasses;
        private glassLabel;
        private glassTrigger;
        private glassSearch;
        private glassCard;
        private glassCardGrid;
        private glassEmpty;
        protected getPortalTemplate(): TemplateResult;
        private glassHelper;
        private glassError;
        private glassFeedback;
        private glassViewMode;
        render(): any;
    }
}
declare module "_102055_/l2/molecules/groupselectone/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102055_/l2/molecules/groupselectone/ml-select-dropdown-glass";
    import "_102055_/l2/molecules/groupselectone/ml-radio-group-glass";
    import "_102055_/l2/molecules/groupselectone/ml-segmented-control-glass";
    import "_102055_/l2/molecules/groupselectone/ml-combobox-glass";
    import "_102055_/l2/molecules/groupselectone/ml-card-selector-glass";
    export class GroupSelectOneIndex extends StateLitElement {
        private country;
        private plan;
        private view;
        private fruit;
        private tier;
        render(): TemplateResult;
    }
}
declare module "_102055_/l2/molecules/groupselectone/ml-card-selector-glass.defs" {
    export const group = "groupSelectOne";
    export const skill = "# Metadata\n- TagName: groupselectone--ml-card-selector-glass\n\n# Objective\nA card selector (popover with a grid of selectable cards) in the Glassmorphism model. Same contract/logic as groupselectone--ml-card-selector (mls-102040): it inherits that component and overrides only the appearance (translucent trigger + frosted popover with glass cards).\n\n# Responsibilities\n- Open a popover; optionally search; render Item/Group cards; navigate with the keyboard; select a card; close on outside click.\n- Dispatch change ({ value }), focus and blur; show selected/focused/disabled states.\n\n# Constraints\n- No changes while disabled or readonly; disabled cards are not selectable; the panel does not open while loading.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102055). Implemented by inheritance from mls-102040 (override of render() only; parsing, filtering, keyboard navigation, open/close and outside-click are inherited). Appearance lives in the .less scoped to the -glass tag; popover uses rgba(30,27,75,0.85) + blur(18px). Assumes a rich/dark background (container contract).";
}
declare module "_102055_/l2/molecules/groupselectone/ml-combobox-glass.defs" {
    export const group = "groupSelectOne";
    export const skill = "# Metadata\n- TagName: groupselectone--ml-combobox-glass\n\n# Objective\nA combobox (typeahead select) in the Glassmorphism model. Same contract/logic as groupselectone--ml-combobox (mls-102040): it inherits that component and overrides only the appearance (translucent input + frosted popover).\n\n# Responsibilities\n- Filter Item/Group options as the user types; navigate with the keyboard; select an option; optional free-text; optional clear button; close on outside click.\n- Dispatch input ({ value }), change ({ value }), focus and blur; keep a hidden input for forms.\n\n# Constraints\n- No changes while disabled, readonly or loading; disabled options are not selectable.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102055). Implemented by inheritance from mls-102040 (override of render() only; parsing, filtering, keyboard navigation, free-text and outside-click are inherited). Appearance lives in the .less scoped to the -glass tag; popover uses rgba(30,27,75,0.85) + blur(18px). Assumes a rich/dark background (container contract).";
}
declare module "_102055_/l2/molecules/groupselectone/ml-radio-group-glass.defs" {
    export const group = "groupSelectOne";
    export const skill = "# Metadata\n- TagName: groupselectone--ml-radio-group-glass\n\n# Objective\nA single-select radio group in the Glassmorphism model. Same contract/logic as groupselectone--ml-radio-group (mls-102040): it inherits that component and overrides only the appearance (glass option cards).\n\n# Responsibilities\n- Render selectable option cards (standalone and grouped); roving keyboard navigation (Arrow keys, Enter/Space, Escape).\n- Select one option; dispatch change ({ value }), focus and blur; render label/helper/error and a compact view mode.\n\n# Constraints\n- No selection while disabled, readonly or loading; disabled items are not selectable.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102055). Implemented by inheritance from mls-102040 (override of render() only; parsing, keyboard and events are inherited). Appearance lives in the .less scoped to the -glass tag; option cards use rgba(255,255,255,0.08) + blur(10px), selected uses indigo tint. Assumes a rich/dark background (container contract).";
}
declare module "_102055_/l2/molecules/groupselectone/ml-segmented-control-glass.defs" {
    export const group = "groupSelectOne";
    export const skill = "# Metadata\n- TagName: groupselectone--ml-segmented-control-glass\n\n# Objective\nA single-select segmented control in the Glassmorphism model. Same contract/logic as groupselectone--ml-segmented-control (mls-102040): it inherits that component and overrides only the appearance (glass track + segments).\n\n# Responsibilities\n- Render inline segments from Item slots; roving keyboard navigation (Arrow keys, Enter/Space) over enabled segments.\n- Select one segment; dispatch change ({ value }), focus and blur; render label/helper/error and a compact view mode.\n\n# Constraints\n- No selection while disabled, readonly or loading; disabled segments are not selectable.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102055). Implemented by inheritance from mls-102040 (override of render() only; parsing, keyboard and events are inherited). Appearance lives in the .less scoped to the -glass tag; track uses rgba(255,255,255,0.08) + blur(10px), selected segment uses a brighter translucent fill. Assumes a rich/dark background (container contract).";
}
declare module "_102055_/l2/molecules/groupselectone/ml-select-dropdown-glass.defs" {
    export const group = "groupSelectOne";
    export const skill = "# Metadata\n- TagName: groupselectone--ml-select-dropdown-glass\n\n# Objective\nA single-select dropdown in the Glassmorphism model. Same contract/logic as groupselectone--ml-select-dropdown (mls-102040): it inherits that component and overrides only the appearance (trigger + translucent popover).\n\n# Responsibilities\n- Open a popover listbox; optionally search/filter items; select one option; close on outside click and Escape.\n- Support standalone items and grouped items; keyboard navigation (ArrowUp/Down, Enter) over selectable items.\n- Dispatch change ({ value }), focus and blur; render label/helper/error and a compact view mode.\n\n# Constraints\n- No selection or open while disabled, readonly or loading.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102055). Implemented by inheritance from mls-102040 (override of render() only; parsing, search, keyboard and outside-click are inherited). Appearance lives in the .less scoped to the -glass tag; popover uses rgba(30,27,75,0.55) + blur(18px). Assumes a rich/dark background (container contract).";
}
declare module "_102055_/l2/molecules/groupshowprogress/ml-linear-progress-glass" {
    import { LinearProgressMolecule } from '_102040_/l2/molecules/groupshowprogress/ml-linear-progress';
    export class LinearProgressGlass extends LinearProgressMolecule {
        private get x();
        private glassSizeClasses;
        private glassTrackClasses;
        private glassFillClasses;
        private glassValueText;
        render(): any;
    }
}
declare module "_102055_/l2/molecules/groupshowprogress/ml-circular-progress-glass" {
    import { CircularProgressMolecule } from '_102040_/l2/molecules/groupshowprogress/ml-circular-progress';
    export class CircularProgressGlass extends CircularProgressMolecule {
        private get x();
        render(): any;
        private glassRenderSvg;
        private glassWrapperClasses;
        private glassSvgClasses;
        private glassValueTextClasses;
        private glassSizeClasses;
    }
}
declare module "_102055_/l2/molecules/groupshowprogress/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102055_/l2/molecules/groupshowprogress/ml-linear-progress-glass";
    import "_102055_/l2/molecules/groupshowprogress/ml-circular-progress-glass";
    export class GroupShowProgressIndex extends StateLitElement {
        render(): TemplateResult;
    }
}
declare module "_102055_/l2/molecules/groupshowprogress/ml-circular-progress-glass.defs" {
    export const group = "groupShowProgress";
    export const skill = "# Metadata\n- TagName: groupshowprogress--ml-circular-progress-glass\n\n# Objective\nA circular (ring) progress indicator in the Glassmorphism model. Same contract/logic as groupshowprogress--ml-circular-progress (mls-102040): it inherits that component and overrides only the appearance.\n\n# Responsibilities\n- Compute the SVG dash offset from the clamped value or spin the arc when indeterminate.\n- Apply size classes; optionally render the centered rounded percentage; expose progressbar ARIA when determinate.\n\n# Constraints\n- Display only \u2014 no interaction or value mutation.\n- The component must not contain business logic.\n\n# Notes\n- Visual model: glassmorphism (mls-102055). Implemented by inheritance from mls-102040 (override of render() only); appearance lives in the .less scoped to the -glass tag. Translucent ring track with a glowing arc. Assumes a rich/dark background (container contract).";
}
declare module "_102055_/l2/molecules/groupshowprogress/ml-linear-progress-glass.defs" {
    export const group = "groupShowProgress";
    export const skill = "# Metadata\n- TagName: groupshowprogress--ml-linear-progress-glass\n\n# Objective\nA horizontal progress bar in the Glassmorphism model. Same contract/logic as groupshowprogress--ml-linear-progress (mls-102040): it inherits that component and overrides only the appearance.\n\n# Responsibilities\n- Render determinate (0\u2013100) fill width or an indeterminate animation when value is null.\n- Apply size and semantic variant styling; optionally show the rounded percentage; expose progressbar ARIA.\n\n# Constraints\n- Display only \u2014 no interaction or value mutation.\n- The component must not contain business logic.\n\n# Notes\n- Visual model: glassmorphism (mls-102055). Implemented by inheritance from mls-102040 (override of render() only); appearance lives in the .less scoped to the -glass tag. Translucent track with a luminous gradient fill. Assumes a rich/dark background (container contract).";
}
declare module "_102055_/l2/molecules/grouptriggeraction/ml-button-standard-glass" {
    import { ButtonStandardMolecule } from '_102040_/l2/molecules/grouptriggeraction/ml-button-standard';
    export class ButtonStandardGlass extends ButtonStandardMolecule {
        private get x();
        private glassButtonClasses;
        private glassSpinner;
        render(): any;
    }
}
declare module "_102055_/l2/molecules/grouptriggeraction/ml-icon-button-glass" {
    import { IconButtonMolecule } from '_102040_/l2/molecules/grouptriggeraction/ml-icon-button';
    export class IconButtonGlass extends IconButtonMolecule {
        private gMsg;
        private get x();
        private glassButtonClasses;
        private glassIconClasses;
        private glassRenderIcon;
        private glassRenderLoadingIcon;
        render(): any;
    }
}
declare module "_102055_/l2/molecules/grouptriggeraction/ml-split-button-glass" {
    import { MlSplitButtonMolecule } from '_102040_/l2/molecules/grouptriggeraction/ml-split-button';
    export class MlSplitButtonGlass extends MlSplitButtonMolecule {
        private gMsg;
        private get x();
        private glassPrimaryClasses;
        private glassChevronClasses;
        private glassOptionClasses;
        private glassRenderIcon;
        private glassRenderLabel;
        private glassRenderSpinner;
        private glassRenderChevron;
        private glassRenderMenuOptions;
        render(): any;
    }
}
declare module "_102055_/l2/molecules/grouptriggeraction/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102055_/l2/molecules/grouptriggeraction/ml-button-standard-glass";
    import "_102055_/l2/molecules/grouptriggeraction/ml-icon-button-glass";
    import "_102055_/l2/molecules/grouptriggeraction/ml-split-button-glass";
    export class GroupTriggerActionIndex extends StateLitElement {
        private lastAction;
        private onAction;
        render(): TemplateResult;
    }
}
declare module "_102055_/l2/molecules/grouptriggeraction/ml-button-standard-glass.defs" {
    export const group = "groupTriggerAction";
    export const skill = "# Metadata\n- TagName: grouptriggeraction--ml-button-standard-glass\n\n# Objective\nGlassmorphism variant (by inheritance) of the standard button for the groupTriggerAction group. Inherits all logic (variants, sizes, loading, icon, action event) from mls-102040 and overrides only the presentation.\n\n# Notes\n- Visual model: glassmorphism (mls-102055, by inheritance). Logic inherited from mls-102040; appearance lives in the scoped .less. Assumes a rich/dark background behind the component (container contract).";
}
declare module "_102055_/l2/molecules/grouptriggeraction/ml-icon-button-glass.defs" {
    export const group = "groupTriggerAction";
    export const skill = "# Metadata\n- TagName: grouptriggeraction--ml-icon-button-glass\n\n# Objective\nGlassmorphism variant (by inheritance) of the icon-only button for the groupTriggerAction group. Inherits all logic (sizes, loading, action event, accessible label) from mls-102040 and overrides only the presentation.\n\n# Notes\n- Visual model: glassmorphism (mls-102055, by inheritance). Logic inherited from mls-102040; appearance lives in the scoped .less; the button is a translucent glass square. Assumes a rich/dark background behind the component (container contract).";
}
declare module "_102055_/l2/molecules/grouptriggeraction/ml-split-button-glass.defs" {
    export const group = "groupTriggerAction";
    export const skill = "# Metadata\n- TagName: grouptriggeraction--ml-split-button-glass\n\n# Objective\nGlassmorphism variant (by inheritance) of the split button for the groupTriggerAction group. Inherits all logic (secondary options collection, open state, action event, sizes, loading) from mls-102040 and overrides only the presentation.\n\n# Notes\n- Visual model: glassmorphism (mls-102055, by inheritance). Logic inherited from mls-102040; appearance lives in the scoped .less; the buttons are translucent glass and the menu is a translucent popover. Assumes a rich/dark background behind the component (container contract).";
}
declare module "_102055_/l2/molecules/groupviewcard/ml-profile-card-glass" {
    import { MlProfileCardMolecule } from '_102040_/l2/molecules/groupviewcard/ml-profile-card';
    export class MlProfileCardGlass extends MlProfileCardMolecule {
        private get x();
        private glassCardClasses;
        private glassHeader;
        private glassContent;
        private glassFooter;
        private glassAction;
        private glassLoadingSkeleton;
        render(): any;
    }
}
declare module "_102055_/l2/molecules/groupviewcard/ml-vertical-card-glass" {
    import { MlVerticalCardMolecule } from '_102040_/l2/molecules/groupviewcard/ml-vertical-card';
    export class MlVerticalCardGlass extends MlVerticalCardMolecule {
        private get x();
        private glassRootClasses;
        private glassHeader;
        private glassContent;
        private glassFooter;
        private glassAction;
        private glassLoading;
        render(): any;
    }
}
declare module "_102055_/l2/molecules/groupviewcard/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102055_/l2/molecules/groupviewcard/ml-profile-card-glass";
    import "_102055_/l2/molecules/groupviewcard/ml-vertical-card-glass";
    import "_102055_/l2/molecules/grouptriggeraction/ml-button-standard-glass";
    export class GroupViewCardIndex extends StateLitElement {
        private selectedPlan;
        render(): TemplateResult;
    }
}
declare module "_102055_/l2/molecules/groupviewcard/ml-profile-card-glass.defs" {
    export const group = "groupViewCard";
    export const skill = "# Metadata\n- TagName: groupviewcard--ml-profile-card-glass\n\n# Objective\nGlassmorphism variant (by inheritance) of the profile/content card for the groupViewCard group. Inherits all logic (header/content/footer/action regions, clickable/selected/disabled/loading states, cardClick event, editing-mode propagation) from mls-102040 and overrides only the presentation.\n\n# Notes\n- Visual model: glassmorphism (mls-102055, by inheritance). Logic inherited from mls-102040; appearance lives in the scoped .less; the card is a translucent glass panel. Assumes a rich/dark background behind the component (container contract).";
}
declare module "_102055_/l2/molecules/groupviewcard/ml-vertical-card-glass.defs" {
    export const group = "groupViewCard";
    export const skill = "# Metadata\n- TagName: groupviewcard--ml-vertical-card-glass\n\n# Objective\nGlassmorphism variant (by inheritance) of the vertically stacked content card for the groupViewCard group. Inherits all logic (header/content/footer/action regions, clickable/selected/disabled/loading states, cardClick event, editing-mode propagation) from mls-102040 and overrides only the presentation.\n\n# Notes\n- Visual model: glassmorphism (mls-102055, by inheritance). Logic inherited from mls-102040; appearance lives in the scoped .less; the card is a translucent glass panel with a separated action region. Assumes a rich/dark background behind the component (container contract).";
}
declare module "_102055_/l2/molecules/groupviewmetric/ml-metric-card-glass" {
    import { MetricCardMolecule } from '_102040_/l2/molecules/groupviewmetric/ml-metric-card';
    export class MetricCardGlass extends MetricCardMolecule {
        private glassBaseClasses;
        private glassLabelClasses;
        private glassValueClasses;
        private glassHelperClasses;
        private glassTrendClasses;
        private glassAriaLabelFromHtml;
        private glassIcon;
        private glassLabel;
        private glassValue;
        private glassTrend;
        private glassHelper;
        private glassSkeleton;
        render(): any;
    }
}
declare module "_102055_/l2/molecules/groupviewmetric/ml-metric-big-number-glass" {
    import { TemplateResult } from 'lit';
    import { MlMetricBigNumberMolecule } from '_102040_/l2/molecules/groupviewmetric/ml-metric-big-number';
    export class MlMetricBigNumberGlass extends MlMetricBigNumberMolecule {
        render(): TemplateResult;
        private glassIcon;
        private glassLabel;
        private glassValue;
        private glassTrend;
        private glassHelper;
        private glassLoadingSkeleton;
        private glassContainerClasses;
        private glassTrendClasses;
        private glassTrendDirection;
        private glassAriaLabel;
    }
}
declare module "_102055_/l2/molecules/groupviewmetric/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102055_/l2/molecules/groupviewmetric/ml-metric-card-glass";
    import "_102055_/l2/molecules/groupviewmetric/ml-metric-big-number-glass";
    export class GroupViewMetricIndex extends StateLitElement {
        render(): TemplateResult;
    }
}
declare module "_102055_/l2/molecules/groupviewmetric/ml-metric-big-number-glass.defs" {
    export const group = "groupViewMetric";
    export const skill = "# Metadata\n- TagName: groupviewmetric--ml-metric-big-number-glass\n\n# Objective\nA single prominent metric in the Glassmorphism model. Same contract/logic as groupviewmetric--ml-metric-big-number (mls-102040): it inherits that component and overrides only the appearance.\n\n# Responsibilities\n- Render Label/Value/Icon/Trend/Helper slots, with the Value at large size; color the trend by its direction attribute.\n- Show a skeleton while loading; render nothing if no Value is provided; expose an accessible figure label.\n\n# Constraints\n- Display only \u2014 no interaction or value mutation.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102055). Implemented by inheritance from mls-102040 (override of render() only); appearance lives in the .less scoped to the -glass tag. Translucent surface with light text. Assumes a rich/dark background (container contract).";
}
declare module "_102055_/l2/molecules/groupviewmetric/ml-metric-card-glass.defs" {
    export const group = "groupViewMetric";
    export const skill = "# Metadata\n- TagName: groupviewmetric--ml-metric-card-glass\n\n# Objective\nA compact KPI card in the Glassmorphism model. Same contract/logic as groupviewmetric--ml-metric-card (mls-102040): it inherits that component and overrides only the appearance.\n\n# Responsibilities\n- Render Label/Value/Icon/Trend/Helper slots; color the trend badge by its direction attribute.\n- Show a skeleton placeholder while loading; expose an accessible figure label from the Label slot.\n\n# Constraints\n- Display only \u2014 no interaction or value mutation.\n- The component must not contain business logic; slot content is rendered via unsafeHTML and not sanitized here.\n\n# Notes\n- Visual model: glassmorphism (mls-102055). Implemented by inheritance from mls-102040 (override of render() only); appearance lives in the .less scoped to the -glass tag. Translucent card with light text; trend badge uses semantic colors. Assumes a rich/dark background (container contract).";
}
