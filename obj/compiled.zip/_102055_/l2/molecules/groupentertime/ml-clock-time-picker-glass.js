var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupentertime/ml-clock-time-picker-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// CLOCK TIME PICKER — GLASSMORPHISM (mls-102055)
// =============================================================================
// Skill Group: enter + time
// Casca (estratégia D): herda tudo de ClockTimePickerMolecule (mls-102040),
// inclusive render() — o markup base emite classes semânticas ml-*; a aparência
// glass vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { ClockTimePickerMolecule } from '/_102040_/l2/molecules/groupentertime/ml-clock-time-picker.js';
let ClockTimePickerGlass = class ClockTimePickerGlass extends ClockTimePickerMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupentertime--ml-clock-time-picker-glass {
  display: block;
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-font-weight-medium: 500;
  --ml-radius-sm: 10px;
  --ml-radius-lg: 14px;
  --ml-border-width: 1px;
  --ml-outline-variant: rgba(255, 255, 255, 0.2);
  --ml-outline-focus: rgba(199, 210, 254, 0.9);
  --ml-outline-error: rgba(255, 120, 120, 0.7);
  --ml-primary: rgba(129, 140, 248, 0.85);
  --ml-on-primary: #ffffff;
  --ml-surface: rgba(255, 255, 255, 0.08);
  --ml-surface-dim: rgba(30, 27, 75, 0.85);
  --ml-on-surface: #ffffff;
  --ml-on-surface-muted: rgba(255, 255, 255, 0.6);
  --ml-error: #ffb4ab;
  --ml-transition: 150ms ease;
  --ml-focus-ring-width: 3px;
  --ml-focus-ring-color: rgba(199, 210, 254, 0.25);
  --ml-disabled-opacity: 0.5;
  --ml-backdrop-blur: 8px;
  --ml-backdrop-blur-strong: 18px;
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupentertime--ml-clock-time-picker-glass .ml-label {
  display: block;
  color: rgba(255, 255, 255, 0.7);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
}
groupentertime--ml-clock-time-picker-glass .ml-error-text {
  color: var(--ml-error, #ffb4ab);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupentertime--ml-clock-time-picker-glass .ml-helper {
  color: rgba(255, 255, 255, 0.65);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupentertime--ml-clock-time-picker-glass .ml-text {
  color: var(--ml-on-surface, #ffffff);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupentertime--ml-clock-time-picker-glass .ml-text-muted {
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.6));
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupentertime--ml-clock-time-picker-glass button.ml-text-muted {
  background: transparent;
  border: none;
  cursor: pointer;
}
groupentertime--ml-clock-time-picker-glass button.ml-text-muted:disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
}
groupentertime--ml-clock-time-picker-glass .ml-input-container {
  background: var(--ml-surface, rgba(255, 255, 255, 0.08));
  border: var(--ml-border-width, 1px) solid var(--ml-outline-variant, rgba(255, 255, 255, 0.2));
  border-radius: var(--ml-radius-sm, 10px);
  outline: none;
  backdrop-filter: blur(var(--ml-backdrop-blur, 8px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur, 8px));
  transition: border-color var(--ml-transition, 150ms ease), box-shadow var(--ml-transition, 150ms ease), background var(--ml-transition, 150ms ease);
}
groupentertime--ml-clock-time-picker-glass .ml-input-container:focus {
  border-color: var(--ml-outline-focus, rgba(199, 210, 254, 0.9));
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) var(--ml-focus-ring-color, rgba(199, 210, 254, 0.25));
}
groupentertime--ml-clock-time-picker-glass .ml-input-container.ml-input-container-error {
  border-color: var(--ml-outline-error, rgba(255, 120, 120, 0.7));
}
groupentertime--ml-clock-time-picker-glass .ml-input {
  color: var(--ml-on-surface, #ffffff);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupentertime--ml-clock-time-picker-glass .ml-input::placeholder {
  color: rgba(255, 255, 255, 0.45);
}
groupentertime--ml-clock-time-picker-glass .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupentertime--ml-clock-time-picker-glass .ml-clock-panel {
  background: var(--ml-surface-dim, rgba(30, 27, 75, 0.85));
  border: var(--ml-border-width, 1px) solid rgba(255, 255, 255, 0.18);
  border-radius: var(--ml-radius-lg, 14px);
  box-shadow: 0 16px 40px rgba(0, 0, 0, 0.45);
  backdrop-filter: blur(var(--ml-backdrop-blur-strong, 18px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur-strong, 18px));
}
groupentertime--ml-clock-time-picker-glass .ml-clock-number {
  border-radius: 9999px;
  border: var(--ml-border-width, 1px) solid rgba(255, 255, 255, 0.18);
  background: rgba(255, 255, 255, 0.06);
  color: rgba(255, 255, 255, 0.9);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  transition: background 0.12s ease, border-color 0.12s ease, color 0.12s ease;
}
groupentertime--ml-clock-time-picker-glass .ml-clock-number:hover:not(.ml-disabled):not(.ml-clock-number-selected) {
  background: rgba(255, 255, 255, 0.12);
}
groupentertime--ml-clock-time-picker-glass .ml-clock-number.ml-disabled {
  opacity: 0.4;
}
groupentertime--ml-clock-time-picker-glass .ml-clock-number-selected {
  background: rgba(199, 210, 254, 0.2);
  border-color: rgba(199, 210, 254, 0.9);
  color: #e0e7ff;
}
groupentertime--ml-clock-time-picker-glass .ml-clock-ampm {
  border-radius: 8px;
  border: var(--ml-border-width, 1px) solid var(--ml-outline-variant, rgba(255, 255, 255, 0.2));
  background: rgba(255, 255, 255, 0.06);
  color: rgba(255, 255, 255, 0.85);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  cursor: pointer;
}
groupentertime--ml-clock-time-picker-glass .ml-clock-ampm-selected {
  background: rgba(199, 210, 254, 0.2);
  border-color: rgba(199, 210, 254, 0.9);
  color: #e0e7ff;
}
groupentertime--ml-clock-time-picker-glass .ml-clock-action {
  background: transparent;
  border: none;
  color: rgba(255, 255, 255, 0.7);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  cursor: pointer;
}
groupentertime--ml-clock-time-picker-glass .ml-clock-action:hover {
  color: #ffffff;
}
groupentertime--ml-clock-time-picker-glass .ml-clock-confirm {
  border-radius: 8px;
  border: var(--ml-border-width, 1px) solid rgba(199, 210, 254, 0.6);
  background: var(--ml-primary, rgba(129, 140, 248, 0.85));
  color: var(--ml-on-primary, #ffffff);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  cursor: pointer;
  transition: background 0.12s ease;
}
groupentertime--ml-clock-time-picker-glass .ml-clock-confirm:hover {
  background: #818cf8;
}
`);
    }
};
ClockTimePickerGlass = __decorate([
    customElement('groupentertime--ml-clock-time-picker-glass')
], ClockTimePickerGlass);
export { ClockTimePickerGlass };
