var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupentertime/ml-clock-time-picker-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// CLOCK TIME PICKER — GLASSMORPHISM (mls-102055)
// =============================================================================
// Skill Group: enter + time
// Casca (estratégia D): herda tudo de ClockTimePickerMolecule (mls-102040),
// inclusive render() — o markup base emite classes semânticas ml-*; a aparência
// glass vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { ClockTimePickerMolecule } from '/_102040_/l2/molecules/groupentertime/ml-clock-time-picker.js';
let ClockTimePickerGlass = class ClockTimePickerGlass extends ClockTimePickerMolecule {
};
ClockTimePickerGlass = __decorate([
    customElement('groupentertime--ml-clock-time-picker-glass')
], ClockTimePickerGlass);
export { ClockTimePickerGlass };
