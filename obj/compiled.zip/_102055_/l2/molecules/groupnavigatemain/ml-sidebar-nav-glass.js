var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupnavigatemain/ml-sidebar-nav-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// SIDEBAR NAV — GLASSMORPHISM (mls-102055)
// =============================================================================
// Casca (estratégia D): herda tudo de MlSidebarNavMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência glass vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlSidebarNavMolecule } from '/_102040_/l2/molecules/groupnavigatemain/ml-sidebar-nav.js';
let MlSidebarNavGlass = class MlSidebarNavGlass extends MlSidebarNavMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupnavigatemain--ml-sidebar-nav-glass {
  display: block;
  height: 100%;
  font-family: 'Inter', system-ui, sans-serif;
  --ml-focus-ring-color: rgba(199, 210, 254, 0.6);
}
groupnavigatemain--ml-sidebar-nav-glass .ml-surface-bg {
  background: rgba(255, 255, 255, 0.07);
  backdrop-filter: blur(18px);
  -webkit-backdrop-filter: blur(18px);
  color: rgba(255, 255, 255, 0.9);
}
groupnavigatemain--ml-sidebar-nav-glass .border-r.ml-border {
  border-color: rgba(255, 255, 255, 0.16);
}
groupnavigatemain--ml-sidebar-nav-glass .border-b.ml-border,
groupnavigatemain--ml-sidebar-nav-glass .border-t.ml-border {
  border-color: rgba(255, 255, 255, 0.14);
}
groupnavigatemain--ml-sidebar-nav-glass span.ml-text {
  color: #fff;
}
groupnavigatemain--ml-sidebar-nav-glass button.ml-text {
  color: rgba(255, 255, 255, 0.78);
}
groupnavigatemain--ml-sidebar-nav-glass .hover\:ml-text:hover {
  color: #fff;
}
groupnavigatemain--ml-sidebar-nav-glass .ml-text-faint {
  color: rgba(255, 255, 255, 0.6);
}
groupnavigatemain--ml-sidebar-nav-glass .hover\:ml-surface-dim-bg:hover {
  background: rgba(255, 255, 255, 0.12);
}
groupnavigatemain--ml-sidebar-nav-glass .ml-surface-dim-bg {
  background: rgba(255, 255, 255, 0.12);
}
groupnavigatemain--ml-sidebar-nav-glass .h-px.ml-surface-dim-bg {
  background: rgba(255, 255, 255, 0.14);
}
groupnavigatemain--ml-sidebar-nav-glass .ml-surface-dim-bg.ml-text-faint {
  color: rgba(255, 255, 255, 0.85);
}
groupnavigatemain--ml-sidebar-nav-glass button.ml-primary-dim-bg {
  background: rgba(99, 102, 241, 0.42);
}
groupnavigatemain--ml-sidebar-nav-glass span.ml-primary-dim-bg {
  background: rgba(99, 102, 241, 0.55);
}
groupnavigatemain--ml-sidebar-nav-glass button.ml-primary-text {
  color: #fff;
}
groupnavigatemain--ml-sidebar-nav-glass .h-5.ml-primary-text {
  color: #c7d2fe;
}
groupnavigatemain--ml-sidebar-nav-glass .rounded-full.ml-primary-text {
  color: #fff;
}
groupnavigatemain--ml-sidebar-nav-glass .ml-error-dim-bg {
  background: #f87171;
  box-shadow: 0 0 0 2px rgba(30, 27, 75, 0.8);
}
groupnavigatemain--ml-sidebar-nav-glass .group:focus-visible {
  outline: none;
  box-shadow: 0 0 0 2px var(--ml-focus-ring-color);
}
groupnavigatemain--ml-sidebar-nav-glass .group:hover .group-hover\:ml-text-muted {
  color: rgba(255, 255, 255, 0.55);
}
groupnavigatemain--ml-sidebar-nav-glass .uppercase.ml-text-faint {
  cursor: pointer;
}
groupnavigatemain--ml-sidebar-nav-glass .uppercase.ml-text-faint:focus-visible {
  outline: none;
}
groupnavigatemain--ml-sidebar-nav-glass .hover\:ml-text-muted:hover {
  color: rgba(255, 255, 255, 0.85);
}
groupnavigatemain--ml-sidebar-nav-glass .hover\:ml-surface-dim-bg.hover\:ml-text-muted {
  cursor: pointer;
}
groupnavigatemain--ml-sidebar-nav-glass .hover\:ml-surface-dim-bg.hover\:ml-text-muted:hover {
  color: #fff;
}
groupnavigatemain--ml-sidebar-nav-glass .hover\:ml-surface-dim-bg.hover\:ml-text-muted:focus-visible {
  outline: none;
  box-shadow: 0 0 0 2px var(--ml-focus-ring-color);
}
`);
    }
};
MlSidebarNavGlass = __decorate([
    customElement('groupnavigatemain--ml-sidebar-nav-glass')
], MlSidebarNavGlass);
export { MlSidebarNavGlass };
