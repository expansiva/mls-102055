var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupentertext/ml-tag-input-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// TAG INPUT — GLASSMORPHISM (mls-102055)
// =============================================================================
// Skill Group: groupEnterText
// Casca (estratégia D): herda tudo de MlTagInputMolecule (mls-102040),
// inclusive render() — o markup base emite classes semânticas ml-*; a aparência
// glass vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlTagInputMolecule } from '/_102040_/l2/molecules/groupentertext/ml-tag-input.js';
let MlTagInputGlass = class MlTagInputGlass extends MlTagInputMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupentertext--ml-tag-input-glass {
  display: block;
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-radius-sm: 12px;
  --ml-border-width: 1px;
  --ml-border-style: solid;
  --ml-outline-variant: rgba(255, 255, 255, 0.2);
  --ml-outline-focus: rgba(199, 210, 254, 0.9);
  --ml-outline-error: rgba(255, 120, 120, 0.7);
  --ml-surface: rgba(255, 255, 255, 0.08);
  --ml-on-surface: #ffffff;
  --ml-on-surface-muted: rgba(255, 255, 255, 0.55);
  --ml-on-surface-faint: rgba(255, 255, 255, 0.6);
  --ml-error: #ffb4ab;
  --ml-transition: 0.2s ease;
  --ml-focus-ring-width: 3px;
  --ml-focus-ring-color: rgba(199, 210, 254, 0.25);
  --ml-disabled-opacity: 0.5;
  --ml-backdrop-blur: 8px;
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupentertext--ml-tag-input-glass .ml-input-container {
  position: relative;
  background: var(--ml-surface, rgba(255, 255, 255, 0.08));
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, rgba(255, 255, 255, 0.2));
  border-radius: var(--ml-radius-sm, 12px);
  backdrop-filter: blur(var(--ml-backdrop-blur, 8px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur, 8px));
  transition: border-color var(--ml-transition, 0.2s ease), box-shadow var(--ml-transition, 0.2s ease), background var(--ml-transition, 0.2s ease);
}
groupentertext--ml-tag-input-glass .ml-input-container::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  border-top: 1px solid rgba(255, 255, 255, 0.5);
  border-left: 1px solid rgba(255, 255, 255, 0.25);
  pointer-events: none;
}
groupentertext--ml-tag-input-glass .ml-input-container:focus-within {
  border-color: var(--ml-outline-focus, rgba(199, 210, 254, 0.9));
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) var(--ml-focus-ring-color, rgba(199, 210, 254, 0.25));
  background: rgba(255, 255, 255, 0.12);
}
groupentertext--ml-tag-input-glass .ml-input-container:has(.ml-input[readonly]) {
  background: rgba(255, 255, 255, 0.04);
}
groupentertext--ml-tag-input-glass .ml-input-container-error {
  border-color: var(--ml-outline-error, rgba(255, 120, 120, 0.7)) !important;
}
groupentertext--ml-tag-input-glass .ml-input {
  color: var(--ml-on-surface, #ffffff);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupentertext--ml-tag-input-glass .ml-input::placeholder {
  color: rgba(255, 255, 255, 0.45);
}
groupentertext--ml-tag-input-glass .ml-label {
  color: rgba(255, 255, 255, 0.85);
}
groupentertext--ml-tag-input-glass .ml-helper {
  color: rgba(255, 255, 255, 0.65);
}
groupentertext--ml-tag-input-glass .ml-error-text {
  color: var(--ml-error, #ffb4ab);
}
groupentertext--ml-tag-input-glass .ml-text {
  color: var(--ml-on-surface, #ffffff);
}
groupentertext--ml-tag-input-glass .ml-text-muted {
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.55));
}
groupentertext--ml-tag-input-glass .ml-text-faint {
  color: var(--ml-on-surface-faint, rgba(255, 255, 255, 0.6));
}
groupentertext--ml-tag-input-glass .ml-tag {
  background: rgba(199, 210, 254, 0.18);
  color: #e0e7ff;
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) rgba(199, 210, 254, 0.4);
  border-radius: 8px;
  backdrop-filter: blur(4px);
  -webkit-backdrop-filter: blur(4px);
}
groupentertext--ml-tag-input-glass .ml-tag-remove {
  color: rgba(199, 210, 254, 0.9);
}
groupentertext--ml-tag-input-glass .ml-tag-remove:not(.ml-disabled):hover {
  background: rgba(199, 210, 254, 0.3);
  color: #ffffff;
}
groupentertext--ml-tag-input-glass .ml-tag-remove:focus-visible {
  outline: none;
  box-shadow: 0 0 0 2px rgba(199, 210, 254, 0.6);
}
groupentertext--ml-tag-input-glass .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupentertext--ml-tag-input-glass .ml-loading-overlay {
  background: rgba(15, 15, 30, 0.5);
  border-radius: var(--ml-radius-sm, 12px);
  backdrop-filter: blur(4px);
  -webkit-backdrop-filter: blur(4px);
  color: rgba(199, 210, 254, 0.95);
}
`);
    }
};
MlTagInputGlass = __decorate([
    customElement('groupentertext--ml-tag-input-glass')
], MlTagInputGlass);
export { MlTagInputGlass };
