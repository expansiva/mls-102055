var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupentertext/ml-floating-text-input-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML FLOATING TEXT INPUT — GLASSMORPHISM (mls-102055, Strategy D shell)
// =============================================================================
// Skill Group: groupEnterText
// Herda tudo de MlFloatingTextInputMolecule (mls-102040). O render() herdado
// emite as classes semânticas ml-*; toda a aparência vive no .less.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlFloatingTextInputMolecule } from '/_102040_/l2/molecules/groupentertext/ml-floating-text-input.js';
let MlFloatingTextInputGlass = class MlFloatingTextInputGlass extends MlFloatingTextInputMolecule {
};
MlFloatingTextInputGlass = __decorate([
    customElement('groupentertext--ml-floating-text-input-glass')
], MlFloatingTextInputGlass);
export { MlFloatingTextInputGlass };
