var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupentertext/ml-floating-text-input-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML FLOATING TEXT INPUT — GLASSMORPHISM (mls-102055, Strategy D shell)
// =============================================================================
// Skill Group: groupEnterText
// Herda tudo de MlFloatingTextInputMolecule (mls-102040). O render() herdado
// emite as classes semânticas ml-*; toda a aparência vive no .less.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlFloatingTextInputMolecule } from '/_102040_/l2/molecules/groupentertext/ml-floating-text-input.js';
let MlFloatingTextInputGlass = class MlFloatingTextInputGlass extends MlFloatingTextInputMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupentertext--ml-floating-text-input-glass {
  display: block;
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-radius-sm: 12px;
  --ml-border-width: 1px;
  --ml-outline-variant: rgba(255, 255, 255, 0.25);
  --ml-outline-focus: rgba(199, 210, 254, 0.9);
  --ml-outline-error: rgba(255, 120, 120, 0.85);
  --ml-surface: rgba(255, 255, 255, 0.1);
  --ml-on-surface: rgba(255, 255, 255, 0.95);
  --ml-on-surface-muted: rgba(255, 255, 255, 0.7);
  --ml-on-surface-faint: rgba(255, 255, 255, 0.6);
  --ml-error: #ffb4ab;
  --ml-shadow-1: 0 4px 16px rgba(0, 0, 0, 0.16);
  --ml-transition: 250ms ease;
  --ml-focus-ring-width: 3px;
  --ml-focus-ring-color: rgba(199, 210, 254, 0.35);
  --ml-disabled-opacity: 0.5;
  --ml-backdrop-blur: 10px;
}
groupentertext--ml-floating-text-input-glass .ml-text {
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupentertext--ml-floating-text-input-glass .ml-text-muted {
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.7));
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupentertext--ml-floating-text-input-glass label.ml-text-muted {
  color: rgba(255, 255, 255, 0.75);
}
groupentertext--ml-floating-text-input-glass .ml-text-faint {
  color: var(--ml-on-surface-faint, rgba(255, 255, 255, 0.6));
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupentertext--ml-floating-text-input-glass .ml-input-container {
  background: var(--ml-surface, rgba(255, 255, 255, 0.1));
  border: var(--ml-border-width, 1px) solid var(--ml-outline-variant, rgba(255, 255, 255, 0.25));
  border-radius: var(--ml-radius-sm, 12px);
  backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  box-shadow: var(--ml-shadow-1, 0 4px 16px rgba(0, 0, 0, 0.16));
  transition: border-color var(--ml-transition, 250ms ease), box-shadow var(--ml-transition, 250ms ease), background var(--ml-transition, 250ms ease);
}
groupentertext--ml-floating-text-input-glass .ml-input-container::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  border-top: 1px solid rgba(255, 255, 255, 0.45);
  pointer-events: none;
}
groupentertext--ml-floating-text-input-glass .ml-input-container:focus-within:not(.ml-input-container-error) {
  border-color: var(--ml-outline-focus, rgba(199, 210, 254, 0.9));
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) var(--ml-focus-ring-color, rgba(199, 210, 254, 0.35)), var(--ml-shadow-1, 0 4px 16px rgba(0, 0, 0, 0.16));
}
groupentertext--ml-floating-text-input-glass .ml-input-container-error {
  border-color: var(--ml-outline-error, rgba(255, 120, 120, 0.85));
}
groupentertext--ml-floating-text-input-glass .ml-input {
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  caret-color: #c7d2fe;
}
groupentertext--ml-floating-text-input-glass .ml-input::placeholder {
  color: rgba(255, 255, 255, 0.55);
}
groupentertext--ml-floating-text-input-glass .ml-spinner {
  border: 2px solid rgba(255, 255, 255, 0.3);
  border-top-color: rgba(255, 255, 255, 0.9);
}
groupentertext--ml-floating-text-input-glass .ml-error-text {
  color: var(--ml-error, #ffb4ab);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupentertext--ml-floating-text-input-glass .ml-helper {
  color: rgba(255, 255, 255, 0.65);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupentertext--ml-floating-text-input-glass .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
    }
};
MlFloatingTextInputGlass = __decorate([
    customElement('groupentertext--ml-floating-text-input-glass')
], MlFloatingTextInputGlass);
export { MlFloatingTextInputGlass };
