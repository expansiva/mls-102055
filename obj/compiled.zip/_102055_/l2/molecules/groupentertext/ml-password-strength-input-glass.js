var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupentertext/ml-password-strength-input-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// PASSWORD STRENGTH INPUT — GLASS (Strategy D shell)
// =============================================================================
// Herda PasswordStrengthInputMolecule (mls-102040) por completo: o render()
// herdado emite as classes semânticas ml-*; toda a aparência vive no .less.
import { customElement } from 'lit/decorators.js';
import { PasswordStrengthInputMolecule } from '/_102040_/l2/molecules/groupentertext/ml-password-strength-input.js';
let PasswordStrengthInputGlass = class PasswordStrengthInputGlass extends PasswordStrengthInputMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupentertext--ml-password-strength-input-glass {
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-radius-sm: 12px;
  --ml-border-width: 1px;
  --ml-surface: rgba(255, 255, 255, 0.08);
  --ml-on-surface: #ffffff;
  --ml-on-surface-faint: rgba(255, 255, 255, 0.6);
  --ml-outline-variant: rgba(255, 255, 255, 0.2);
  --ml-outline-focus: rgba(199, 210, 254, 0.9);
  --ml-outline-error: rgba(255, 120, 120, 0.7);
  --ml-error: #ffb4ab;
  --ml-transition: 0.2s ease;
  --ml-focus-ring-width: 3px;
  --ml-focus-ring-color: rgba(199, 210, 254, 0.25);
  --ml-disabled-opacity: 0.5;
  --ml-backdrop-blur: 8px;
  display: block;
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupentertext--ml-password-strength-input-glass .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupentertext--ml-password-strength-input-glass .ml-label {
  color: rgba(255, 255, 255, 0.85);
}
groupentertext--ml-password-strength-input-glass .ml-error-text {
  color: var(--ml-error, #ffb4ab);
}
groupentertext--ml-password-strength-input-glass .ml-helper {
  color: rgba(255, 255, 255, 0.65);
}
groupentertext--ml-password-strength-input-glass .ml-text {
  color: var(--ml-on-surface, #ffffff);
  letter-spacing: 0.15em;
}
groupentertext--ml-password-strength-input-glass .ml-text-faint {
  color: var(--ml-on-surface-faint, rgba(255, 255, 255, 0.6));
}
groupentertext--ml-password-strength-input-glass div.ml-text-faint {
  color: rgba(255, 255, 255, 0.55);
}
groupentertext--ml-password-strength-input-glass button.ml-text-faint {
  background: transparent;
  border: none;
  border-radius: 0 12px 12px 0;
}
groupentertext--ml-password-strength-input-glass button.ml-text-faint:hover:not(:disabled) {
  color: #ffffff;
}
groupentertext--ml-password-strength-input-glass .ml-input-container {
  position: relative;
  background: var(--ml-surface, rgba(255, 255, 255, 0.08));
  border: var(--ml-border-width, 1px) solid var(--ml-outline-variant, rgba(255, 255, 255, 0.2));
  border-radius: var(--ml-radius-sm, 12px);
  backdrop-filter: blur(var(--ml-backdrop-blur, 8px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur, 8px));
  transition: border-color var(--ml-transition, 0.2s ease), box-shadow var(--ml-transition, 0.2s ease), background var(--ml-transition, 0.2s ease);
}
groupentertext--ml-password-strength-input-glass .ml-input-container::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  border-top: 1px solid rgba(255, 255, 255, 0.5);
  border-left: 1px solid rgba(255, 255, 255, 0.25);
  pointer-events: none;
}
groupentertext--ml-password-strength-input-glass .ml-input-container:focus-within {
  border-color: var(--ml-outline-focus, rgba(199, 210, 254, 0.9));
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) var(--ml-focus-ring-color, rgba(199, 210, 254, 0.25));
  background: rgba(255, 255, 255, 0.12);
}
groupentertext--ml-password-strength-input-glass .ml-input-container:has(.ml-input[readonly]) {
  background: rgba(255, 255, 255, 0.04);
}
groupentertext--ml-password-strength-input-glass .ml-input-container-error {
  border-color: var(--ml-outline-error, rgba(255, 120, 120, 0.7)) !important;
}
groupentertext--ml-password-strength-input-glass .ml-input {
  color: var(--ml-on-surface, #ffffff);
}
groupentertext--ml-password-strength-input-glass .ml-input::placeholder {
  color: rgba(255, 255, 255, 0.45);
}
groupentertext--ml-password-strength-input-glass .ml-spinner {
  color: rgba(255, 255, 255, 0.7);
}
groupentertext--ml-password-strength-input-glass .ml-text-muted {
  color: rgba(255, 255, 255, 0.7);
}
groupentertext--ml-password-strength-input-glass .ml-strength-track {
  background: rgba(255, 255, 255, 0.15);
}
groupentertext--ml-password-strength-input-glass .ml-strength-weak {
  background-color: #f87171;
}
groupentertext--ml-password-strength-input-glass .ml-strength-weak-text {
  color: #fca5a5;
}
groupentertext--ml-password-strength-input-glass .ml-strength-fair {
  background-color: #fbbf24;
}
groupentertext--ml-password-strength-input-glass .ml-strength-fair-text {
  color: #fcd34d;
}
groupentertext--ml-password-strength-input-glass .ml-strength-strong {
  background-color: #4ade80;
}
groupentertext--ml-password-strength-input-glass .ml-strength-strong-text {
  color: #86efac;
}
groupentertext--ml-password-strength-input-glass .ml-strength-strong.w-full {
  background-color: #34d399;
}
groupentertext--ml-password-strength-input-glass .ml-strength-track:has(> .w-full) + .ml-strength-strong-text {
  color: #6ee7b7;
}
`);
    }
};
PasswordStrengthInputGlass = __decorate([
    customElement('groupentertext--ml-password-strength-input-glass')
], PasswordStrengthInputGlass);
export { PasswordStrengthInputGlass };
