var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupentertext/ml-password-strength-input-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// PASSWORD STRENGTH INPUT — GLASS (Strategy D shell)
// =============================================================================
// Herda PasswordStrengthInputMolecule (mls-102040) por completo: o render()
// herdado emite as classes semânticas ml-*; toda a aparência vive no .less.
import { customElement } from 'lit/decorators.js';
import { PasswordStrengthInputMolecule } from '/_102040_/l2/molecules/groupentertext/ml-password-strength-input.js';
let PasswordStrengthInputGlass = class PasswordStrengthInputGlass extends PasswordStrengthInputMolecule {
};
PasswordStrengthInputGlass = __decorate([
    customElement('groupentertext--ml-password-strength-input-glass')
], PasswordStrengthInputGlass);
export { PasswordStrengthInputGlass };
