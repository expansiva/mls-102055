var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupselectmany/ml-multi-select-dropdown-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// MULTI SELECT DROPDOWN — GLASSMORPHISM (mls-102055)
// =============================================================================
// Casca (estratégia D): herda tudo de MultiSelectDropdownMolecule (mls-102040), inclusive render() e getPortalTemplate() — o markup base emite classes ml-*;
// a aparência glass vem do .less irmão, escopado sob esta tag e sob o
// data-widget do portal.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MultiSelectDropdownMolecule } from '/_102040_/l2/molecules/groupselectmany/ml-multi-select-dropdown.js';
let MultiSelectDropdownGlass = class MultiSelectDropdownGlass extends MultiSelectDropdownMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupselectmany--ml-multi-select-dropdown-glass,
div[data-widget="groupselectmany--ml-multi-select-dropdown-glass"] {
  display: block;
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-font-weight-medium: 600;
  --ml-on-surface: rgba(255, 255, 255, 0.95);
  --ml-on-surface-muted: rgba(255, 255, 255, 0.55);
  --ml-error: #ffb4ab;
  --ml-surface: rgba(255, 255, 255, 0.1);
  --ml-surface-dim: rgba(30, 27, 75, 0.85);
  --ml-border-width: 1px;
  --ml-outline-variant: rgba(255, 255, 255, 0.25);
  --ml-outline-error: rgba(255, 120, 120, 0.85);
  --ml-radius-md: 12px;
  --ml-radius-lg: 14px;
  --ml-transition: 250ms ease;
  --ml-focus-ring-width: 3px;
  --ml-focus-ring-color: rgba(199, 210, 254, 0.3);
  --ml-disabled-opacity: 0.5;
  --ml-backdrop-blur: 10px;
  --ml-backdrop-blur-strong: 18px;
}
groupselectmany--ml-multi-select-dropdown-glass .ml-label,
div[data-widget="groupselectmany--ml-multi-select-dropdown-glass"] .ml-label {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  font-weight: var(--ml-font-weight-medium, 600);
  color: rgba(255, 255, 255, 0.92);
}
groupselectmany--ml-multi-select-dropdown-glass .ml-helper,
div[data-widget="groupselectmany--ml-multi-select-dropdown-glass"] .ml-helper {
  color: rgba(255, 255, 255, 0.65);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupselectmany--ml-multi-select-dropdown-glass .ml-error-text,
div[data-widget="groupselectmany--ml-multi-select-dropdown-glass"] .ml-error-text {
  color: var(--ml-error, #ffb4ab);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupselectmany--ml-multi-select-dropdown-glass .ml-text-muted,
div[data-widget="groupselectmany--ml-multi-select-dropdown-glass"] .ml-text-muted {
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.55));
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupselectmany--ml-multi-select-dropdown-glass div.ml-text-muted,
div[data-widget="groupselectmany--ml-multi-select-dropdown-glass"] div.ml-text-muted {
  color: rgba(255, 255, 255, 0.6);
}
groupselectmany--ml-multi-select-dropdown-glass .ml-disabled,
div[data-widget="groupselectmany--ml-multi-select-dropdown-glass"] .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupselectmany--ml-multi-select-dropdown-glass .ml-select-trigger,
div[data-widget="groupselectmany--ml-multi-select-dropdown-glass"] .ml-select-trigger {
  position: relative;
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
  background: var(--ml-surface, rgba(255, 255, 255, 0.1));
  border: var(--ml-border-width, 1px) solid var(--ml-outline-variant, rgba(255, 255, 255, 0.25));
  border-radius: var(--ml-radius-md, 12px);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16), inset 0 1px 1px rgba(255, 255, 255, 0.25);
  cursor: pointer;
  text-align: left;
  transition: border-color var(--ml-transition, 250ms ease), box-shadow var(--ml-transition, 250ms ease), background var(--ml-transition, 250ms ease);
}
groupselectmany--ml-multi-select-dropdown-glass .ml-select-trigger::before,
div[data-widget="groupselectmany--ml-multi-select-dropdown-glass"] .ml-select-trigger::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  border-top: 1px solid rgba(255, 255, 255, 0.45);
  pointer-events: none;
}
groupselectmany--ml-multi-select-dropdown-glass .ml-select-trigger:focus-visible,
div[data-widget="groupselectmany--ml-multi-select-dropdown-glass"] .ml-select-trigger:focus-visible {
  outline: none;
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) var(--ml-focus-ring-color, rgba(199, 210, 254, 0.3)), 0 4px 16px rgba(0, 0, 0, 0.16);
}
groupselectmany--ml-multi-select-dropdown-glass .ml-select-trigger-error,
div[data-widget="groupselectmany--ml-multi-select-dropdown-glass"] .ml-select-trigger-error {
  border-color: var(--ml-outline-error, rgba(255, 120, 120, 0.85));
}
groupselectmany--ml-multi-select-dropdown-glass .ml-select-tag,
div[data-widget="groupselectmany--ml-multi-select-dropdown-glass"] .ml-select-tag {
  border-radius: 8px;
  background: rgba(99, 102, 241, 0.45);
  color: #fff;
  border: 1px solid rgba(255, 255, 255, 0.2);
}
groupselectmany--ml-multi-select-dropdown-glass .ml-select-view,
div[data-widget="groupselectmany--ml-multi-select-dropdown-glass"] .ml-select-view {
  border-radius: var(--ml-radius-md, 12px);
  border: 1px solid rgba(255, 255, 255, 0.18);
  background: rgba(255, 255, 255, 0.06);
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
}
groupselectmany--ml-multi-select-dropdown-glass .ml-select-panel,
div[data-widget="groupselectmany--ml-multi-select-dropdown-glass"] .ml-select-panel {
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: var(--ml-radius-lg, 14px);
  background: var(--ml-surface-dim, rgba(30, 27, 75, 0.85));
  backdrop-filter: blur(var(--ml-backdrop-blur-strong, 18px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur-strong, 18px));
  box-shadow: 0 16px 44px rgba(0, 0, 0, 0.45), inset 0 1px 0 rgba(255, 255, 255, 0.3);
}
groupselectmany--ml-multi-select-dropdown-glass .ml-select-panel > div:has(> input.ml-select-search),
div[data-widget="groupselectmany--ml-multi-select-dropdown-glass"] .ml-select-panel > div:has(> input.ml-select-search) {
  border-bottom: 1px solid rgba(255, 255, 255, 0.12);
}
groupselectmany--ml-multi-select-dropdown-glass .ml-select-search,
div[data-widget="groupselectmany--ml-multi-select-dropdown-glass"] .ml-select-search {
  background: rgba(255, 255, 255, 0.08);
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  border: 1px solid rgba(255, 255, 255, 0.18);
  border-radius: 8px;
  outline: none;
}
groupselectmany--ml-multi-select-dropdown-glass .ml-select-search::placeholder,
div[data-widget="groupselectmany--ml-multi-select-dropdown-glass"] .ml-select-search::placeholder {
  color: rgba(255, 255, 255, 0.5);
}
groupselectmany--ml-multi-select-dropdown-glass .ml-select-search:focus,
div[data-widget="groupselectmany--ml-multi-select-dropdown-glass"] .ml-select-search:focus {
  border-color: rgba(199, 210, 254, 0.8);
}
groupselectmany--ml-multi-select-dropdown-glass .ml-select-item,
div[data-widget="groupselectmany--ml-multi-select-dropdown-glass"] .ml-select-item {
  border-radius: 8px;
  border: 1px solid transparent;
  color: rgba(255, 255, 255, 0.9);
  background: transparent;
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  cursor: pointer;
  transition: background 150ms ease, color 150ms ease, border-color 150ms ease;
}
groupselectmany--ml-multi-select-dropdown-glass .ml-select-item-hover:hover,
div[data-widget="groupselectmany--ml-multi-select-dropdown-glass"] .ml-select-item-hover:hover {
  background: rgba(255, 255, 255, 0.12);
}
groupselectmany--ml-multi-select-dropdown-glass .ml-select-item-selected,
div[data-widget="groupselectmany--ml-multi-select-dropdown-glass"] .ml-select-item-selected {
  border-radius: 8px;
  border: 1px solid rgba(199, 210, 254, 0.7);
  background: rgba(99, 102, 241, 0.4);
  color: #fff;
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupselectmany--ml-multi-select-dropdown-glass .ml-select-item.ml-disabled,
div[data-widget="groupselectmany--ml-multi-select-dropdown-glass"] .ml-select-item.ml-disabled,
groupselectmany--ml-multi-select-dropdown-glass .ml-select-item-selected.ml-disabled,
div[data-widget="groupselectmany--ml-multi-select-dropdown-glass"] .ml-select-item-selected.ml-disabled {
  opacity: 0.45;
}
groupselectmany--ml-multi-select-dropdown-glass .ml-select-check,
div[data-widget="groupselectmany--ml-multi-select-dropdown-glass"] .ml-select-check {
  color: #c7d2fe;
}
`);
        // O container do portal (document.body) recebe este data-widget — o .less do
        // tema escopa o conteúdo por div[data-widget="...-glass"].
        this.portalWidgetName = 'groupselectmany--ml-multi-select-dropdown-glass';
    }
};
MultiSelectDropdownGlass = __decorate([
    customElement('groupselectmany--ml-multi-select-dropdown-glass')
], MultiSelectDropdownGlass);
export { MultiSelectDropdownGlass };
