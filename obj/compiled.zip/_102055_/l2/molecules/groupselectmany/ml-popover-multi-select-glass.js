var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupselectmany/ml-popover-multi-select-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// POPOVER MULTI SELECT — GLASSMORPHISM (mls-102055)
// =============================================================================
// Casca (estratégia D): herda tudo de MlPopoverMultiSelectMolecule (mls-102040), inclusive render() e getPortalTemplate() — o markup base emite classes ml-*;
// a aparência glass vem do .less irmão, escopado sob esta tag e sob o
// data-widget do portal.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlPopoverMultiSelectMolecule } from '/_102040_/l2/molecules/groupselectmany/ml-popover-multi-select.js';
let MlPopoverMultiSelectGlass = class MlPopoverMultiSelectGlass extends MlPopoverMultiSelectMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupselectmany--ml-popover-multi-select-glass,
div[data-widget="groupselectmany--ml-popover-multi-select-glass"] {
  display: block;
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-on-surface-muted: rgba(255, 255, 255, 0.55);
  --ml-error: #ffb4ab;
  --ml-surface: rgba(255, 255, 255, 0.08);
  --ml-surface-dim: rgba(30, 27, 75, 0.85);
  --ml-outline-variant: rgba(255, 255, 255, 0.2);
  --ml-outline-focus: rgba(199, 210, 254, 0.9);
  --ml-outline-error: rgba(255, 120, 120, 0.7);
  --ml-radius-md: 10px;
  --ml-radius-lg: 12px;
  --ml-focus-ring-width: 3px;
  --ml-focus-ring-color: rgba(199, 210, 254, 0.25);
  --ml-disabled-opacity: 0.5;
  --ml-backdrop-blur: 8px;
  --ml-backdrop-blur-strong: 18px;
}
groupselectmany--ml-popover-multi-select-glass .ml-label,
div[data-widget="groupselectmany--ml-popover-multi-select-glass"] .ml-label {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  color: rgba(255, 255, 255, 0.85);
}
groupselectmany--ml-popover-multi-select-glass .ml-helper,
div[data-widget="groupselectmany--ml-popover-multi-select-glass"] .ml-helper {
  color: rgba(255, 255, 255, 0.65);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupselectmany--ml-popover-multi-select-glass .ml-error-text,
div[data-widget="groupselectmany--ml-popover-multi-select-glass"] .ml-error-text {
  color: var(--ml-error, #ffb4ab);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupselectmany--ml-popover-multi-select-glass .ml-text-muted,
div[data-widget="groupselectmany--ml-popover-multi-select-glass"] .ml-text-muted {
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.55));
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupselectmany--ml-popover-multi-select-glass .ml-text-muted:has(svg),
div[data-widget="groupselectmany--ml-popover-multi-select-glass"] .ml-text-muted:has(svg) {
  color: rgba(255, 255, 255, 0.6);
}
groupselectmany--ml-popover-multi-select-glass div.font-semibold.ml-text-muted,
div[data-widget="groupselectmany--ml-popover-multi-select-glass"] div.font-semibold.ml-text-muted {
  color: rgba(255, 255, 255, 0.5);
}
groupselectmany--ml-popover-multi-select-glass .ml-disabled,
div[data-widget="groupselectmany--ml-popover-multi-select-glass"] .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupselectmany--ml-popover-multi-select-glass .ml-select-trigger,
div[data-widget="groupselectmany--ml-popover-multi-select-glass"] .ml-select-trigger {
  position: relative;
  color: #fff;
  background: var(--ml-surface, rgba(255, 255, 255, 0.08));
  border: 1px solid var(--ml-outline-variant, rgba(255, 255, 255, 0.2));
  border-radius: var(--ml-radius-md, 10px);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  backdrop-filter: blur(var(--ml-backdrop-blur, 8px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur, 8px));
  cursor: pointer;
  transition: border-color 0.15s ease, box-shadow 0.15s ease, background 0.15s ease;
}
groupselectmany--ml-popover-multi-select-glass .ml-select-trigger:focus-visible,
div[data-widget="groupselectmany--ml-popover-multi-select-glass"] .ml-select-trigger:focus-visible {
  outline: none;
  border-color: var(--ml-outline-focus, rgba(199, 210, 254, 0.9));
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) var(--ml-focus-ring-color, rgba(199, 210, 254, 0.25));
}
groupselectmany--ml-popover-multi-select-glass .ml-select-trigger-active,
div[data-widget="groupselectmany--ml-popover-multi-select-glass"] .ml-select-trigger-active {
  border-color: var(--ml-outline-focus, rgba(199, 210, 254, 0.9));
  box-shadow: 0 0 0 3px rgba(199, 210, 254, 0.2);
}
groupselectmany--ml-popover-multi-select-glass .ml-select-trigger-error,
div[data-widget="groupselectmany--ml-popover-multi-select-glass"] .ml-select-trigger-error {
  border-color: var(--ml-outline-error, rgba(255, 120, 120, 0.7));
}
groupselectmany--ml-popover-multi-select-glass .ml-select-tag,
div[data-widget="groupselectmany--ml-popover-multi-select-glass"] .ml-select-tag {
  background: rgba(199, 210, 254, 0.18);
  color: #e0e7ff;
  border: 1px solid rgba(199, 210, 254, 0.35);
}
groupselectmany--ml-popover-multi-select-glass .ml-select-view,
div[data-widget="groupselectmany--ml-popover-multi-select-glass"] .ml-select-view {
  background: rgba(255, 255, 255, 0.04);
  border: 1px solid rgba(255, 255, 255, 0.15);
  border-radius: var(--ml-radius-md, 10px);
  color: #fff;
}
groupselectmany--ml-popover-multi-select-glass .ml-select-panel,
div[data-widget="groupselectmany--ml-popover-multi-select-glass"] .ml-select-panel {
  background: var(--ml-surface-dim, rgba(30, 27, 75, 0.85));
  border: 1px solid rgba(255, 255, 255, 0.18);
  border-radius: var(--ml-radius-lg, 12px);
  box-shadow: 0 16px 40px rgba(0, 0, 0, 0.45);
  backdrop-filter: blur(var(--ml-backdrop-blur-strong, 18px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur-strong, 18px));
}
groupselectmany--ml-popover-multi-select-glass .ml-select-panel-divider,
div[data-widget="groupselectmany--ml-popover-multi-select-glass"] .ml-select-panel-divider {
  border-color: rgba(255, 255, 255, 0.12);
}
groupselectmany--ml-popover-multi-select-glass .ml-select-search,
div[data-widget="groupselectmany--ml-popover-multi-select-glass"] .ml-select-search {
  background: rgba(255, 255, 255, 0.08);
  border: 1px solid var(--ml-outline-variant, rgba(255, 255, 255, 0.2));
  border-radius: 8px;
  color: #fff;
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  outline: none;
}
groupselectmany--ml-popover-multi-select-glass .ml-select-search::placeholder,
div[data-widget="groupselectmany--ml-popover-multi-select-glass"] .ml-select-search::placeholder {
  color: rgba(255, 255, 255, 0.45);
}
groupselectmany--ml-popover-multi-select-glass .ml-select-search:focus,
div[data-widget="groupselectmany--ml-popover-multi-select-glass"] .ml-select-search:focus {
  border-color: var(--ml-outline-focus, rgba(199, 210, 254, 0.9));
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) var(--ml-focus-ring-color, rgba(199, 210, 254, 0.25));
}
groupselectmany--ml-popover-multi-select-glass .ml-select-item,
div[data-widget="groupselectmany--ml-popover-multi-select-glass"] .ml-select-item {
  background: transparent;
  border: 1px solid transparent;
  border-radius: 8px;
  color: rgba(255, 255, 255, 0.9);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  cursor: pointer;
  transition: background 0.12s ease, border-color 0.12s ease, color 0.12s ease;
}
groupselectmany--ml-popover-multi-select-glass .ml-select-item:focus-visible,
div[data-widget="groupselectmany--ml-popover-multi-select-glass"] .ml-select-item:focus-visible {
  outline: none;
  background: rgba(255, 255, 255, 0.12);
}
groupselectmany--ml-popover-multi-select-glass .ml-select-item-hover:hover,
div[data-widget="groupselectmany--ml-popover-multi-select-glass"] .ml-select-item-hover:hover {
  background: rgba(255, 255, 255, 0.08);
}
groupselectmany--ml-popover-multi-select-glass .ml-select-item-selected,
div[data-widget="groupselectmany--ml-popover-multi-select-glass"] .ml-select-item-selected {
  background: rgba(199, 210, 254, 0.18);
  border: 1px solid rgba(199, 210, 254, 0.6);
  border-radius: 8px;
  color: #e0e7ff;
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupselectmany--ml-popover-multi-select-glass .ml-select-check,
div[data-widget="groupselectmany--ml-popover-multi-select-glass"] .ml-select-check {
  color: #c7d2fe;
}
`);
        // O container do portal (document.body) recebe este data-widget — o .less do
        // tema escopa o conteúdo por div[data-widget="...-glass"].
        this.portalWidgetName = 'groupselectmany--ml-popover-multi-select-glass';
    }
};
MlPopoverMultiSelectGlass = __decorate([
    customElement('groupselectmany--ml-popover-multi-select-glass')
], MlPopoverMultiSelectGlass);
export { MlPopoverMultiSelectGlass };
