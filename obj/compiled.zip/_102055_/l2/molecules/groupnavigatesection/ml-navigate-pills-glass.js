var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupnavigatesection/ml-navigate-pills-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// NAVIGATE PILLS — GLASSMORPHISM (mls-102055)
// =============================================================================
// Casca (estratégia D): herda tudo de NavigatePillsMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência glass vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { NavigatePillsMolecule } from '/_102040_/l2/molecules/groupnavigatesection/ml-navigate-pills.js';
let NavigatePillsGlass = class NavigatePillsGlass extends NavigatePillsMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupnavigatesection--ml-navigate-pills-glass {
  display: block;
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-disabled-opacity: 0.5;
  --ml-error: #ffb4ab;
  --ml-primary: rgba(99, 102, 241, 0.5);
  font-family: var(--ml-font-family);
}
groupnavigatesection--ml-navigate-pills-glass .ml-label {
  color: rgba(255, 255, 255, 0.85);
}
groupnavigatesection--ml-navigate-pills-glass .ml-error-text {
  color: var(--ml-error);
}
groupnavigatesection--ml-navigate-pills-glass .ml-nav-pill {
  border-radius: 9999px;
  border: 1px solid rgba(255, 255, 255, 0.22);
  background: rgba(255, 255, 255, 0.08);
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
  color: rgba(255, 255, 255, 0.78);
  transition: background 200ms ease, color 200ms ease, border-color 200ms ease;
}
groupnavigatesection--ml-navigate-pills-glass .ml-nav-pill.ml-nav-pill-active {
  background: var(--ml-primary);
  border-color: rgba(199, 210, 254, 0.8);
  color: #fff;
}
groupnavigatesection--ml-navigate-pills-glass .ml-nav-pill:not(.ml-disabled):not(.ml-nav-pill-active):hover {
  background: rgba(255, 255, 255, 0.15);
  color: #fff;
}
groupnavigatesection--ml-navigate-pills-glass .ml-nav-pill:focus-visible {
  outline: none;
  box-shadow: 0 0 0 2px rgba(199, 210, 254, 0.6);
}
groupnavigatesection--ml-navigate-pills-glass .ml-nav-pill.ml-disabled {
  opacity: var(--ml-disabled-opacity);
  cursor: not-allowed;
}
groupnavigatesection--ml-navigate-pills-glass .ml-nav-pill.ml-text-muted {
  border-radius: 12px;
  border-color: rgba(255, 255, 255, 0.18);
  background: rgba(255, 255, 255, 0.07);
  backdrop-filter: none;
  -webkit-backdrop-filter: none;
  color: rgba(255, 255, 255, 0.6);
}
groupnavigatesection--ml-navigate-pills-glass .ml-nav-pill-panel {
  border-radius: 14px;
  border: 1px solid rgba(255, 255, 255, 0.18);
  background: rgba(255, 255, 255, 0.07);
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
  color: rgba(255, 255, 255, 0.9);
}
`);
    }
};
NavigatePillsGlass = __decorate([
    customElement('groupnavigatesection--ml-navigate-pills-glass')
], NavigatePillsGlass);
export { NavigatePillsGlass };
