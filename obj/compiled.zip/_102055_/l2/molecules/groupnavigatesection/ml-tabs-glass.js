var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupnavigatesection/ml-tabs-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// TABS — GLASSMORPHISM (mls-102055)
// =============================================================================
// Casca (estratégia D): herda tudo de MlTabsMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência glass vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlTabsMolecule } from '/_102040_/l2/molecules/groupnavigatesection/ml-tabs.js';
let MlTabsGlass = class MlTabsGlass extends MlTabsMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupnavigatesection--ml-tabs-glass {
  display: block;
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-disabled-opacity: 0.5;
  --ml-error: #ffb4ab;
  font-family: var(--ml-font-family);
}
groupnavigatesection--ml-tabs-glass .ml-label {
  color: rgba(255, 255, 255, 0.85);
}
groupnavigatesection--ml-tabs-glass .ml-error-text {
  color: var(--ml-error);
}
groupnavigatesection--ml-tabs-glass .ml-tab-list {
  border-bottom: 1px solid rgba(255, 255, 255, 0.18);
}
groupnavigatesection--ml-tabs-glass .ml-tab {
  border: none;
  border-bottom: 2px solid transparent;
  background: transparent;
  color: rgba(255, 255, 255, 0.7);
  transition: color 200ms ease, border-color 200ms ease;
  margin-bottom: -1px;
}
groupnavigatesection--ml-tabs-glass .ml-tab.ml-tab-active {
  border-bottom-color: #c7d2fe;
  color: #fff;
}
groupnavigatesection--ml-tabs-glass .ml-tab:not(.ml-tab-active):not(.ml-disabled):hover {
  color: #fff;
}
groupnavigatesection--ml-tabs-glass .ml-tab:focus-visible {
  outline: none;
  box-shadow: 0 0 0 2px rgba(199, 210, 254, 0.5);
  border-radius: 6px;
}
groupnavigatesection--ml-tabs-glass .ml-tab.ml-disabled {
  opacity: var(--ml-disabled-opacity);
  cursor: not-allowed;
}
groupnavigatesection--ml-tabs-glass .ml-tab-panel {
  border-radius: 14px;
  border: 1px solid rgba(255, 255, 255, 0.18);
  background: rgba(255, 255, 255, 0.07);
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
  color: rgba(255, 255, 255, 0.9);
}
groupnavigatesection--ml-tabs-glass .ml-tab-container {
  border-radius: 12px;
  border: 1px solid rgba(255, 255, 255, 0.18);
  background: rgba(255, 255, 255, 0.07);
  color: rgba(255, 255, 255, 0.6);
}
`);
    }
};
MlTabsGlass = __decorate([
    customElement('groupnavigatesection--ml-tabs-glass')
], MlTabsGlass);
export { MlTabsGlass };
