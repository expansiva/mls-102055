var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// BREADCRUMB TRAIL — GLASSMORPHISM (mls-102055)
// =============================================================================
// Casca (estratégia D): herda tudo de BreadcrumbTrailMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência glass vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { BreadcrumbTrailMolecule } from '/_102040_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail.js';
let BreadcrumbTrailGlass = class BreadcrumbTrailGlass extends BreadcrumbTrailMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupnavigatesection--ml-breadcrumb-trail-glass {
  display: block;
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-disabled-opacity: 0.5;
  --ml-error: #ffb4ab;
  --ml-on-surface: rgba(255, 255, 255, 0.9);
  font-family: var(--ml-font-family);
}
groupnavigatesection--ml-breadcrumb-trail-glass .ml-label {
  color: rgba(255, 255, 255, 0.65);
}
groupnavigatesection--ml-breadcrumb-trail-glass .ml-text-muted {
  color: rgba(255, 255, 255, 0.6);
}
groupnavigatesection--ml-breadcrumb-trail-glass .ml-text {
  color: var(--ml-on-surface);
}
groupnavigatesection--ml-breadcrumb-trail-glass .ml-error-text {
  color: var(--ml-error);
}
groupnavigatesection--ml-breadcrumb-trail-glass .ml-breadcrumb {
  border-radius: 8px;
  border: none;
  background: transparent;
  color: rgba(255, 255, 255, 0.65);
  transition: background 150ms ease, color 150ms ease;
}
groupnavigatesection--ml-breadcrumb-trail-glass .ml-breadcrumb.ml-breadcrumb-current {
  color: #fff;
}
groupnavigatesection--ml-breadcrumb-trail-glass .ml-breadcrumb.cursor-pointer:hover {
  background: rgba(255, 255, 255, 0.12);
  color: #fff;
}
groupnavigatesection--ml-breadcrumb-trail-glass .ml-breadcrumb:focus-visible {
  outline: none;
  box-shadow: 0 0 0 2px rgba(199, 210, 254, 0.6);
}
groupnavigatesection--ml-breadcrumb-trail-glass .ml-breadcrumb.ml-disabled {
  opacity: var(--ml-disabled-opacity);
  cursor: not-allowed;
}
groupnavigatesection--ml-breadcrumb-trail-glass .ml-breadcrumb-separator {
  color: rgba(255, 255, 255, 0.4);
}
groupnavigatesection--ml-breadcrumb-trail-glass .ml-breadcrumb-dropdown {
  border-radius: 12px;
  border: 1px solid rgba(255, 255, 255, 0.2);
  background: rgba(30, 27, 75, 0.85);
  backdrop-filter: blur(18px);
  -webkit-backdrop-filter: blur(18px);
  box-shadow: 0 16px 44px rgba(0, 0, 0, 0.45), inset 0 1px 0 rgba(255, 255, 255, 0.35);
}
`);
    }
};
BreadcrumbTrailGlass = __decorate([
    customElement('groupnavigatesection--ml-breadcrumb-trail-glass')
], BreadcrumbTrailGlass);
export { BreadcrumbTrailGlass };
