var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupentermoney/ml-currency-input-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// CURRENCY INPUT — GLASSMORPHISM (mls-102055)
// =============================================================================
// Skill Group: groupEnterMoney
// Casca (estratégia D): herda tudo de GroupEnterMoneyMlCurrencyInputMolecule
// (mls-102040) — parsing BigInt, clamp min/max, formatação Intl e render() —
// o markup base emite classes semânticas ml-*; a aparência glass vem do .less
// irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { GroupEnterMoneyMlCurrencyInputMolecule } from '/_102040_/l2/molecules/groupentermoney/ml-currency-input.js';
let CurrencyInputGlass = class CurrencyInputGlass extends GroupEnterMoneyMlCurrencyInputMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupentermoney--ml-currency-input-glass {
  display: block;
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-font-weight-medium: 500;
  --ml-radius-sm: 10px;
  --ml-border-width: 1px;
  --ml-outline-variant: rgba(255, 255, 255, 0.2);
  --ml-outline-focus: rgba(199, 210, 254, 0.9);
  --ml-outline-error: rgba(255, 120, 120, 0.7);
  --ml-surface: rgba(255, 255, 255, 0.08);
  --ml-on-surface: #ffffff;
  --ml-on-surface-muted: rgba(255, 255, 255, 0.65);
  --ml-error: #ffb4ab;
  --ml-transition: 0.15s ease;
  --ml-focus-ring-width: 3px;
  --ml-focus-ring-color: rgba(199, 210, 254, 0.25);
  --ml-disabled-opacity: 0.5;
  --ml-backdrop-blur: 8px;
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupentermoney--ml-currency-input-glass .ml-input-container {
  background: var(--ml-surface, rgba(255, 255, 255, 0.08));
  border: var(--ml-border-width, 1px) solid var(--ml-outline-variant, rgba(255, 255, 255, 0.2));
  border-radius: var(--ml-radius-sm, 10px);
  backdrop-filter: blur(var(--ml-backdrop-blur, 8px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur, 8px));
  transition: border-color var(--ml-transition, 0.15s ease), box-shadow var(--ml-transition, 0.15s ease), background var(--ml-transition, 0.15s ease);
}
groupentermoney--ml-currency-input-glass .ml-input-container::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  border-top: 1px solid rgba(255, 255, 255, 0.5);
  border-left: 1px solid rgba(255, 255, 255, 0.25);
  pointer-events: none;
}
groupentermoney--ml-currency-input-glass .ml-input-container:hover:not(.ml-disabled):not(:has(.ml-input[readonly])) {
  background: rgba(255, 255, 255, 0.12);
}
groupentermoney--ml-currency-input-glass .ml-input-container:focus-within {
  border-color: var(--ml-outline-focus, rgba(199, 210, 254, 0.9));
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) var(--ml-focus-ring-color, rgba(199, 210, 254, 0.25));
  background: rgba(255, 255, 255, 0.12);
}
groupentermoney--ml-currency-input-glass .ml-input-container:has(.ml-input[readonly]) {
  background: rgba(255, 255, 255, 0.04);
}
groupentermoney--ml-currency-input-glass .ml-input-container-error {
  border-color: var(--ml-outline-error, rgba(255, 120, 120, 0.7));
}
groupentermoney--ml-currency-input-glass .ml-input-container-error:focus-within {
  border-color: var(--ml-outline-error, rgba(255, 120, 120, 0.7));
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) rgba(255, 120, 120, 0.25);
}
groupentermoney--ml-currency-input-glass .ml-input {
  color: var(--ml-on-surface, #ffffff);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupentermoney--ml-currency-input-glass .ml-input::placeholder {
  color: rgba(255, 255, 255, 0.45);
}
groupentermoney--ml-currency-input-glass .ml-label {
  color: rgba(255, 255, 255, 0.85);
  font-weight: var(--ml-font-weight-medium, 500);
}
groupentermoney--ml-currency-input-glass .ml-helper {
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.65));
}
groupentermoney--ml-currency-input-glass .ml-error-text {
  color: var(--ml-error, #ffb4ab);
}
groupentermoney--ml-currency-input-glass .ml-text {
  color: var(--ml-on-surface, #ffffff);
}
groupentermoney--ml-currency-input-glass .ml-text-muted {
  color: rgba(255, 255, 255, 0.85);
}
groupentermoney--ml-currency-input-glass .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupentermoney--ml-currency-input-glass .ml-loading-overlay {
  background: rgba(15, 15, 30, 0.5);
  border-radius: var(--ml-radius-sm, 10px);
  backdrop-filter: blur(4px);
  -webkit-backdrop-filter: blur(4px);
}
`);
    }
};
CurrencyInputGlass = __decorate([
    customElement('groupentermoney--ml-currency-input-glass')
], CurrencyInputGlass);
export { CurrencyInputGlass };
