var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupentermoney/ml-currency-input-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// CURRENCY INPUT — GLASSMORPHISM (mls-102055)
// =============================================================================
// Skill Group: groupEnterMoney
// Casca (estratégia D): herda tudo de GroupEnterMoneyMlCurrencyInputMolecule
// (mls-102040) — parsing BigInt, clamp min/max, formatação Intl e render() —
// o markup base emite classes semânticas ml-*; a aparência glass vem do .less
// irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { GroupEnterMoneyMlCurrencyInputMolecule } from '/_102040_/l2/molecules/groupentermoney/ml-currency-input.js';
let CurrencyInputGlass = class CurrencyInputGlass extends GroupEnterMoneyMlCurrencyInputMolecule {
};
CurrencyInputGlass = __decorate([
    customElement('groupentermoney--ml-currency-input-glass')
], CurrencyInputGlass);
export { CurrencyInputGlass };
