var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupselectone/ml-select-dropdown-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// SELECT DROPDOWN — GLASSMORPHISM (mls-102055)
// =============================================================================
// Skill Group: groupSelectOne
// Casca (estratégia D): herda tudo de MlSelectDropdownMolecule (mls-102040),
// inclusive render() e getPortalTemplate() — o markup base emite classes ml-*;
// a aparência glass vem do .less irmão, escopado sob esta tag e sob o
// data-widget do portal.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlSelectDropdownMolecule } from '/_102040_/l2/molecules/groupselectone/ml-select-dropdown.js';
let MlSelectDropdownGlass = class MlSelectDropdownGlass extends MlSelectDropdownMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupselectone--ml-select-dropdown-glass,
div[data-widget="groupselectone--ml-select-dropdown-glass"] {
  display: block;
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-font-weight-medium: 600;
  --ml-on-surface: rgba(255, 255, 255, 0.95);
  --ml-on-surface-muted: rgba(255, 255, 255, 0.55);
  --ml-error: #ffb4ab;
  --ml-surface: rgba(255, 255, 255, 0.1);
  --ml-surface-dim: rgba(30, 27, 75, 0.55);
  --ml-border-width: 1px;
  --ml-border-style: solid;
  --ml-outline-variant: rgba(255, 255, 255, 0.25);
  --ml-outline-focus: rgba(199, 210, 254, 0.9);
  --ml-outline-error: rgba(255, 120, 120, 0.85);
  --ml-radius-md: 12px;
  --ml-radius-lg: 14px;
  --ml-transition: 250ms ease;
  --ml-focus-ring-width: 3px;
  --ml-focus-ring-color: rgba(199, 210, 254, 0.3);
  --ml-disabled-opacity: 0.5;
  --ml-backdrop-blur: 10px;
  --ml-backdrop-blur-strong: 18px;
}
groupselectone--ml-select-dropdown-glass .ml-label,
div[data-widget="groupselectone--ml-select-dropdown-glass"] .ml-label {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  font-weight: var(--ml-font-weight-medium, 600);
  color: rgba(255, 255, 255, 0.92);
}
groupselectone--ml-select-dropdown-glass .ml-helper,
div[data-widget="groupselectone--ml-select-dropdown-glass"] .ml-helper {
  color: rgba(255, 255, 255, 0.65);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupselectone--ml-select-dropdown-glass .ml-error-text,
div[data-widget="groupselectone--ml-select-dropdown-glass"] .ml-error-text {
  color: var(--ml-error, #ffb4ab);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupselectone--ml-select-dropdown-glass .ml-text,
div[data-widget="groupselectone--ml-select-dropdown-glass"] .ml-text {
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupselectone--ml-select-dropdown-glass .ml-text-muted,
div[data-widget="groupselectone--ml-select-dropdown-glass"] .ml-text-muted {
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.55));
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupselectone--ml-select-dropdown-glass svg.ml-text-muted,
div[data-widget="groupselectone--ml-select-dropdown-glass"] svg.ml-text-muted {
  color: rgba(255, 255, 255, 0.7);
}
groupselectone--ml-select-dropdown-glass .ml-disabled,
div[data-widget="groupselectone--ml-select-dropdown-glass"] .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupselectone--ml-select-dropdown-glass .ml-select-trigger,
div[data-widget="groupselectone--ml-select-dropdown-glass"] .ml-select-trigger {
  position: relative;
  background: var(--ml-surface, rgba(255, 255, 255, 0.1));
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, rgba(255, 255, 255, 0.25));
  border-radius: var(--ml-radius-md, 12px);
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.16), inset 0 1px 1px rgba(255, 255, 255, 0.25);
  cursor: pointer;
  transition: border-color var(--ml-transition, 250ms ease), box-shadow var(--ml-transition, 250ms ease), background var(--ml-transition, 250ms ease);
}
groupselectone--ml-select-dropdown-glass .ml-select-trigger::before,
div[data-widget="groupselectone--ml-select-dropdown-glass"] .ml-select-trigger::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  border-top: 1px solid rgba(255, 255, 255, 0.45);
  pointer-events: none;
}
groupselectone--ml-select-dropdown-glass .ml-select-trigger:focus,
div[data-widget="groupselectone--ml-select-dropdown-glass"] .ml-select-trigger:focus {
  border-color: var(--ml-outline-focus, rgba(199, 210, 254, 0.9));
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) var(--ml-focus-ring-color, rgba(199, 210, 254, 0.3)), 0 4px 16px rgba(0, 0, 0, 0.16);
}
groupselectone--ml-select-dropdown-glass .ml-select-trigger:hover:not(:disabled):not(.ml-select-trigger-open),
div[data-widget="groupselectone--ml-select-dropdown-glass"] .ml-select-trigger:hover:not(:disabled):not(.ml-select-trigger-open) {
  background: rgba(255, 255, 255, 0.16);
}
groupselectone--ml-select-dropdown-glass .ml-select-trigger-open,
div[data-widget="groupselectone--ml-select-dropdown-glass"] .ml-select-trigger-open {
  border-color: var(--ml-outline-focus, rgba(199, 210, 254, 0.9));
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) var(--ml-focus-ring-color, rgba(199, 210, 254, 0.3)), 0 4px 16px rgba(0, 0, 0, 0.16);
}
groupselectone--ml-select-dropdown-glass .ml-select-trigger-error,
div[data-widget="groupselectone--ml-select-dropdown-glass"] .ml-select-trigger-error {
  border-color: var(--ml-outline-error, rgba(255, 120, 120, 0.85)) !important;
}
groupselectone--ml-select-dropdown-glass .ml-select-panel,
div[data-widget="groupselectone--ml-select-dropdown-glass"] .ml-select-panel {
  background: var(--ml-surface-dim, rgba(30, 27, 75, 0.55));
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) rgba(255, 255, 255, 0.2);
  border-radius: var(--ml-radius-lg, 14px);
  backdrop-filter: blur(var(--ml-backdrop-blur-strong, 18px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur-strong, 18px));
  box-shadow: 0 16px 44px rgba(0, 0, 0, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.35);
}
groupselectone--ml-select-dropdown-glass .ml-select-search-container,
div[data-widget="groupselectone--ml-select-dropdown-glass"] .ml-select-search-container {
  background: rgba(30, 27, 75, 0.65);
  backdrop-filter: blur(var(--ml-backdrop-blur-strong, 18px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur-strong, 18px));
}
groupselectone--ml-select-dropdown-glass .ml-select-search,
div[data-widget="groupselectone--ml-select-dropdown-glass"] .ml-select-search {
  background: transparent;
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  border: none;
  border-bottom: 1px solid rgba(255, 255, 255, 0.18);
  outline: none;
}
groupselectone--ml-select-dropdown-glass .ml-select-search::placeholder,
div[data-widget="groupselectone--ml-select-dropdown-glass"] .ml-select-search::placeholder {
  color: rgba(255, 255, 255, 0.5);
}
groupselectone--ml-select-dropdown-glass .ml-select-item,
div[data-widget="groupselectone--ml-select-dropdown-glass"] .ml-select-item {
  background: transparent;
  border: none;
  color: rgba(255, 255, 255, 0.9);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  cursor: pointer;
  transition: background 150ms ease, color 150ms ease;
}
groupselectone--ml-select-dropdown-glass .ml-select-item:hover:not(.ml-disabled):not(.ml-select-item-selected),
div[data-widget="groupselectone--ml-select-dropdown-glass"] .ml-select-item:hover:not(.ml-disabled):not(.ml-select-item-selected) {
  background: rgba(255, 255, 255, 0.12);
}
groupselectone--ml-select-dropdown-glass .ml-select-item.ml-disabled,
div[data-widget="groupselectone--ml-select-dropdown-glass"] .ml-select-item.ml-disabled {
  opacity: 0.45;
}
groupselectone--ml-select-dropdown-glass .ml-select-item-highlighted,
div[data-widget="groupselectone--ml-select-dropdown-glass"] .ml-select-item-highlighted {
  background: rgba(255, 255, 255, 0.12);
}
groupselectone--ml-select-dropdown-glass .ml-select-item-selected,
div[data-widget="groupselectone--ml-select-dropdown-glass"] .ml-select-item-selected {
  background: rgba(99, 102, 241, 0.45);
  color: #ffffff;
}
groupselectone--ml-select-dropdown-glass .ml-select-group-label,
div[data-widget="groupselectone--ml-select-dropdown-glass"] .ml-select-group-label {
  color: rgba(255, 255, 255, 0.55);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupselectone--ml-select-dropdown-glass .ml-select-empty,
div[data-widget="groupselectone--ml-select-dropdown-glass"] .ml-select-empty {
  color: rgba(255, 255, 255, 0.6);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
`);
        // O container do portal (document.body) recebe este data-widget — o .less do
        // tema escopa o painel por div[data-widget="...-glass"].
        this.portalWidgetName = 'groupselectone--ml-select-dropdown-glass';
    }
};
MlSelectDropdownGlass = __decorate([
    customElement('groupselectone--ml-select-dropdown-glass')
], MlSelectDropdownGlass);
export { MlSelectDropdownGlass };
