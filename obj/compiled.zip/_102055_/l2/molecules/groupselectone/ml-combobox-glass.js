var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupselectone/ml-combobox-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// COMBOBOX — GLASSMORPHISM (mls-102055)
// =============================================================================
// Casca (estratégia D): herda tudo de MlComboboxMolecule (mls-102040), inclusive render() e getPortalTemplate() — o markup base emite classes ml-*;
// a aparência glass vem do .less irmão, escopado sob esta tag e sob o
// data-widget do portal.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlComboboxMolecule } from '/_102040_/l2/molecules/groupselectone/ml-combobox.js';
let MlComboboxGlass = class MlComboboxGlass extends MlComboboxMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupselectone--ml-combobox-glass,
div[data-widget="groupselectone--ml-combobox-glass"] {
  display: block;
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-on-surface: #ffffff;
  --ml-on-surface-muted: rgba(255, 255, 255, 0.45);
  --ml-error: #ffb4ab;
  --ml-surface: rgba(255, 255, 255, 0.08);
  --ml-surface-dim: rgba(30, 27, 75, 0.85);
  --ml-outline-variant: rgba(255, 255, 255, 0.2);
  --ml-outline-focus: rgba(199, 210, 254, 0.9);
  --ml-outline-error: rgba(255, 120, 120, 0.7);
  --ml-radius-sm: 10px;
  --ml-radius-lg: 12px;
  --ml-border-width: 1px;
  --ml-transition: 150ms ease;
  --ml-focus-ring-width: 3px;
  --ml-focus-ring-color: rgba(199, 210, 254, 0.25);
  --ml-disabled-opacity: 0.5;
  --ml-backdrop-blur: 8px;
  --ml-backdrop-blur-strong: 18px;
}
groupselectone--ml-combobox-glass .ml-label,
div[data-widget="groupselectone--ml-combobox-glass"] .ml-label {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupselectone--ml-combobox-glass label.ml-label,
div[data-widget="groupselectone--ml-combobox-glass"] label.ml-label {
  color: rgba(255, 255, 255, 0.85);
}
groupselectone--ml-combobox-glass div.ml-label,
div[data-widget="groupselectone--ml-combobox-glass"] div.ml-label {
  color: rgba(255, 255, 255, 0.6);
}
groupselectone--ml-combobox-glass .ml-helper,
div[data-widget="groupselectone--ml-combobox-glass"] .ml-helper {
  color: rgba(255, 255, 255, 0.65);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupselectone--ml-combobox-glass .ml-error-text,
div[data-widget="groupselectone--ml-combobox-glass"] .ml-error-text {
  color: var(--ml-error, #ffb4ab);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupselectone--ml-combobox-glass .ml-text,
div[data-widget="groupselectone--ml-combobox-glass"] .ml-text {
  color: var(--ml-on-surface, #ffffff);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupselectone--ml-combobox-glass .ml-text-muted,
div[data-widget="groupselectone--ml-combobox-glass"] .ml-text-muted {
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.45));
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupselectone--ml-combobox-glass span.ml-text-muted,
div[data-widget="groupselectone--ml-combobox-glass"] span.ml-text-muted {
  color: rgba(255, 255, 255, 0.6);
}
groupselectone--ml-combobox-glass button.ml-text-muted,
div[data-widget="groupselectone--ml-combobox-glass"] button.ml-text-muted {
  color: rgba(255, 255, 255, 0.5);
}
groupselectone--ml-combobox-glass button.ml-text-muted:hover,
div[data-widget="groupselectone--ml-combobox-glass"] button.ml-text-muted:hover {
  color: #ffffff;
}
groupselectone--ml-combobox-glass button.ml-text-muted:focus-visible,
div[data-widget="groupselectone--ml-combobox-glass"] button.ml-text-muted:focus-visible {
  box-shadow: 0 0 0 2px rgba(199, 210, 254, 0.6);
}
groupselectone--ml-combobox-glass .ml-text-muted.uppercase,
div[data-widget="groupselectone--ml-combobox-glass"] .ml-text-muted.uppercase {
  color: rgba(255, 255, 255, 0.5);
}
groupselectone--ml-combobox-glass .ml-disabled,
div[data-widget="groupselectone--ml-combobox-glass"] .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupselectone--ml-combobox-glass .ml-select-empty,
div[data-widget="groupselectone--ml-combobox-glass"] .ml-select-empty {
  color: rgba(255, 255, 255, 0.55);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupselectone--ml-combobox-glass .ml-select-checkmark,
div[data-widget="groupselectone--ml-combobox-glass"] .ml-select-checkmark {
  color: #c7d2fe;
}
groupselectone--ml-combobox-glass input.ml-select-trigger,
div[data-widget="groupselectone--ml-combobox-glass"] input.ml-select-trigger {
  position: relative;
  background: var(--ml-surface, rgba(255, 255, 255, 0.08));
  border: var(--ml-border-width, 1px) solid var(--ml-outline-variant, rgba(255, 255, 255, 0.2));
  border-radius: var(--ml-radius-sm, 10px);
  color: var(--ml-on-surface, #ffffff);
  outline: none;
  backdrop-filter: blur(var(--ml-backdrop-blur, 8px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur, 8px));
  transition: border-color var(--ml-transition, 150ms ease), box-shadow var(--ml-transition, 150ms ease), background var(--ml-transition, 150ms ease);
}
groupselectone--ml-combobox-glass input.ml-select-trigger[readonly],
div[data-widget="groupselectone--ml-combobox-glass"] input.ml-select-trigger[readonly] {
  background: rgba(255, 255, 255, 0.04);
}
groupselectone--ml-combobox-glass div.ml-select-trigger,
div[data-widget="groupselectone--ml-combobox-glass"] div.ml-select-trigger {
  background: rgba(255, 255, 255, 0.12);
  border-radius: 10px;
}
groupselectone--ml-combobox-glass .ml-select-trigger-open,
div[data-widget="groupselectone--ml-combobox-glass"] .ml-select-trigger-open {
  border-color: var(--ml-outline-focus, rgba(199, 210, 254, 0.9));
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) var(--ml-focus-ring-color, rgba(199, 210, 254, 0.25));
  background: rgba(255, 255, 255, 0.12);
}
groupselectone--ml-combobox-glass .ml-select-trigger-error,
div[data-widget="groupselectone--ml-combobox-glass"] .ml-select-trigger-error {
  border-color: var(--ml-outline-error, rgba(255, 120, 120, 0.7)) !important;
}
groupselectone--ml-combobox-glass .ml-select-trigger-error.ml-select-trigger-open,
div[data-widget="groupselectone--ml-combobox-glass"] .ml-select-trigger-error.ml-select-trigger-open {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) rgba(255, 120, 120, 0.25);
}
groupselectone--ml-combobox-glass .ml-select-panel,
div[data-widget="groupselectone--ml-combobox-glass"] .ml-select-panel {
  background: var(--ml-surface-dim, rgba(30, 27, 75, 0.85));
  border: 1px solid rgba(255, 255, 255, 0.18);
  border-radius: var(--ml-radius-lg, 12px);
  box-shadow: 0 16px 40px rgba(0, 0, 0, 0.45);
  backdrop-filter: blur(var(--ml-backdrop-blur-strong, 18px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur-strong, 18px));
  list-style: none;
  margin: 0.25rem 0 0;
  padding-left: 0;
}
groupselectone--ml-combobox-glass .ml-select-item,
div[data-widget="groupselectone--ml-combobox-glass"] .ml-select-item {
  color: rgba(255, 255, 255, 0.85);
  cursor: pointer;
  transition: background 120ms ease, color 120ms ease;
}
groupselectone--ml-combobox-glass .ml-select-item:hover:not(.ml-disabled),
div[data-widget="groupselectone--ml-combobox-glass"] .ml-select-item:hover:not(.ml-disabled) {
  background: rgba(255, 255, 255, 0.08);
}
groupselectone--ml-combobox-glass .ml-select-item-highlighted,
div[data-widget="groupselectone--ml-combobox-glass"] .ml-select-item-highlighted {
  background: rgba(255, 255, 255, 0.12);
  color: #ffffff;
}
groupselectone--ml-combobox-glass .ml-select-item-selected,
div[data-widget="groupselectone--ml-combobox-glass"] .ml-select-item-selected {
  background: rgba(199, 210, 254, 0.18);
  color: #e0e7ff;
}
`);
        // O container do portal (document.body) recebe este data-widget — o .less do
        // tema escopa o conteúdo por div[data-widget="...-glass"].
        this.portalWidgetName = 'groupselectone--ml-combobox-glass';
    }
};
MlComboboxGlass = __decorate([
    customElement('groupselectone--ml-combobox-glass')
], MlComboboxGlass);
export { MlComboboxGlass };
