var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupselectone/ml-segmented-control-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// SEGMENTED CONTROL — GLASSMORPHISM (mls-102055)
// =============================================================================
// Casca (estratégia D): herda tudo de SegmentedControlMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência glass vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { SegmentedControlMolecule } from '/_102040_/l2/molecules/groupselectone/ml-segmented-control.js';
let SegmentedControlGlass = class SegmentedControlGlass extends SegmentedControlMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupselectone--ml-segmented-control-glass {
  display: block;
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-error: #ffb4ab;
  --ml-surface: rgba(255, 255, 255, 0.08);
  --ml-outline-variant: rgba(255, 255, 255, 0.2);
  --ml-outline-error: rgba(255, 120, 120, 0.7);
  --ml-radius-lg: 12px;
  --ml-border-width: 1px;
  --ml-backdrop-blur: 10px;
  --ml-disabled-opacity: 0.5;
}
groupselectone--ml-segmented-control-glass .ml-label {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  color: rgba(255, 255, 255, 0.7);
  margin-bottom: 0.375rem;
}
groupselectone--ml-segmented-control-glass .ml-helper {
  color: rgba(255, 255, 255, 0.65);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupselectone--ml-segmented-control-glass .ml-error-text {
  color: var(--ml-error, #ffb4ab);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupselectone--ml-segmented-control-glass .ml-text {
  color: rgba(255, 255, 255, 0.95);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupselectone--ml-segmented-control-glass .ml-text-muted {
  color: rgba(255, 255, 255, 0.6);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupselectone--ml-segmented-control-glass .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupselectone--ml-segmented-control-glass .ml-disabled.cursor-wait {
  opacity: 0.6;
}
groupselectone--ml-segmented-control-glass .ml-segmented-track {
  position: relative;
  border-radius: var(--ml-radius-lg, 12px);
  border: var(--ml-border-width, 1px) solid var(--ml-outline-variant, rgba(255, 255, 255, 0.2));
  background: var(--ml-surface, rgba(255, 255, 255, 0.08));
  backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
}
groupselectone--ml-segmented-control-glass .ml-segmented-track::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  border-top: 1px solid rgba(255, 255, 255, 0.5);
  border-left: 1px solid rgba(255, 255, 255, 0.25);
  pointer-events: none;
}
groupselectone--ml-segmented-control-glass .ml-segmented-track-error {
  box-shadow: 0 0 0 2px var(--ml-outline-error, rgba(255, 120, 120, 0.7));
}
groupselectone--ml-segmented-control-glass .ml-segmented-option {
  flex: 1 1 0;
  border-radius: 9px;
  border: none;
  background: transparent;
  color: rgba(255, 255, 255, 0.7);
}
groupselectone--ml-segmented-control-glass .ml-segmented-option:not(.ml-segmented-option-active):not(.ml-disabled):hover {
  background: rgba(255, 255, 255, 0.12);
  color: #ffffff;
}
groupselectone--ml-segmented-control-glass .ml-segmented-option:focus-visible {
  box-shadow: 0 0 0 2px rgba(199, 210, 254, 0.7);
}
groupselectone--ml-segmented-control-glass .ml-segmented-option-active {
  background: rgba(255, 255, 255, 0.22);
  color: #ffffff;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.25), inset 0 1px 0 rgba(255, 255, 255, 0.4);
}
`);
    }
};
SegmentedControlGlass = __decorate([
    customElement('groupselectone--ml-segmented-control-glass')
], SegmentedControlGlass);
export { SegmentedControlGlass };
