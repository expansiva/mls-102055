var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupselectone/ml-card-selector-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// CARD SELECTOR — GLASSMORPHISM (mls-102055)
// =============================================================================
// Casca (estratégia D): herda tudo de MlCardSelectorMolecule (mls-102040), inclusive render() e getPortalTemplate() — o markup base emite classes ml-*;
// a aparência glass vem do .less irmão, escopado sob esta tag e sob o
// data-widget do portal.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlCardSelectorMolecule } from '/_102040_/l2/molecules/groupselectone/ml-card-selector.js';
let MlCardSelectorGlass = class MlCardSelectorGlass extends MlCardSelectorMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupselectone--ml-card-selector-glass,
div[data-widget="groupselectone--ml-card-selector-glass"] {
  display: block;
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-on-surface: #ffffff;
  --ml-error: #ffb4ab;
  --ml-surface: rgba(255, 255, 255, 0.08);
  --ml-surface-dim: rgba(30, 27, 75, 0.85);
  --ml-outline-variant: rgba(255, 255, 255, 0.2);
  --ml-outline-focus: rgba(199, 210, 254, 0.9);
  --ml-outline-error: rgba(255, 120, 120, 0.7);
  --ml-radius-sm: 10px;
  --ml-radius-lg: 14px;
  --ml-border-width: 1px;
  --ml-transition: 150ms ease;
  --ml-focus-ring-width: 3px;
  --ml-focus-ring-color: rgba(199, 210, 254, 0.25);
  --ml-disabled-opacity: 0.5;
  --ml-backdrop-blur: 8px;
  --ml-backdrop-blur-strong: 18px;
}
groupselectone--ml-card-selector-glass .ml-label,
div[data-widget="groupselectone--ml-card-selector-glass"] .ml-label {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  color: rgba(255, 255, 255, 0.85);
}
groupselectone--ml-card-selector-glass .ml-helper,
div[data-widget="groupselectone--ml-card-selector-glass"] .ml-helper {
  color: rgba(255, 255, 255, 0.65);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupselectone--ml-card-selector-glass .ml-error-text,
div[data-widget="groupselectone--ml-card-selector-glass"] .ml-error-text {
  color: var(--ml-error, #ffb4ab);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupselectone--ml-card-selector-glass .ml-text,
div[data-widget="groupselectone--ml-card-selector-glass"] .ml-text {
  color: var(--ml-on-surface, #ffffff);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupselectone--ml-card-selector-glass .ml-text-muted,
div[data-widget="groupselectone--ml-card-selector-glass"] .ml-text-muted {
  color: rgba(255, 255, 255, 0.45);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupselectone--ml-card-selector-glass svg.ml-text-muted,
div[data-widget="groupselectone--ml-card-selector-glass"] svg.ml-text-muted {
  color: rgba(255, 255, 255, 0.6);
}
groupselectone--ml-card-selector-glass .ml-text-muted.uppercase,
div[data-widget="groupselectone--ml-card-selector-glass"] .ml-text-muted.uppercase {
  color: rgba(255, 255, 255, 0.5);
}
groupselectone--ml-card-selector-glass .ml-text .ml-text-muted,
div[data-widget="groupselectone--ml-card-selector-glass"] .ml-text .ml-text-muted {
  color: rgba(255, 255, 255, 0.6);
}
groupselectone--ml-card-selector-glass .ml-disabled,
div[data-widget="groupselectone--ml-card-selector-glass"] .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupselectone--ml-card-selector-glass .ml-select-empty,
div[data-widget="groupselectone--ml-card-selector-glass"] .ml-select-empty {
  color: rgba(255, 255, 255, 0.55);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupselectone--ml-card-selector-glass .ml-select-checkmark,
div[data-widget="groupselectone--ml-card-selector-glass"] .ml-select-checkmark {
  color: #c7d2fe;
}
groupselectone--ml-card-selector-glass button.ml-select-trigger,
div[data-widget="groupselectone--ml-card-selector-glass"] button.ml-select-trigger {
  position: relative;
  background: var(--ml-surface, rgba(255, 255, 255, 0.08));
  border: var(--ml-border-width, 1px) solid var(--ml-outline-variant, rgba(255, 255, 255, 0.2));
  border-radius: var(--ml-radius-sm, 10px);
  color: var(--ml-on-surface, #ffffff);
  cursor: pointer;
  backdrop-filter: blur(var(--ml-backdrop-blur, 8px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur, 8px));
  transition: border-color var(--ml-transition, 150ms ease), box-shadow var(--ml-transition, 150ms ease), background var(--ml-transition, 150ms ease);
}
groupselectone--ml-card-selector-glass button.ml-select-trigger::before,
div[data-widget="groupselectone--ml-card-selector-glass"] button.ml-select-trigger::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  border-top: 1px solid rgba(255, 255, 255, 0.5);
  border-left: 1px solid rgba(255, 255, 255, 0.25);
  pointer-events: none;
}
groupselectone--ml-card-selector-glass button.ml-select-trigger:hover:not(:disabled):not(.ml-select-trigger-open):not(.ml-select-trigger-error),
div[data-widget="groupselectone--ml-card-selector-glass"] button.ml-select-trigger:hover:not(:disabled):not(.ml-select-trigger-open):not(.ml-select-trigger-error) {
  background: rgba(255, 255, 255, 0.12);
}
groupselectone--ml-card-selector-glass .ml-select-trigger-open,
div[data-widget="groupselectone--ml-card-selector-glass"] .ml-select-trigger-open {
  border-color: var(--ml-outline-focus, rgba(199, 210, 254, 0.9));
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) var(--ml-focus-ring-color, rgba(199, 210, 254, 0.25));
}
groupselectone--ml-card-selector-glass .ml-select-trigger-error,
div[data-widget="groupselectone--ml-card-selector-glass"] .ml-select-trigger-error {
  border-color: var(--ml-outline-error, rgba(255, 120, 120, 0.7)) !important;
}
groupselectone--ml-card-selector-glass .ml-combobox-input,
div[data-widget="groupselectone--ml-card-selector-glass"] .ml-combobox-input {
  background: rgba(255, 255, 255, 0.08);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 8px;
  color: var(--ml-on-surface, #ffffff);
  outline: none;
}
groupselectone--ml-card-selector-glass .ml-combobox-input::placeholder,
div[data-widget="groupselectone--ml-card-selector-glass"] .ml-combobox-input::placeholder {
  color: rgba(255, 255, 255, 0.45);
}
groupselectone--ml-card-selector-glass .ml-combobox-input:focus,
div[data-widget="groupselectone--ml-card-selector-glass"] .ml-combobox-input:focus {
  border-color: var(--ml-outline-focus, rgba(199, 210, 254, 0.9));
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) var(--ml-focus-ring-color, rgba(199, 210, 254, 0.25));
}
groupselectone--ml-card-selector-glass .ml-select-panel,
div[data-widget="groupselectone--ml-card-selector-glass"] .ml-select-panel {
  background: var(--ml-surface-dim, rgba(30, 27, 75, 0.85));
  border: 1px solid rgba(255, 255, 255, 0.18);
  border-radius: var(--ml-radius-lg, 14px);
  box-shadow: 0 16px 40px rgba(0, 0, 0, 0.45);
  backdrop-filter: blur(var(--ml-backdrop-blur-strong, 18px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur-strong, 18px));
}
groupselectone--ml-card-selector-glass .ml-select-panel:has(> input.ml-combobox-input),
div[data-widget="groupselectone--ml-card-selector-glass"] .ml-select-panel:has(> input.ml-combobox-input) {
  background: transparent;
  border: none;
  border-bottom: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: 0;
  backdrop-filter: none;
  -webkit-backdrop-filter: none;
  box-shadow: none;
}
groupselectone--ml-card-selector-glass .ml-card-option,
div[data-widget="groupselectone--ml-card-selector-glass"] .ml-card-option {
  position: relative;
  background: rgba(255, 255, 255, 0.06);
  border: 2px solid rgba(255, 255, 255, 0.15);
  border-radius: 12px;
  color: var(--ml-on-surface, #ffffff);
  cursor: pointer;
  transition: border-color 150ms ease, background 150ms ease, box-shadow 150ms ease;
}
groupselectone--ml-card-selector-glass .ml-card-option::before,
div[data-widget="groupselectone--ml-card-selector-glass"] .ml-card-option::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  border-top: 1px solid rgba(255, 255, 255, 0.5);
  border-left: 1px solid rgba(255, 255, 255, 0.25);
  pointer-events: none;
}
groupselectone--ml-card-selector-glass .ml-card-option:hover:not(.ml-disabled):not(.ml-card-option-selected),
div[data-widget="groupselectone--ml-card-selector-glass"] .ml-card-option:hover:not(.ml-disabled):not(.ml-card-option-selected) {
  border-color: rgba(255, 255, 255, 0.3);
  background: rgba(255, 255, 255, 0.1);
}
groupselectone--ml-card-selector-glass .ml-card-option-selected,
div[data-widget="groupselectone--ml-card-selector-glass"] .ml-card-option-selected {
  border-color: var(--ml-outline-focus, rgba(199, 210, 254, 0.9));
  background: rgba(199, 210, 254, 0.15);
}
groupselectone--ml-card-selector-glass .ml-select-item-highlighted,
div[data-widget="groupselectone--ml-card-selector-glass"] .ml-select-item-highlighted {
  box-shadow: 0 0 0 3px rgba(199, 210, 254, 0.4);
}
groupselectone--ml-card-selector-glass .ml-card-option-error,
div[data-widget="groupselectone--ml-card-selector-glass"] .ml-card-option-error {
  border-color: var(--ml-outline-error, rgba(255, 120, 120, 0.7));
}
`);
        // O container do portal (document.body) recebe este data-widget — o .less do
        // tema escopa o conteúdo por div[data-widget="...-glass"].
        this.portalWidgetName = 'groupselectone--ml-card-selector-glass';
    }
};
MlCardSelectorGlass = __decorate([
    customElement('groupselectone--ml-card-selector-glass')
], MlCardSelectorGlass);
export { MlCardSelectorGlass };
