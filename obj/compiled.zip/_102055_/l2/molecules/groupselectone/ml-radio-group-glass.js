var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupselectone/ml-radio-group-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// RADIO GROUP — GLASSMORPHISM (mls-102055)
// =============================================================================
// Casca (estratégia D): herda tudo de MlRadioGroupMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência glass vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlRadioGroupMolecule } from '/_102040_/l2/molecules/groupselectone/ml-radio-group.js';
let MlRadioGroupGlass = class MlRadioGroupGlass extends MlRadioGroupMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupselectone--ml-radio-group-glass {
  display: block;
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-error: #ffb4ab;
  --ml-surface: rgba(255, 255, 255, 0.08);
  --ml-outline-variant: rgba(255, 255, 255, 0.22);
  --ml-outline-focus: rgba(199, 210, 254, 0.9);
  --ml-radius-md: 12px;
  --ml-border-width: 1px;
  --ml-transition: 200ms ease;
  --ml-backdrop-blur: 10px;
  --ml-disabled-opacity: 0.5;
  --ml-on-primary: #ffffff;
}
groupselectone--ml-radio-group-glass .ml-label {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  font-weight: 600;
  color: rgba(255, 255, 255, 0.92);
}
groupselectone--ml-radio-group-glass .ml-helper {
  color: rgba(255, 255, 255, 0.65);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupselectone--ml-radio-group-glass .ml-error-text {
  color: var(--ml-error, #ffb4ab);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupselectone--ml-radio-group-glass .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupselectone--ml-radio-group-glass .ml-select-group-label {
  color: rgba(255, 255, 255, 0.55);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupselectone--ml-radio-group-glass .ml-text {
  color: rgba(255, 255, 255, 0.95);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupselectone--ml-radio-group-glass [role='radio'] .ml-text {
  color: rgba(255, 255, 255, 0.9);
  transition: color 200ms ease;
}
groupselectone--ml-radio-group-glass div.ml-text-muted {
  color: rgba(255, 255, 255, 0.6);
}
groupselectone--ml-radio-group-glass span.ml-text-muted {
  color: rgba(255, 255, 255, 0.65);
}
groupselectone--ml-radio-group-glass .ml-text.ml-radio-label-selected {
  color: #ffffff;
  font-weight: 500;
}
groupselectone--ml-radio-group-glass .ml-text.ml-text-muted {
  color: rgba(255, 255, 255, 0.45);
}
groupselectone--ml-radio-group-glass .ml-radio-option {
  position: relative;
  border-radius: var(--ml-radius-md, 12px);
  border: var(--ml-border-width, 1px) solid var(--ml-outline-variant, rgba(255, 255, 255, 0.22));
  background: var(--ml-surface, rgba(255, 255, 255, 0.08));
  backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  transition: background var(--ml-transition, 200ms ease), border-color var(--ml-transition, 200ms ease), box-shadow var(--ml-transition, 200ms ease);
}
groupselectone--ml-radio-group-glass .ml-radio-option::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  border-top: 1px solid rgba(255, 255, 255, 0.5);
  border-left: 1px solid rgba(255, 255, 255, 0.25);
  pointer-events: none;
}
groupselectone--ml-radio-group-glass .ml-radio-option:hover:not(.ml-disabled):not(.ml-radio-option-selected) {
  background: rgba(255, 255, 255, 0.14);
}
groupselectone--ml-radio-group-glass .ml-radio-option-selected {
  background: rgba(99, 102, 241, 0.4);
  border-color: rgba(199, 210, 254, 0.8);
}
groupselectone--ml-radio-group-glass .ml-radio-option-focused {
  box-shadow: 0 0 0 2px rgba(199, 210, 254, 0.6);
}
groupselectone--ml-radio-group-glass .ml-radio-option-error {
  border-color: rgba(255, 120, 120, 0.8);
}
groupselectone--ml-radio-group-glass .ml-radio-dot {
  border-radius: 9999px;
  border: 2px solid rgba(255, 255, 255, 0.4);
  background: rgba(255, 255, 255, 0.1);
  transition: border-color 200ms ease, background 200ms ease;
}
groupselectone--ml-radio-group-glass .ml-radio-dot-selected {
  border-color: var(--ml-outline-focus, rgba(199, 210, 254, 0.9));
  background: rgba(99, 102, 241, 0.9);
}
groupselectone--ml-radio-group-glass .ml-radio-dot-inner {
  background: var(--ml-on-primary, #ffffff);
}
groupselectone--ml-radio-group-glass .ml-spinner {
  border-left-color: rgba(199, 210, 254, 0.9);
  border-right-color: rgba(199, 210, 254, 0.9);
  border-bottom-color: rgba(199, 210, 254, 0.9);
}
`);
    }
};
MlRadioGroupGlass = __decorate([
    customElement('groupselectone--ml-radio-group-glass')
], MlRadioGroupGlass);
export { MlRadioGroupGlass };
