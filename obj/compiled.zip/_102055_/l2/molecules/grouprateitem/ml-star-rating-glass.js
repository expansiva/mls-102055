var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/grouprateitem/ml-star-rating-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// STAR RATING — GLASSMORPHISM (mls-102055)
// =============================================================================
// Casca (estratégia D): herda tudo de MlStarRatingMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência glass vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlStarRatingMolecule } from '/_102040_/l2/molecules/grouprateitem/ml-star-rating.js';
let MlStarRatingGlass = class MlStarRatingGlass extends MlStarRatingMolecule {
};
MlStarRatingGlass = __decorate([
    customElement('grouprateitem--ml-star-rating-glass')
], MlStarRatingGlass);
export { MlStarRatingGlass };
