var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/grouprateitem/ml-star-rating-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// STAR RATING — GLASSMORPHISM (mls-102055)
// =============================================================================
// Casca (estratégia D): herda tudo de MlStarRatingMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência glass vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlStarRatingMolecule } from '/_102040_/l2/molecules/grouprateitem/ml-star-rating.js';
let MlStarRatingGlass = class MlStarRatingGlass extends MlStarRatingMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`grouprateitem--ml-star-rating-glass {
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-radius-md: 12px;
  --ml-outline-variant: rgba(255, 255, 255, 0.18);
  --ml-outline-focus: rgba(199, 210, 254, 0.9);
  --ml-outline-error: rgba(255, 120, 120, 0.7);
  --ml-surface: rgba(255, 255, 255, 0.07);
  --ml-on-surface: rgba(255, 255, 255, 0.7);
  --ml-on-surface-muted: rgba(255, 255, 255, 0.65);
  --ml-error: #ffb4ab;
  --ml-disabled-opacity: 0.5;
  --ml-backdrop-blur: 8px;
  --ml-focus-ring-width: 3px;
  --ml-focus-ring-color: rgba(199, 210, 254, 0.25);
  display: block;
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
grouprateitem--ml-star-rating-glass .ml-label {
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.7));
  display: block;
}
grouprateitem--ml-star-rating-glass .ml-helper {
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.65));
}
grouprateitem--ml-star-rating-glass .ml-error-text {
  color: var(--ml-error, #ffb4ab);
}
grouprateitem--ml-star-rating-glass .ml-text-muted {
  color: rgba(255, 255, 255, 0.45);
}
grouprateitem--ml-star-rating-glass .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
grouprateitem--ml-star-rating-glass .ml-surface {
  position: relative;
  width: fit-content;
  background: var(--ml-surface, rgba(255, 255, 255, 0.07));
  border-radius: var(--ml-radius-md, 12px);
  backdrop-filter: blur(var(--ml-backdrop-blur, 8px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur, 8px));
  transition: border-color 0.15s ease, box-shadow 0.15s ease;
}
grouprateitem--ml-star-rating-glass .ml-surface::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  border-top: 1px solid rgba(255, 255, 255, 0.5);
  border-left: 1px solid rgba(255, 255, 255, 0.25);
  pointer-events: none;
}
grouprateitem--ml-star-rating-glass .ml-border {
  border-color: var(--ml-outline-variant, rgba(255, 255, 255, 0.18));
}
grouprateitem--ml-star-rating-glass .ml-border-error {
  border-color: var(--ml-outline-error, rgba(255, 120, 120, 0.7));
}
grouprateitem--ml-star-rating-glass .ml-focus-within:focus-within {
  border-color: var(--ml-outline-focus, rgba(199, 210, 254, 0.9));
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) var(--ml-focus-ring-color, rgba(199, 210, 254, 0.25));
}
grouprateitem--ml-star-rating-glass .ml-rating-star-hover {
  background: transparent;
  border: none;
  border-radius: 8px;
  transition: background 0.12s ease;
}
grouprateitem--ml-star-rating-glass .ml-rating-star-hover:hover:not(.ml-disabled) {
  background: rgba(255, 255, 255, 0.08);
}
grouprateitem--ml-star-rating-glass .ml-rating-star-hover:focus-visible {
  outline: none;
  box-shadow: 0 0 0 2px rgba(199, 210, 254, 0.6);
}
grouprateitem--ml-star-rating-glass button.ml-rating-star-filled {
  background: rgba(199, 210, 254, 0.16);
}
grouprateitem--ml-star-rating-glass .ml-rating-star {
  color: rgba(255, 255, 255, 0.25);
}
grouprateitem--ml-star-rating-glass svg.ml-rating-star,
grouprateitem--ml-star-rating-glass svg.ml-rating-star-filled {
  transition: color 0.12s ease, filter 0.12s ease;
}
grouprateitem--ml-star-rating-glass svg.ml-rating-star-filled {
  color: #fbbf24;
  filter: drop-shadow(0 0 4px rgba(251, 191, 36, 0.5));
}
`);
    }
};
MlStarRatingGlass = __decorate([
    customElement('grouprateitem--ml-star-rating-glass')
], MlStarRatingGlass);
export { MlStarRatingGlass };
