var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupnavigatesteps/ml-wizard-steps-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// WIZARD STEPS — GLASSMORPHISM (mls-102055)
// =============================================================================
// Casca (estratégia D): herda tudo de MlWizardStepsMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência glass vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlWizardStepsMolecule } from '/_102040_/l2/molecules/groupnavigatesteps/ml-wizard-steps.js';
let MlWizardStepsGlass = class MlWizardStepsGlass extends MlWizardStepsMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupnavigatesteps--ml-wizard-steps-glass {
  display: block;
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-transition: 0.15s ease;
  --ml-backdrop-blur: 6px;
  --ml-radius-md: 12px;
  --ml-focus-ring-width: 3px;
  --ml-focus-ring-color: rgba(199, 210, 254, 0.4);
}
groupnavigatesteps--ml-wizard-steps-glass .ml-label {
  color: rgba(255, 255, 255, 0.85);
}
groupnavigatesteps--ml-wizard-steps-glass .ml-text {
  color: #fff;
}
groupnavigatesteps--ml-wizard-steps-glass .ml-text-muted {
  color: rgba(255, 255, 255, 0.55);
}
groupnavigatesteps--ml-wizard-steps-glass .ml-disabled {
  opacity: 0.5;
  cursor: not-allowed;
  pointer-events: none;
}
groupnavigatesteps--ml-wizard-steps-glass .ml-step {
  position: relative;
  overflow: hidden;
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.15);
  border-radius: var(--ml-radius-md, 12px);
  transition: background var(--ml-transition, 0.15s ease), border-color var(--ml-transition, 0.15s ease);
  backdrop-filter: blur(var(--ml-backdrop-blur, 6px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur, 6px));
}
groupnavigatesteps--ml-wizard-steps-glass .ml-step::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  border-top: 1px solid rgba(255, 255, 255, 0.5);
  border-left: 1px solid rgba(255, 255, 255, 0.25);
  pointer-events: none;
}
groupnavigatesteps--ml-wizard-steps-glass .ml-step:hover:not(.ml-disabled):not(.ml-step-active) {
  background: rgba(255, 255, 255, 0.1);
}
groupnavigatesteps--ml-wizard-steps-glass .ml-step:focus-visible {
  outline: none;
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) var(--ml-focus-ring-color, rgba(199, 210, 254, 0.4));
}
groupnavigatesteps--ml-wizard-steps-glass .ml-step:has(.ml-step-badge-done) {
  border-color: rgba(16, 185, 129, 0.5);
}
groupnavigatesteps--ml-wizard-steps-glass .ml-step-active {
  background: rgba(199, 210, 254, 0.16);
  border-color: rgba(199, 210, 254, 0.9);
}
groupnavigatesteps--ml-wizard-steps-glass .ml-step-container {
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.15);
  border-radius: 10px;
  color: rgba(255, 255, 255, 0.7);
}
groupnavigatesteps--ml-wizard-steps-glass .ml-step-badge {
  border: 1px solid rgba(255, 255, 255, 0.35);
  color: rgba(255, 255, 255, 0.6);
}
groupnavigatesteps--ml-wizard-steps-glass .ml-step-badge-active {
  border-color: rgba(199, 210, 254, 0.9);
  color: #e0e7ff;
}
groupnavigatesteps--ml-wizard-steps-glass .ml-step-badge-done {
  border-color: rgba(16, 185, 129, 0.7);
  color: #6ee7b7;
}
`);
    }
};
MlWizardStepsGlass = __decorate([
    customElement('groupnavigatesteps--ml-wizard-steps-glass')
], MlWizardStepsGlass);
export { MlWizardStepsGlass };
