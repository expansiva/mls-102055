var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// HORIZONTAL STEPPER — GLASSMORPHISM (mls-102055)
// =============================================================================
// Casca (estratégia D): herda tudo de MlHorizontalStepperMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência glass vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlHorizontalStepperMolecule } from '/_102040_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper.js';
let MlHorizontalStepperGlass = class MlHorizontalStepperGlass extends MlHorizontalStepperMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupnavigatesteps--ml-horizontal-stepper-glass {
  display: block;
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-transition: 0.15s ease;
  --ml-backdrop-blur: 6px;
  --ml-disabled-opacity: 0.6;
  --ml-focus-ring-width: 3px;
  --ml-focus-ring-color: rgba(199, 210, 254, 0.4);
  --ml-outline-variant: rgba(255, 255, 255, 0.25);
  --ml-outline-focus: rgba(199, 210, 254, 0.9);
  --ml-surface: rgba(255, 255, 255, 0.08);
  --ml-on-surface: rgba(255, 255, 255, 0.8);
  --ml-on-surface-muted: rgba(255, 255, 255, 0.55);
}
groupnavigatesteps--ml-horizontal-stepper-glass .ml-label {
  color: rgba(255, 255, 255, 0.85);
}
groupnavigatesteps--ml-horizontal-stepper-glass .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.6);
  cursor: not-allowed;
  pointer-events: none;
}
groupnavigatesteps--ml-horizontal-stepper-glass .ml-step-number {
  position: relative;
  overflow: hidden;
  border: 1px solid var(--ml-outline-variant, rgba(255, 255, 255, 0.25));
  background: var(--ml-surface, rgba(255, 255, 255, 0.08));
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.8));
  transition: background var(--ml-transition, 0.15s ease), border-color var(--ml-transition, 0.15s ease), color var(--ml-transition, 0.15s ease), box-shadow var(--ml-transition, 0.15s ease);
  backdrop-filter: blur(var(--ml-backdrop-blur, 6px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur, 6px));
}
groupnavigatesteps--ml-horizontal-stepper-glass .ml-step-number::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  border-top: 1px solid rgba(255, 255, 255, 0.5);
  border-left: 1px solid rgba(255, 255, 255, 0.25);
  pointer-events: none;
}
groupnavigatesteps--ml-horizontal-stepper-glass .ml-step-number:hover:not(.ml-disabled):not(.ml-step-active) {
  background: rgba(255, 255, 255, 0.14);
}
groupnavigatesteps--ml-horizontal-stepper-glass .ml-step-number:focus-visible {
  outline: none;
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) var(--ml-focus-ring-color, rgba(199, 210, 254, 0.4));
}
groupnavigatesteps--ml-horizontal-stepper-glass .ml-step-number.ml-disabled {
  opacity: 0.5;
}
groupnavigatesteps--ml-horizontal-stepper-glass .ml-step-active {
  background: rgba(199, 210, 254, 0.2);
  border-color: var(--ml-outline-focus, rgba(199, 210, 254, 0.9));
  color: #e0e7ff;
}
groupnavigatesteps--ml-horizontal-stepper-glass .ml-step-completed {
  background: rgba(16, 185, 129, 0.18);
  border-color: rgba(16, 185, 129, 0.6);
  color: #6ee7b7;
}
groupnavigatesteps--ml-horizontal-stepper-glass .ml-text {
  color: rgba(255, 255, 255, 0.8);
}
groupnavigatesteps--ml-horizontal-stepper-glass .ml-step-active-text {
  color: #e0e7ff;
}
groupnavigatesteps--ml-horizontal-stepper-glass .ml-text-muted {
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.55));
}
groupnavigatesteps--ml-horizontal-stepper-glass .ml-text-muted.text-sm {
  color: rgba(255, 255, 255, 0.7);
}
groupnavigatesteps--ml-horizontal-stepper-glass .ml-text.ml-text-muted,
groupnavigatesteps--ml-horizontal-stepper-glass .ml-step-active-text.ml-text-muted {
  color: rgba(255, 255, 255, 0.4);
}
groupnavigatesteps--ml-horizontal-stepper-glass .ml-step-connector {
  background: rgba(255, 255, 255, 0.2);
  transition: background 0.2s ease;
}
groupnavigatesteps--ml-horizontal-stepper-glass .ml-step-connector-completed {
  background: rgba(16, 185, 129, 0.6);
}
groupnavigatesteps--ml-horizontal-stepper-glass .ml-step-loading-dot {
  background: rgba(255, 255, 255, 0.5);
}
`);
    }
};
MlHorizontalStepperGlass = __decorate([
    customElement('groupnavigatesteps--ml-horizontal-stepper-glass')
], MlHorizontalStepperGlass);
export { MlHorizontalStepperGlass };
