var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupnotifyuser/ml-alert-modal-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ALERT MODAL — GLASSMORPHISM (mls-102055)
// =============================================================================
// Casca (estratégia D): herda tudo de MlAlertModalMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência glass vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlAlertModalMolecule } from '/_102040_/l2/molecules/groupnotifyuser/ml-alert-modal.js';
let MlAlertModalGlass = class MlAlertModalGlass extends MlAlertModalMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupnotifyuser--ml-alert-modal-glass {
  display: contents;
  font-family: 'Inter', system-ui, sans-serif;
  --ml-radius-lg: 20px;
  --ml-backdrop-blur-strong: 20px;
  --ml-outline-variant: rgba(255, 255, 255, 0.22);
}
groupnotifyuser--ml-alert-modal-glass .ml-surface-bg\/40 {
  background: rgba(8, 10, 25, 0.45);
  backdrop-filter: blur(6px);
  -webkit-backdrop-filter: blur(6px);
}
groupnotifyuser--ml-alert-modal-glass .ml-surface-bg {
  border-radius: var(--ml-radius-lg, 20px);
  background: rgba(30, 27, 75, 0.8);
  backdrop-filter: blur(var(--ml-backdrop-blur-strong, 20px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur-strong, 20px));
  box-shadow: 0 24px 60px rgba(0, 0, 0, 0.5), inset 0 1px 0 rgba(255, 255, 255, 0.3);
}
groupnotifyuser--ml-alert-modal-glass .ml-border-info,
groupnotifyuser--ml-alert-modal-glass .ml-border-success,
groupnotifyuser--ml-alert-modal-glass .ml-border-warning,
groupnotifyuser--ml-alert-modal-glass .ml-border-error {
  border-color: var(--ml-outline-variant, rgba(255, 255, 255, 0.22));
  border-top-width: 3px;
}
groupnotifyuser--ml-alert-modal-glass .ml-border-info {
  border-top-color: rgba(199, 210, 254, 0.8);
}
groupnotifyuser--ml-alert-modal-glass .ml-border-success {
  border-top-color: rgba(110, 231, 183, 0.8);
}
groupnotifyuser--ml-alert-modal-glass .ml-border-warning {
  border-top-color: rgba(252, 211, 77, 0.8);
}
groupnotifyuser--ml-alert-modal-glass .ml-border-error {
  border-top-color: rgba(252, 165, 165, 0.85);
}
groupnotifyuser--ml-alert-modal-glass .ml-surface-bg.ml-text {
  color: rgba(255, 255, 255, 0.92);
}
groupnotifyuser--ml-alert-modal-glass h3.ml-text {
  color: #fff;
}
groupnotifyuser--ml-alert-modal-glass .ml-text {
  color: rgba(255, 255, 255, 0.82);
}
groupnotifyuser--ml-alert-modal-glass .ml-primary-text {
  color: #c7d2fe;
}
groupnotifyuser--ml-alert-modal-glass .ml-primary-dim-bg {
  background: rgba(56, 70, 140, 0.5);
  border: 1px solid rgba(255, 255, 255, 0.2);
}
groupnotifyuser--ml-alert-modal-glass .ml-success-text {
  color: #6ee7b7;
}
groupnotifyuser--ml-alert-modal-glass .ml-success-dim-bg {
  background: rgba(16, 100, 70, 0.45);
  border: 1px solid rgba(255, 255, 255, 0.2);
}
groupnotifyuser--ml-alert-modal-glass .ml-warning-text {
  color: #fcd34d;
}
groupnotifyuser--ml-alert-modal-glass .ml-warning-dim-bg {
  background: rgba(120, 90, 20, 0.45);
  border: 1px solid rgba(255, 255, 255, 0.2);
}
groupnotifyuser--ml-alert-modal-glass .ml-error-text {
  color: #fca5a5;
}
groupnotifyuser--ml-alert-modal-glass .ml-error-dim-bg {
  background: rgba(130, 40, 50, 0.5);
  border: 1px solid rgba(255, 255, 255, 0.2);
}
groupnotifyuser--ml-alert-modal-glass .ml-text-muted {
  color: rgba(255, 255, 255, 0.7);
  background: transparent;
  border: none;
  cursor: pointer;
  border-radius: 8px;
  padding: 0.25rem;
  transition: background 150ms ease, color 150ms ease;
}
groupnotifyuser--ml-alert-modal-glass .ml-text-muted:hover {
  background: rgba(255, 255, 255, 0.15);
}
groupnotifyuser--ml-alert-modal-glass .hover\:ml-text:hover {
  color: #fff;
}
`);
    }
};
MlAlertModalGlass = __decorate([
    customElement('groupnotifyuser--ml-alert-modal-glass')
], MlAlertModalGlass);
export { MlAlertModalGlass };
