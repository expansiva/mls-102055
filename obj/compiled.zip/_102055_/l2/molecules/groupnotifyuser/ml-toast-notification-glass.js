var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupnotifyuser/ml-toast-notification-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// TOAST NOTIFICATION — GLASSMORPHISM (mls-102055)
// =============================================================================
// Casca (estratégia D): herda tudo de ToastNotificationMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência glass vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { ToastNotificationMolecule } from '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification.js';
let ToastNotificationGlass = class ToastNotificationGlass extends ToastNotificationMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupnotifyuser--ml-toast-notification-glass {
  display: contents;
  font-family: 'Inter', system-ui, sans-serif;
  --ml-radius-lg: 14px;
  --ml-backdrop-blur-strong: 16px;
  --ml-outline-variant: rgba(255, 255, 255, 0.22);
}
groupnotifyuser--ml-toast-notification-glass .ml-primary-dim-bg,
groupnotifyuser--ml-toast-notification-glass .ml-success-dim-bg,
groupnotifyuser--ml-toast-notification-glass .ml-warning-dim-bg,
groupnotifyuser--ml-toast-notification-glass .ml-error-dim-bg {
  border-radius: var(--ml-radius-lg, 14px);
  backdrop-filter: blur(var(--ml-backdrop-blur-strong, 16px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur-strong, 16px));
  box-shadow: 0 14px 40px rgba(0, 0, 0, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.3);
  color: rgba(255, 255, 255, 0.92);
}
groupnotifyuser--ml-toast-notification-glass .ml-primary-dim-bg {
  background: rgba(40, 50, 110, 0.8);
}
groupnotifyuser--ml-toast-notification-glass .ml-success-dim-bg {
  background: rgba(16, 80, 60, 0.8);
}
groupnotifyuser--ml-toast-notification-glass .ml-warning-dim-bg {
  background: rgba(100, 75, 18, 0.8);
}
groupnotifyuser--ml-toast-notification-glass .ml-error-dim-bg {
  background: rgba(110, 35, 45, 0.82);
}
groupnotifyuser--ml-toast-notification-glass .ml-border-info,
groupnotifyuser--ml-toast-notification-glass .ml-border-success,
groupnotifyuser--ml-toast-notification-glass .ml-border-warning,
groupnotifyuser--ml-toast-notification-glass .ml-border-error {
  border-color: var(--ml-outline-variant, rgba(255, 255, 255, 0.22));
}
groupnotifyuser--ml-toast-notification-glass .font-semibold.ml-text {
  color: #fff;
}
groupnotifyuser--ml-toast-notification-glass .ml-text {
  color: rgba(255, 255, 255, 0.82);
}
groupnotifyuser--ml-toast-notification-glass .ml-primary-text {
  color: #c7d2fe;
}
groupnotifyuser--ml-toast-notification-glass .ml-success-text {
  color: #6ee7b7;
}
groupnotifyuser--ml-toast-notification-glass .ml-warning-text {
  color: #fcd34d;
}
groupnotifyuser--ml-toast-notification-glass .ml-error-text {
  color: #fca5a5;
}
groupnotifyuser--ml-toast-notification-glass .cursor-pointer.ml-primary-text:hover,
groupnotifyuser--ml-toast-notification-glass .cursor-pointer.ml-success-text:hover,
groupnotifyuser--ml-toast-notification-glass .cursor-pointer.ml-warning-text:hover,
groupnotifyuser--ml-toast-notification-glass .cursor-pointer.ml-error-text:hover {
  text-decoration: underline;
}
groupnotifyuser--ml-toast-notification-glass .ml-text-faint {
  color: rgba(255, 255, 255, 0.7);
  background: transparent;
  border: none;
  cursor: pointer;
}
groupnotifyuser--ml-toast-notification-glass .hover\:ml-text-muted:hover {
  color: #fff;
}
groupnotifyuser--ml-toast-notification-glass .hover\:ml-surface-dim-bg:hover {
  background: rgba(255, 255, 255, 0.15);
}
groupnotifyuser--ml-toast-notification-glass .ml-text-faint:focus-visible {
  outline: none;
  box-shadow: 0 0 0 2px rgba(199, 210, 254, 0.7);
}
`);
    }
};
ToastNotificationGlass = __decorate([
    customElement('groupnotifyuser--ml-toast-notification-glass')
], ToastNotificationGlass);
export { ToastNotificationGlass };
