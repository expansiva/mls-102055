var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupnotifyuser/ml-notify-banner-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// NOTIFY BANNER — GLASSMORPHISM (mls-102055)
// =============================================================================
// Casca (estratégia D): herda tudo de NotifyBannerMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência glass vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { NotifyBannerMolecule } from '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner.js';
let NotifyBannerGlass = class NotifyBannerGlass extends NotifyBannerMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupnotifyuser--ml-notify-banner-glass {
  display: contents;
  font-family: 'Inter', system-ui, sans-serif;
  --ml-radius-lg: 14px;
  --ml-backdrop-blur-strong: 16px;
  --ml-outline-variant: rgba(255, 255, 255, 0.22);
}
groupnotifyuser--ml-notify-banner-glass .ml-primary-dim-bg,
groupnotifyuser--ml-notify-banner-glass .ml-success-dim-bg,
groupnotifyuser--ml-notify-banner-glass .ml-warning-dim-bg,
groupnotifyuser--ml-notify-banner-glass .ml-error-dim-bg {
  border-radius: var(--ml-radius-lg, 14px);
  backdrop-filter: blur(var(--ml-backdrop-blur-strong, 16px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur-strong, 16px));
  box-shadow: 0 12px 36px rgba(0, 0, 0, 0.32), inset 0 1px 0 rgba(255, 255, 255, 0.3);
}
groupnotifyuser--ml-notify-banner-glass .ml-primary-dim-bg {
  background: rgba(56, 70, 140, 0.55);
}
groupnotifyuser--ml-notify-banner-glass .ml-success-dim-bg {
  background: rgba(16, 100, 70, 0.5);
}
groupnotifyuser--ml-notify-banner-glass .ml-warning-dim-bg {
  background: rgba(120, 90, 20, 0.5);
}
groupnotifyuser--ml-notify-banner-glass .ml-error-dim-bg {
  background: rgba(130, 40, 50, 0.55);
}
groupnotifyuser--ml-notify-banner-glass .ml-border-info,
groupnotifyuser--ml-notify-banner-glass .ml-border-success,
groupnotifyuser--ml-notify-banner-glass .ml-border-warning,
groupnotifyuser--ml-notify-banner-glass .ml-border-error {
  border-color: var(--ml-outline-variant, rgba(255, 255, 255, 0.22));
}
groupnotifyuser--ml-notify-banner-glass .ml-primary-dim-bg.ml-text,
groupnotifyuser--ml-notify-banner-glass .ml-success-dim-bg.ml-text,
groupnotifyuser--ml-notify-banner-glass .ml-warning-dim-bg.ml-text,
groupnotifyuser--ml-notify-banner-glass .ml-error-dim-bg.ml-text {
  color: rgba(255, 255, 255, 0.92);
}
groupnotifyuser--ml-notify-banner-glass .font-semibold.ml-text {
  color: #fff;
}
groupnotifyuser--ml-notify-banner-glass .ml-text {
  color: rgba(255, 255, 255, 0.82);
}
groupnotifyuser--ml-notify-banner-glass .ml-primary-text {
  color: #c7d2fe;
}
groupnotifyuser--ml-notify-banner-glass .ml-success-text {
  color: #6ee7b7;
}
groupnotifyuser--ml-notify-banner-glass .ml-warning-text {
  color: #fcd34d;
}
groupnotifyuser--ml-notify-banner-glass .ml-error-text {
  color: #fca5a5;
}
groupnotifyuser--ml-notify-banner-glass .cursor-pointer.ml-primary-text:hover {
  text-decoration: underline;
}
groupnotifyuser--ml-notify-banner-glass .ml-text-muted {
  color: rgba(255, 255, 255, 0.7);
  background: transparent;
  border: none;
  cursor: pointer;
  transition: background 150ms ease, color 150ms ease;
}
groupnotifyuser--ml-notify-banner-glass .hover\:ml-surface-dim-bg:hover {
  background: rgba(255, 255, 255, 0.15);
  color: #fff;
}
groupnotifyuser--ml-notify-banner-glass .ml-text-muted:focus-visible {
  outline: none;
  box-shadow: 0 0 0 2px rgba(199, 210, 254, 0.7);
}
`);
    }
};
NotifyBannerGlass = __decorate([
    customElement('groupnotifyuser--ml-notify-banner-glass')
], NotifyBannerGlass);
export { NotifyBannerGlass };
