var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/grouptriggeraction/ml-icon-button-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ICON BUTTON — GLASSMORPHISM (mls-102055) — Strategy D shell
// =============================================================================
// Skill Group: groupTriggerAction
// Herda IconButtonMolecule (mls-102040) sem sobrescrever render():
// o render() herdado emite classes semânticas ml-*; toda a aparência
// glass vive no .less homônimo, escopado sob a tag -glass.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { IconButtonMolecule } from '/_102040_/l2/molecules/grouptriggeraction/ml-icon-button.js';
let IconButtonGlass = class IconButtonGlass extends IconButtonMolecule {
};
IconButtonGlass = __decorate([
    customElement('grouptriggeraction--ml-icon-button-glass')
], IconButtonGlass);
export { IconButtonGlass };
