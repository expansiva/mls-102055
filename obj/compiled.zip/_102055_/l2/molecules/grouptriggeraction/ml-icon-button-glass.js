var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/grouptriggeraction/ml-icon-button-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ICON BUTTON — GLASSMORPHISM (mls-102055) — Strategy D shell
// =============================================================================
// Skill Group: groupTriggerAction
// Herda IconButtonMolecule (mls-102040) sem sobrescrever render():
// o render() herdado emite classes semânticas ml-*; toda a aparência
// glass vive no .less homônimo, escopado sob a tag -glass.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { IconButtonMolecule } from '/_102040_/l2/molecules/grouptriggeraction/ml-icon-button.js';
let IconButtonGlass = class IconButtonGlass extends IconButtonMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`grouptriggeraction--ml-icon-button-glass {
  display: inline-block;
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-font-weight-medium: 600;
  --ml-radius-sm: 10px;
  --ml-border-width: 1px;
  --ml-outline-variant: rgba(255, 255, 255, 0.25);
  --ml-surface: rgba(255, 255, 255, 0.1);
  --ml-on-surface: #ffffff;
  --ml-shadow-1: 0 4px 14px rgba(0, 0, 0, 0.16);
  --ml-transition: 200ms ease;
  --ml-focus-ring-width: 3px;
  --ml-focus-ring-color: rgba(199, 210, 254, 0.5);
  --ml-disabled-opacity: 0.5;
  --ml-backdrop-blur: 10px;
}
grouptriggeraction--ml-icon-button-glass .ml-button {
  position: relative;
  overflow: hidden;
  appearance: none;
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  font-weight: var(--ml-font-weight-medium, 600);
  border-radius: var(--ml-radius-sm, 10px);
  backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  box-shadow: var(--ml-shadow-1, 0 4px 14px rgba(0, 0, 0, 0.16));
  cursor: pointer;
  transition: background var(--ml-transition, 200ms ease), box-shadow var(--ml-transition, 200ms ease), border-color var(--ml-transition, 200ms ease), transform 120ms ease;
}
grouptriggeraction--ml-icon-button-glass .ml-button::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  border-top: 1px solid rgba(255, 255, 255, 0.5);
  border-left: 1px solid rgba(255, 255, 255, 0.25);
  pointer-events: none;
}
grouptriggeraction--ml-icon-button-glass .ml-button:focus-visible {
  outline: none;
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) var(--ml-focus-ring-color, rgba(199, 210, 254, 0.5));
}
grouptriggeraction--ml-icon-button-glass .ml-button-secondary {
  background: var(--ml-surface, rgba(255, 255, 255, 0.1));
  color: var(--ml-on-surface, #ffffff);
  border: var(--ml-border-width, 1px) solid var(--ml-outline-variant, rgba(255, 255, 255, 0.25));
}
grouptriggeraction--ml-icon-button-glass .ml-button-secondary:not(.ml-disabled):hover {
  background: rgba(255, 255, 255, 0.18);
}
grouptriggeraction--ml-icon-button-glass .ml-button-secondary:not(.ml-disabled):active {
  transform: translateY(1px);
}
grouptriggeraction--ml-icon-button-glass .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
grouptriggeraction--ml-icon-button-glass .ml-button > span[aria-hidden='true'] {
  color: rgba(255, 255, 255, 0.92);
  padding: 22%;
}
`);
    }
};
IconButtonGlass = __decorate([
    customElement('grouptriggeraction--ml-icon-button-glass')
], IconButtonGlass);
export { IconButtonGlass };
