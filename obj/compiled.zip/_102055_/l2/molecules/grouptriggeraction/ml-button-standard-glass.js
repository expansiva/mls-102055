var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/grouptriggeraction/ml-button-standard-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// BUTTON STANDARD — GLASSMORPHISM (mls-102055)
// =============================================================================
// Skill Group: groupTriggerAction
// Casca (estratégia D): herda tudo de ButtonStandardMolecule (mls-102040),
// inclusive render() — o markup base emite classes semânticas ml-*; a aparência
// glass vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { ButtonStandardMolecule } from '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard.js';
let ButtonStandardGlass = class ButtonStandardGlass extends ButtonStandardMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`grouptriggeraction--ml-button-standard-glass {
  display: inline-block;
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-font-weight-medium: 600;
  --ml-radius-sm: 12px;
  --ml-border-width: 1px;
  --ml-border-style: solid;
  --ml-outline-variant: rgba(255, 255, 255, 0.25);
  --ml-primary: rgba(99, 102, 241, 0.55);
  --ml-on-primary: #ffffff;
  --ml-surface: rgba(255, 255, 255, 0.14);
  --ml-error: rgba(244, 63, 94, 0.55);
  --ml-shadow-1: 0 4px 18px rgba(0, 0, 0, 0.18);
  --ml-shadow-2: 0 6px 24px rgba(0, 0, 0, 0.26);
  --ml-transition: 250ms ease;
  --ml-focus-ring-width: 3px;
  --ml-focus-ring-color: rgba(255, 255, 255, 0.5);
  --ml-disabled-opacity: 0.5;
  --ml-backdrop-blur: 10px;
}
grouptriggeraction--ml-button-standard-glass .ml-button {
  position: relative;
  overflow: hidden;
  border-radius: var(--ml-radius-sm, 12px);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, rgba(255, 255, 255, 0.25));
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  font-weight: var(--ml-font-weight-medium, 600);
  color: var(--ml-on-primary, #ffffff);
  backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  box-shadow: var(--ml-shadow-1, 0 4px 18px rgba(0, 0, 0, 0.18));
  transition: background var(--ml-transition, 250ms ease), border-color var(--ml-transition, 250ms ease), box-shadow var(--ml-transition, 250ms ease), transform 120ms ease;
  cursor: pointer;
}
grouptriggeraction--ml-button-standard-glass .ml-button::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  border-top: 1px solid rgba(255, 255, 255, 0.5);
  border-left: 1px solid rgba(255, 255, 255, 0.25);
  pointer-events: none;
}
grouptriggeraction--ml-button-standard-glass .ml-button:focus-visible {
  outline: none;
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) var(--ml-focus-ring-color, rgba(255, 255, 255, 0.5)), var(--ml-shadow-1, 0 4px 18px rgba(0, 0, 0, 0.18));
}
grouptriggeraction--ml-button-standard-glass .ml-button:not(.ml-disabled):hover {
  box-shadow: var(--ml-shadow-2, 0 6px 24px rgba(0, 0, 0, 0.26));
}
grouptriggeraction--ml-button-standard-glass .ml-button:not(.ml-disabled):active {
  transform: translateY(1px);
}
grouptriggeraction--ml-button-standard-glass .ml-button-primary {
  background: var(--ml-primary, rgba(99, 102, 241, 0.55));
}
grouptriggeraction--ml-button-standard-glass .ml-button-primary:not(.ml-disabled):hover {
  background: rgba(99, 102, 241, 0.68);
}
grouptriggeraction--ml-button-standard-glass .ml-button-secondary {
  background: var(--ml-surface, rgba(255, 255, 255, 0.14));
}
grouptriggeraction--ml-button-standard-glass .ml-button-secondary:not(.ml-disabled):hover {
  background: rgba(255, 255, 255, 0.22);
}
grouptriggeraction--ml-button-standard-glass .ml-button-danger {
  background: var(--ml-error, rgba(244, 63, 94, 0.55));
}
grouptriggeraction--ml-button-standard-glass .ml-button-danger:not(.ml-disabled):hover {
  background: rgba(244, 63, 94, 0.68);
}
grouptriggeraction--ml-button-standard-glass .ml-button-ghost {
  background: rgba(255, 255, 255, 0.04);
  border-color: rgba(255, 255, 255, 0.15);
}
grouptriggeraction--ml-button-standard-glass .ml-button-ghost:not(.ml-disabled):hover {
  background: rgba(255, 255, 255, 0.12);
}
grouptriggeraction--ml-button-standard-glass .ml-button-link {
  background: transparent;
  border-color: transparent;
  backdrop-filter: none;
  -webkit-backdrop-filter: none;
  box-shadow: none;
  color: #c7d2fe;
}
grouptriggeraction--ml-button-standard-glass .ml-button-link::before {
  display: none;
}
grouptriggeraction--ml-button-standard-glass .ml-button-link:not(.ml-disabled):hover {
  text-decoration: underline;
  box-shadow: none;
}
grouptriggeraction--ml-button-standard-glass .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
    }
};
ButtonStandardGlass = __decorate([
    customElement('grouptriggeraction--ml-button-standard-glass')
], ButtonStandardGlass);
export { ButtonStandardGlass };
