var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/grouptriggeraction/ml-split-button-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// SPLIT BUTTON — GLASSMORPHISM (mls-102055)
// =============================================================================
// Casca (estratégia D): herda tudo de MlSplitButtonMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência glass vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlSplitButtonMolecule } from '/_102040_/l2/molecules/grouptriggeraction/ml-split-button.js';
let MlSplitButtonGlass = class MlSplitButtonGlass extends MlSplitButtonMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`grouptriggeraction--ml-split-button-glass {
  display: inline-block;
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-font-weight-medium: 600;
  --ml-radius-sm: 12px;
  --ml-radius-lg: 12px;
  --ml-border-width: 1px;
  --ml-outline-variant: rgba(255, 255, 255, 0.25);
  --ml-primary: rgba(99, 102, 241, 0.5);
  --ml-on-primary: #ffffff;
  --ml-on-surface: rgba(255, 255, 255, 0.9);
  --ml-surface-dim: rgba(30, 27, 75, 0.85);
  --ml-transition: 200ms ease;
  --ml-focus-ring-width: 3px;
  --ml-focus-ring-color: rgba(199, 210, 254, 0.5);
  --ml-disabled-opacity: 0.5;
  --ml-backdrop-blur: 10px;
  --ml-backdrop-blur-strong: 18px;
}
grouptriggeraction--ml-split-button-glass .ml-split-trigger,
grouptriggeraction--ml-split-button-glass .ml-split-dropdown {
  border: var(--ml-border-width, 1px) solid var(--ml-outline-variant, rgba(255, 255, 255, 0.25));
  background: var(--ml-primary, rgba(99, 102, 241, 0.5));
  color: var(--ml-on-primary, #ffffff);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  cursor: pointer;
  transition: background var(--ml-transition, 200ms ease), box-shadow var(--ml-transition, 200ms ease), transform 120ms ease;
}
grouptriggeraction--ml-split-button-glass .ml-split-trigger:not(.ml-disabled):hover,
grouptriggeraction--ml-split-button-glass .ml-split-dropdown:not(.ml-disabled):hover {
  background: rgba(99, 102, 241, 0.64);
}
grouptriggeraction--ml-split-button-glass .ml-split-trigger:not(.ml-disabled):active,
grouptriggeraction--ml-split-button-glass .ml-split-dropdown:not(.ml-disabled):active {
  transform: translateY(1px);
}
grouptriggeraction--ml-split-button-glass .ml-split-trigger:focus-visible,
grouptriggeraction--ml-split-button-glass .ml-split-dropdown:focus-visible {
  outline: none;
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) var(--ml-focus-ring-color, rgba(199, 210, 254, 0.5));
}
grouptriggeraction--ml-split-button-glass .ml-split-trigger {
  position: relative;
  overflow: hidden;
  border-radius: var(--ml-radius-sm, 12px) 0 0 var(--ml-radius-sm, 12px);
  font-weight: var(--ml-font-weight-medium, 600);
}
grouptriggeraction--ml-split-button-glass .ml-split-trigger::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  border-top: 1px solid rgba(255, 255, 255, 0.5);
  border-left: 1px solid rgba(255, 255, 255, 0.25);
  pointer-events: none;
}
grouptriggeraction--ml-split-button-glass .ml-split-dropdown {
  border-radius: 0 var(--ml-radius-sm, 12px) var(--ml-radius-sm, 12px) 0;
  border-left: 1px solid rgba(255, 255, 255, 0.35);
  margin-left: -1px;
}
grouptriggeraction--ml-split-button-glass .ml-split-menu {
  border: var(--ml-border-width, 1px) solid rgba(255, 255, 255, 0.2);
  border-radius: var(--ml-radius-lg, 12px);
  background: var(--ml-surface-dim, rgba(30, 27, 75, 0.85));
  backdrop-filter: blur(var(--ml-backdrop-blur-strong, 18px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur-strong, 18px));
  box-shadow: 0 16px 44px rgba(0, 0, 0, 0.45), inset 0 1px 0 rgba(255, 255, 255, 0.3);
}
grouptriggeraction--ml-split-button-glass .ml-split-item {
  border-radius: 8px;
  border: none;
  background: transparent;
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.9));
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  cursor: pointer;
  transition: background 150ms ease;
}
grouptriggeraction--ml-split-button-glass .ml-split-item:not(.ml-disabled):hover {
  background: rgba(255, 255, 255, 0.12);
}
grouptriggeraction--ml-split-button-glass .ml-split-item.ml-disabled {
  opacity: 0.45;
}
grouptriggeraction--ml-split-button-glass .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
    }
};
MlSplitButtonGlass = __decorate([
    customElement('grouptriggeraction--ml-split-button-glass')
], MlSplitButtonGlass);
export { MlSplitButtonGlass };
