var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// FILE UPLOAD DROPZONE — GLASSMORPHISM (mls-102055)
// =============================================================================
// Casca (estratégia D): herda tudo de MlFileUploadDropzoneMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência glass vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlFileUploadDropzoneMolecule } from '/_102040_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone.js';
let MlFileUploadDropzoneGlass = class MlFileUploadDropzoneGlass extends MlFileUploadDropzoneMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupselectfileforupload--ml-file-upload-dropzone-glass {
  display: block;
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-error: #ffb4ab;
  --ml-outline-variant: rgba(255, 255, 255, 0.3);
  --ml-outline-error: rgba(255, 120, 120, 0.7);
  --ml-outline-focus: rgba(199, 210, 254, 0.9);
  --ml-radius-lg: 14px;
  --ml-focus-ring-width: 3px;
  --ml-focus-ring-color: rgba(199, 210, 254, 0.4);
  --ml-disabled-opacity: 0.5;
  --ml-backdrop-blur: 8px;
}
groupselectfileforupload--ml-file-upload-dropzone-glass label.ml-label {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  color: rgba(255, 255, 255, 0.85);
}
groupselectfileforupload--ml-file-upload-dropzone-glass div.ml-label {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  color: rgba(255, 255, 255, 0.9);
}
groupselectfileforupload--ml-file-upload-dropzone-glass .ml-helper {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  color: rgba(255, 255, 255, 0.65);
}
groupselectfileforupload--ml-file-upload-dropzone-glass .ml-error-text {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  color: var(--ml-error, #ffb4ab);
}
groupselectfileforupload--ml-file-upload-dropzone-glass .ml-text {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  color: #ffffff;
}
groupselectfileforupload--ml-file-upload-dropzone-glass .ml-text-muted {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  color: rgba(255, 255, 255, 0.6);
}
groupselectfileforupload--ml-file-upload-dropzone-glass .ml-dropzone .ml-text-muted {
  color: rgba(255, 255, 255, 0.55);
}
groupselectfileforupload--ml-file-upload-dropzone-glass .ml-dropzone > .ml-text-muted {
  color: rgba(255, 255, 255, 0.7);
}
groupselectfileforupload--ml-file-upload-dropzone-glass .ml-dropzone-file-item .ml-text-muted {
  color: rgba(255, 255, 255, 0.55);
}
groupselectfileforupload--ml-file-upload-dropzone-glass .ml-dropzone-file-item .ml-text-muted.ml-dropzone-file-remove {
  color: rgba(255, 255, 255, 0.7);
  cursor: pointer;
  transition: color 0.12s ease;
}
groupselectfileforupload--ml-file-upload-dropzone-glass .ml-dropzone-file-item .ml-text-muted.ml-dropzone-file-remove:hover {
  color: #ffffff;
}
groupselectfileforupload--ml-file-upload-dropzone-glass .ml-dropzone-file-item .ml-text-muted.ml-dropzone-file-remove:disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
}
groupselectfileforupload--ml-file-upload-dropzone-glass .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupselectfileforupload--ml-file-upload-dropzone-glass .ml-dropzone {
  background: rgba(255, 255, 255, 0.05);
  border-color: var(--ml-outline-variant, rgba(255, 255, 255, 0.3));
  border-radius: var(--ml-radius-lg, 14px);
  color: #ffffff;
  transition: border-color 0.15s ease, background 0.15s ease, box-shadow 0.15s ease;
  backdrop-filter: blur(var(--ml-backdrop-blur, 8px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur, 8px));
}
groupselectfileforupload--ml-file-upload-dropzone-glass .ml-dropzone:focus-visible {
  outline: none;
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) var(--ml-focus-ring-color, rgba(199, 210, 254, 0.4));
}
groupselectfileforupload--ml-file-upload-dropzone-glass .ml-dropzone-active {
  border-color: var(--ml-outline-focus, rgba(199, 210, 254, 0.9));
  background: rgba(199, 210, 254, 0.12);
}
groupselectfileforupload--ml-file-upload-dropzone-glass .ml-dropzone-error {
  border-color: var(--ml-outline-error, rgba(255, 120, 120, 0.7)) !important;
}
groupselectfileforupload--ml-file-upload-dropzone-glass .ml-dropzone-icon {
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  color: rgba(255, 255, 255, 0.85);
}
groupselectfileforupload--ml-file-upload-dropzone-glass .ml-dropzone-file-item {
  background: rgba(255, 255, 255, 0.07);
  border-color: rgba(255, 255, 255, 0.15);
  border-radius: 10px;
  backdrop-filter: blur(6px);
  -webkit-backdrop-filter: blur(6px);
}
`);
    }
};
MlFileUploadDropzoneGlass = __decorate([
    customElement('groupselectfileforupload--ml-file-upload-dropzone-glass')
], MlFileUploadDropzoneGlass);
export { MlFileUploadDropzoneGlass };
