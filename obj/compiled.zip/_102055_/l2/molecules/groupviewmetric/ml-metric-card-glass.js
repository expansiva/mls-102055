var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupviewmetric/ml-metric-card-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// METRIC CARD — GLASSMORPHISM (mls-102055)
// =============================================================================
// Casca (estratégia D): herda tudo de MetricCardMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência glass vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MetricCardMolecule } from '/_102040_/l2/molecules/groupviewmetric/ml-metric-card.js';
let MetricCardGlass = class MetricCardGlass extends MetricCardMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupviewmetric--ml-metric-card-glass {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-radius-lg: 16px;
  --ml-outline-variant: rgba(255, 255, 255, 0.15);
  --ml-surface: rgba(255, 255, 255, 0.07);
  --ml-on-surface: #fff;
  --ml-on-surface-muted: rgba(255, 255, 255, 0.7);
  --ml-success: #6ee7b7;
  --ml-error: #fca5a5;
  --ml-backdrop-blur: 10px;
  --ml-shadow-1: 0 8px 24px rgba(0, 0, 0, 0.25);
}
groupviewmetric--ml-metric-card-glass .ml-surface-bg.ml-border.ml-text {
  position: relative;
  border-radius: var(--ml-radius-lg, 16px);
  backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  box-shadow: var(--ml-shadow-1, 0 8px 24px rgba(0, 0, 0, 0.25));
}
groupviewmetric--ml-metric-card-glass .ml-surface-bg.ml-border.ml-text::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  border-top: 1px solid rgba(255, 255, 255, 0.5);
  border-left: 1px solid rgba(255, 255, 255, 0.25);
  pointer-events: none;
}
groupviewmetric--ml-metric-card-glass .ml-surface-bg {
  background: var(--ml-surface, rgba(255, 255, 255, 0.07));
}
groupviewmetric--ml-metric-card-glass .ml-border {
  border-color: var(--ml-outline-variant, rgba(255, 255, 255, 0.15));
}
groupviewmetric--ml-metric-card-glass .ml-text {
  color: var(--ml-on-surface, #fff);
}
groupviewmetric--ml-metric-card-glass .p-2.ml-surface-dim-bg .ml-text {
  color: rgba(255, 255, 255, 0.85);
}
groupviewmetric--ml-metric-card-glass .ml-text-muted {
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.7));
}
groupviewmetric--ml-metric-card-glass .ml-text-muted:not(.font-medium) {
  color: rgba(255, 255, 255, 0.55);
}
groupviewmetric--ml-metric-card-glass .ml-surface-dim-bg {
  background: rgba(255, 255, 255, 0.12);
  border-radius: 6px;
  animation: glass-mc-pulse 1.4s ease-in-out infinite;
}
@keyframes glass-mc-pulse {
  0%,
  100% {
    opacity: 0.6;
  }
  50% {
    opacity: 0.25;
  }
}
groupviewmetric--ml-metric-card-glass .p-2.ml-surface-dim-bg {
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.18);
  border-radius: 10px;
  animation: none;
}
groupviewmetric--ml-metric-card-glass .ml-success-text {
  color: var(--ml-success, #6ee7b7);
}
groupviewmetric--ml-metric-card-glass .ml-success-dim-bg {
  background: rgba(16, 185, 129, 0.15);
}
groupviewmetric--ml-metric-card-glass .ml-success-border {
  border-color: rgba(16, 185, 129, 0.4);
}
groupviewmetric--ml-metric-card-glass .ml-error-text {
  color: var(--ml-error, #fca5a5);
}
groupviewmetric--ml-metric-card-glass .ml-error-dim-bg {
  background: rgba(239, 68, 68, 0.15);
}
groupviewmetric--ml-metric-card-glass .ml-border-error {
  border-color: rgba(239, 68, 68, 0.4);
}
groupviewmetric--ml-metric-card-glass .ml-border.ml-surface-dim-bg {
  background: rgba(255, 255, 255, 0.08);
  border-color: rgba(255, 255, 255, 0.2);
  animation: none;
}
groupviewmetric--ml-metric-card-glass .gap-1 {
  border-radius: 8px;
}
`);
    }
};
MetricCardGlass = __decorate([
    customElement('groupviewmetric--ml-metric-card-glass')
], MetricCardGlass);
export { MetricCardGlass };
