var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupsearchcontent/ml-search-bar-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// SEARCH BAR — GLASSMORPHISM (mls-102055)
// =============================================================================
// Casca (estratégia D): herda tudo de MlSearchBarMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência glass vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlSearchBarMolecule } from '/_102040_/l2/molecules/groupsearchcontent/ml-search-bar.js';
let MlSearchBarGlass = class MlSearchBarGlass extends MlSearchBarMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupsearchcontent--ml-search-bar-glass {
  display: block;
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-on-surface-muted: rgba(255, 255, 255, 0.55);
  --ml-error: #ffb4ab;
  --ml-outline-variant: rgba(255, 255, 255, 0.2);
  --ml-outline-focus: rgba(199, 210, 254, 0.9);
  --ml-outline-error: rgba(255, 120, 120, 0.7);
  --ml-radius-md: 10px;
  --ml-radius-lg: 12px;
  --ml-surface: rgba(255, 255, 255, 0.08);
  --ml-surface-dim: rgba(30, 27, 75, 0.85);
  --ml-transition: 150ms ease;
  --ml-focus-ring-width: 3px;
  --ml-focus-ring-color: rgba(199, 210, 254, 0.25);
  --ml-disabled-opacity: 0.5;
  --ml-backdrop-blur: 8px;
  --ml-backdrop-blur-strong: 18px;
}
groupsearchcontent--ml-search-bar-glass .ml-label {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  color: rgba(255, 255, 255, 0.6);
}
groupsearchcontent--ml-search-bar-glass .ml-text {
  color: rgba(255, 255, 255, 0.9);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupsearchcontent--ml-search-bar-glass p.ml-text-muted {
  color: rgba(255, 255, 255, 0.65);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupsearchcontent--ml-search-bar-glass div.ml-text-muted {
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.55));
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupsearchcontent--ml-search-bar-glass .ml-error-text {
  color: var(--ml-error, #ffb4ab);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupsearchcontent--ml-search-bar-glass .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupsearchcontent--ml-search-bar-glass .ml-search-icon {
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.55));
}
groupsearchcontent--ml-search-bar-glass .ml-search-clear {
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.55));
}
groupsearchcontent--ml-search-bar-glass .ml-search-clear:hover {
  color: #ffffff;
}
groupsearchcontent--ml-search-bar-glass .ml-search-input {
  background: var(--ml-surface, rgba(255, 255, 255, 0.08));
  border-radius: var(--ml-radius-md, 10px);
  color: #ffffff;
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  outline: none;
  backdrop-filter: blur(var(--ml-backdrop-blur, 8px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur, 8px));
  transition: border-color var(--ml-transition, 150ms ease), box-shadow var(--ml-transition, 150ms ease), background var(--ml-transition, 150ms ease);
}
groupsearchcontent--ml-search-bar-glass .ml-search-input::placeholder {
  color: rgba(255, 255, 255, 0.45);
}
groupsearchcontent--ml-search-bar-glass .ml-search-border {
  border-color: var(--ml-outline-variant, rgba(255, 255, 255, 0.2));
}
groupsearchcontent--ml-search-bar-glass .ml-error-border {
  border-color: var(--ml-outline-error, rgba(255, 120, 120, 0.7));
}
groupsearchcontent--ml-search-bar-glass .ml-search-focus:focus {
  border-color: var(--ml-outline-focus, rgba(199, 210, 254, 0.9));
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) var(--ml-focus-ring-color, rgba(199, 210, 254, 0.25));
  background: rgba(255, 255, 255, 0.12);
}
groupsearchcontent--ml-search-bar-glass .ml-search-container {
  background: var(--ml-surface-dim, rgba(30, 27, 75, 0.85));
  border-color: rgba(255, 255, 255, 0.18);
  border-radius: var(--ml-radius-lg, 12px);
  box-shadow: 0 16px 40px rgba(0, 0, 0, 0.45);
  backdrop-filter: blur(var(--ml-backdrop-blur-strong, 18px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur-strong, 18px));
}
groupsearchcontent--ml-search-bar-glass .ml-text.ml-search-icon {
  color: rgba(255, 255, 255, 0.9);
  border-radius: 8px;
}
groupsearchcontent--ml-search-bar-glass .ml-text.ml-search-icon:not(.ml-disabled):hover {
  background: rgba(255, 255, 255, 0.08);
}
groupsearchcontent--ml-search-bar-glass .ml-filter-chip-active {
  background: rgba(199, 210, 254, 0.18);
  color: #e0e7ff;
  border: 1px solid rgba(199, 210, 254, 0.6);
  border-radius: 8px;
}
`);
    }
};
MlSearchBarGlass = __decorate([
    customElement('groupsearchcontent--ml-search-bar-glass')
], MlSearchBarGlass);
export { MlSearchBarGlass };
