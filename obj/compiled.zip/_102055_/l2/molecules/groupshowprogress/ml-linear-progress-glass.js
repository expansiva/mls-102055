var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupshowprogress/ml-linear-progress-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML LINEAR PROGRESS — GLASSMORPHISM por HERANÇA (mls-102055)
// =============================================================================
// Skill Group: groupShowProgress
// Herda LinearProgressMolecule (mls-102040): contrato/props (value, size, label,
// showValue, variant) e clamp. Sobrescreve só render() + helpers de aparência.
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { LinearProgressMolecule } from '/_102040_/l2/molecules/groupshowprogress/ml-linear-progress.js';
let LinearProgressGlass = class LinearProgressGlass extends LinearProgressMolecule {
    get x() {
        return this;
    }
    // ---- helpers presentacionais (glass) — nomes próprios p/ não colidir com os private do pai ----
    glassSizeClasses() {
        const sizeMap = {
            xs: 'glass-lp--xs',
            sm: 'glass-lp--sm',
            md: 'glass-lp--md',
            lg: 'glass-lp--lg',
        };
        return sizeMap[this.size] || sizeMap.md;
    }
    glassTrackClasses() {
        return 'glass-lp-track w-full overflow-hidden';
    }
    glassFillClasses(isIndeterminate) {
        return ['glass-lp-fill h-full', `is-${this.variant}`, isIndeterminate ? 'is-indeterminate' : '']
            .filter(Boolean)
            .join(' ');
    }
    glassValueText(value) {
        if (value === null || !this.showValue)
            return null;
        const textClasses = ['glass-lp-value min-w-[3rem] text-right', this.x.getTextSizeClasses()].join(' ');
        return html `<span class="${textClasses}">${Math.round(value)}%</span>`;
    }
    // ===========================================================================
    // RENDER (override) — lógica/clamp herdados via this.x
    // ===========================================================================
    render() {
        const normalized = this.x.getNormalizedValue();
        const isIndeterminate = normalized === null;
        const trackClasses = [this.glassTrackClasses(), this.glassSizeClasses()].join(' ');
        const fillClasses = this.glassFillClasses(isIndeterminate);
        const widthStyle = isIndeterminate ? '' : `width: ${normalized}%;`;
        const ariaAttrs = {
            role: 'progressbar',
            'aria-label': this.label || undefined,
            'aria-valuemin': isIndeterminate ? undefined : '0',
            'aria-valuemax': isIndeterminate ? undefined : '100',
            'aria-valuenow': isIndeterminate ? undefined : String(normalized),
        };
        return html `
      <div class="w-full flex items-center gap-2" ...=${ariaAttrs}>
        <div class="${trackClasses}">
          <div class="${fillClasses}" style="${widthStyle}" aria-hidden="true"></div>
        </div>
        ${this.glassValueText(isIndeterminate ? null : normalized)}
      </div>
    `;
    }
};
LinearProgressGlass = __decorate([
    customElement('groupshowprogress--ml-linear-progress-glass')
], LinearProgressGlass);
export { LinearProgressGlass };
