var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupshowprogress/ml-linear-progress-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// LINEAR PROGRESS — GLASSMORPHISM (mls-102055)
// =============================================================================
// Casca (estratégia D): herda tudo de LinearProgressMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência glass vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { LinearProgressMolecule } from '/_102040_/l2/molecules/groupshowprogress/ml-linear-progress.js';
let LinearProgressGlass = class LinearProgressGlass extends LinearProgressMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupshowprogress--ml-linear-progress-glass {
  display: block;
  --ml-font-family: 'Inter', system-ui, sans-serif;
}
groupshowprogress--ml-linear-progress-glass .ml-text-muted {
  color: rgba(255, 255, 255, 0.7);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupshowprogress--ml-linear-progress-glass .ml-surface-dim-bg {
  background: rgba(255, 255, 255, 0.14);
  border: 1px solid rgba(255, 255, 255, 0.12);
}
groupshowprogress--ml-linear-progress-glass .ml-primary-bg {
  background: linear-gradient(90deg, #818cf8, #c7d2fe);
}
groupshowprogress--ml-linear-progress-glass .ml-success-bg {
  background: linear-gradient(90deg, #10b981, #6ee7b7);
}
groupshowprogress--ml-linear-progress-glass .ml-warning-bg {
  background: linear-gradient(90deg, #f59e0b, #fcd34d);
}
groupshowprogress--ml-linear-progress-glass .ml-error-bg {
  background: linear-gradient(90deg, #ef4444, #fca5a5);
}
`);
    }
};
LinearProgressGlass = __decorate([
    customElement('groupshowprogress--ml-linear-progress-glass')
], LinearProgressGlass);
export { LinearProgressGlass };
