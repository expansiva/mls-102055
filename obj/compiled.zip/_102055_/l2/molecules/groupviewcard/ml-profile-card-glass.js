var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupviewcard/ml-profile-card-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// PROFILE CARD — GLASSMORPHISM (mls-102055)
// =============================================================================
// Casca (estratégia D): herda tudo de MlProfileCardMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência glass vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlProfileCardMolecule } from '/_102040_/l2/molecules/groupviewcard/ml-profile-card.js';
let MlProfileCardGlass = class MlProfileCardGlass extends MlProfileCardMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupviewcard--ml-profile-card-glass {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-font-weight-medium: 600;
  --ml-radius-md: 18px;
  --ml-border-width: 1px;
  --ml-outline-variant: rgba(255, 255, 255, 0.2);
  --ml-surface: rgba(255, 255, 255, 0.09);
  --ml-on-surface: rgba(255, 255, 255, 0.92);
  --ml-on-surface-muted: rgba(255, 255, 255, 0.68);
  --ml-disabled-opacity: 0.5;
  --ml-shadow-1: 0 12px 40px rgba(0, 0, 0, 0.28);
  --ml-backdrop-blur: 16px;
  --ml-focus-ring-width: 3px;
  --ml-focus-ring-color: rgba(199, 210, 254, 0.5);
}
groupviewcard--ml-profile-card-glass .ml-card {
  position: relative;
  border-radius: var(--ml-radius-md, 18px);
  border: var(--ml-border-width, 1px) solid var(--ml-outline-variant, rgba(255, 255, 255, 0.2));
  background: var(--ml-surface, rgba(255, 255, 255, 0.09));
  backdrop-filter: blur(var(--ml-backdrop-blur, 16px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur, 16px));
  box-shadow: var(--ml-shadow-1, 0 12px 40px rgba(0, 0, 0, 0.28));
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.92));
  transition: background 200ms ease, border-color 200ms ease, transform 150ms ease;
}
groupviewcard--ml-profile-card-glass .ml-card::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  border-top: 1px solid rgba(255, 255, 255, 0.5);
  border-left: 1px solid rgba(255, 255, 255, 0.25);
  pointer-events: none;
}
groupviewcard--ml-profile-card-glass .ml-card:focus-visible {
  outline: none;
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) var(--ml-focus-ring-color, rgba(199, 210, 254, 0.5));
}
groupviewcard--ml-profile-card-glass .ml-card-hover:hover {
  background: rgba(255, 255, 255, 0.14);
}
groupviewcard--ml-profile-card-glass .ml-card-hover.cursor-pointer:hover {
  transform: translateY(-2px);
}
groupviewcard--ml-profile-card-glass .ml-card[aria-selected='true'] {
  background: rgba(99, 102, 241, 0.34);
  border-color: rgba(199, 210, 254, 0.8);
}
groupviewcard--ml-profile-card-glass .ml-label {
  font-weight: var(--ml-font-weight-medium, 600);
  color: #fff;
}
groupviewcard--ml-profile-card-glass .ml-text {
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.92));
}
groupviewcard--ml-profile-card-glass .card-header.ml-text {
  color: #fff;
}
groupviewcard--ml-profile-card-glass .card-content.ml-text {
  color: rgba(255, 255, 255, 0.88);
}
groupviewcard--ml-profile-card-glass .ml-text-muted {
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.68));
}
groupviewcard--ml-profile-card-glass .card-footer.ml-text-muted {
  color: rgba(255, 255, 255, 0.6);
}
groupviewcard--ml-profile-card-glass .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupviewcard--ml-profile-card-glass .ml-skeleton {
  background: rgba(255, 255, 255, 0.12);
  border-radius: 8px;
}
`);
    }
};
MlProfileCardGlass = __decorate([
    customElement('groupviewcard--ml-profile-card-glass')
], MlProfileCardGlass);
export { MlProfileCardGlass };
