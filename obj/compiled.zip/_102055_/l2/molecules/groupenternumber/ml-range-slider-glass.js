var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupenternumber/ml-range-slider-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// RANGE SLIDER — GLASSMORPHISM (mls-102055, Strategy D shell)
// =============================================================================
// Skill Group: groupEnterNumber
// Herda RangeSliderMolecule (mls-102040) sem sobrescrever render():
// o markup herdado emite classes ml-*; toda a aparência vive no .less.
import { customElement } from 'lit/decorators.js';
import { RangeSliderMolecule } from '/_102040_/l2/molecules/groupenternumber/ml-range-slider.js';
let RangeSliderGlass = class RangeSliderGlass extends RangeSliderMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupenternumber--ml-range-slider-glass {
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-font-weight-medium: 500;
  --ml-surface: rgba(255, 255, 255, 0.16);
  --ml-border-width: 1px;
  --ml-outline-variant: rgba(255, 255, 255, 0.2);
  --ml-outline-error: rgba(255, 120, 120, 0.7);
  --ml-on-surface: rgba(255, 255, 255, 0.95);
  --ml-on-surface-muted: rgba(255, 255, 255, 0.65);
  --ml-error: #ffb4ab;
  --ml-focus-ring-width: 3px;
  --ml-focus-ring-color: rgba(199, 210, 254, 0.4);
  --ml-disabled-opacity: 0.5;
  display: block;
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupenternumber--ml-range-slider-glass .ml-label {
  color: rgba(255, 255, 255, 0.85);
  font-weight: var(--ml-font-weight-medium, 500);
}
groupenternumber--ml-range-slider-glass span.ml-text {
  color: #fff;
  font-weight: 500;
}
groupenternumber--ml-range-slider-glass div.ml-text {
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
}
groupenternumber--ml-range-slider-glass .ml-text-muted {
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.65));
}
groupenternumber--ml-range-slider-glass div.ml-text-muted > span.ml-text-muted {
  color: rgba(255, 255, 255, 0.5);
}
groupenternumber--ml-range-slider-glass div.ml-text-muted.mt-2 {
  color: rgba(255, 255, 255, 0.6);
}
groupenternumber--ml-range-slider-glass .ml-helper {
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.65));
}
groupenternumber--ml-range-slider-glass .ml-error-text {
  color: var(--ml-error, #ffb4ab);
}
groupenternumber--ml-range-slider-glass .ml-slider-track {
  -webkit-appearance: none;
  appearance: none;
  background: var(--ml-surface, rgba(255, 255, 255, 0.16));
  border: var(--ml-border-width, 1px) solid var(--ml-outline-variant, rgba(255, 255, 255, 0.2));
  outline: none;
}
groupenternumber--ml-range-slider-glass .ml-slider-track::-webkit-slider-thumb {
  -webkit-appearance: none;
  appearance: none;
  width: 1.1rem;
  height: 1.1rem;
  border-radius: 9999px;
  background: rgba(255, 255, 255, 0.95);
  border: 1px solid rgba(199, 210, 254, 0.9);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.35);
  cursor: pointer;
}
groupenternumber--ml-range-slider-glass .ml-slider-track::-moz-range-thumb {
  width: 1.1rem;
  height: 1.1rem;
  border-radius: 9999px;
  background: rgba(255, 255, 255, 0.95);
  border: 1px solid rgba(199, 210, 254, 0.9);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.35);
  cursor: pointer;
}
groupenternumber--ml-range-slider-glass .ml-slider-track:focus-visible {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) var(--ml-focus-ring-color, rgba(199, 210, 254, 0.4));
}
groupenternumber--ml-range-slider-glass .ml-slider-track.ml-input-container-error {
  border-color: var(--ml-outline-error, rgba(255, 120, 120, 0.7));
}
groupenternumber--ml-range-slider-glass .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
    }
};
RangeSliderGlass = __decorate([
    customElement('groupenternumber--ml-range-slider-glass')
], RangeSliderGlass);
export { RangeSliderGlass };
