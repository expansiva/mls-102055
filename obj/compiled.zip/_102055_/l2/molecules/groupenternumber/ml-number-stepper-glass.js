var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupenternumber/ml-number-stepper-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// NUMBER STEPPER — GLASSMORPHISM (mls-102055, Strategy D)
// =============================================================================
// Shell subclass: no render() override. The inherited render() emits semantic
// ml-* classes; all glass appearance lives in ml-number-stepper-glass.less.
import { customElement } from 'lit/decorators.js';
import { NumberStepperMolecule } from '/_102040_/l2/molecules/groupenternumber/ml-number-stepper.js';
let NumberStepperGlass = class NumberStepperGlass extends NumberStepperMolecule {
};
NumberStepperGlass = __decorate([
    customElement('groupenternumber--ml-number-stepper-glass')
], NumberStepperGlass);
export { NumberStepperGlass };
