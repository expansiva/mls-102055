var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupenternumber/ml-number-stepper-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// NUMBER STEPPER — GLASSMORPHISM (mls-102055, Strategy D)
// =============================================================================
// Shell subclass: no render() override. The inherited render() emits semantic
// ml-* classes; all glass appearance lives in ml-number-stepper-glass.less.
import { customElement } from 'lit/decorators.js';
import { NumberStepperMolecule } from '/_102040_/l2/molecules/groupenternumber/ml-number-stepper.js';
let NumberStepperGlass = class NumberStepperGlass extends NumberStepperMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupenternumber--ml-number-stepper-glass {
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-radius-sm: 10px;
  --ml-border-width: 1px;
  --ml-outline-variant: rgba(255, 255, 255, 0.25);
  --ml-outline-focus: rgba(199, 210, 254, 0.9);
  --ml-outline-error: rgba(255, 120, 120, 0.85);
  --ml-surface: rgba(255, 255, 255, 0.1);
  --ml-on-surface: rgba(255, 255, 255, 0.95);
  --ml-on-surface-muted: rgba(255, 255, 255, 0.7);
  --ml-error: #ffb4ab;
  --ml-transition: 200ms ease;
  --ml-focus-ring-width: 3px;
  --ml-focus-ring-color: rgba(199, 210, 254, 0.3);
  --ml-disabled-opacity: 0.5;
  --ml-backdrop-blur: 10px;
  display: block;
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupenternumber--ml-number-stepper-glass .ml-text {
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
}
groupenternumber--ml-number-stepper-glass .ml-text-muted {
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.7));
}
groupenternumber--ml-number-stepper-glass p.ml-text-muted {
  color: rgba(255, 255, 255, 0.65);
}
groupenternumber--ml-number-stepper-glass div.ml-text-muted {
  color: rgba(255, 255, 255, 0.6);
}
groupenternumber--ml-number-stepper-glass .ml-error-text {
  color: var(--ml-error, #ffb4ab);
}
groupenternumber--ml-number-stepper-glass .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupenternumber--ml-number-stepper-glass .ml-input {
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
}
groupenternumber--ml-number-stepper-glass .ml-input::placeholder {
  color: rgba(255, 255, 255, 0.5);
}
groupenternumber--ml-number-stepper-glass .ml-input-container {
  position: relative;
  border-radius: var(--ml-radius-sm, 10px);
  border: var(--ml-border-width, 1px) solid var(--ml-outline-variant, rgba(255, 255, 255, 0.25));
  background: var(--ml-surface, rgba(255, 255, 255, 0.1));
  backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  transition: border-color var(--ml-transition, 200ms ease), box-shadow var(--ml-transition, 200ms ease);
}
groupenternumber--ml-number-stepper-glass .ml-input-container::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  border-top: 1px solid rgba(255, 255, 255, 0.5);
  border-left: 1px solid rgba(255, 255, 255, 0.25);
  pointer-events: none;
}
groupenternumber--ml-number-stepper-glass .ml-input-container:focus-within {
  border-color: var(--ml-outline-focus, rgba(199, 210, 254, 0.9));
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) var(--ml-focus-ring-color, rgba(199, 210, 254, 0.3));
}
groupenternumber--ml-number-stepper-glass .ml-input-container-error,
groupenternumber--ml-number-stepper-glass .ml-input-container:has(.ml-input[aria-invalid='true']) {
  border-color: var(--ml-outline-error, rgba(255, 120, 120, 0.85)) !important;
}
groupenternumber--ml-number-stepper-glass .ml-stepper-button {
  position: relative;
  overflow: hidden;
  border-radius: var(--ml-radius-sm, 10px);
  border: var(--ml-border-width, 1px) solid var(--ml-outline-variant, rgba(255, 255, 255, 0.25));
  background: rgba(255, 255, 255, 0.12);
  backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur, 10px));
  color: #ffffff;
  cursor: pointer;
  transition: background var(--ml-transition, 200ms ease);
}
groupenternumber--ml-number-stepper-glass .ml-stepper-button::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  border-top: 1px solid rgba(255, 255, 255, 0.5);
  border-left: 1px solid rgba(255, 255, 255, 0.25);
  pointer-events: none;
}
groupenternumber--ml-number-stepper-glass .ml-stepper-button:hover:not(:disabled) {
  background: rgba(255, 255, 255, 0.2);
}
groupenternumber--ml-number-stepper-glass .ml-stepper-button:focus-visible {
  outline: none;
  box-shadow: 0 0 0 2px rgba(199, 210, 254, 0.6);
}
groupenternumber--ml-number-stepper-glass .ml-stepper-button:disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
}
`);
    }
};
NumberStepperGlass = __decorate([
    customElement('groupenternumber--ml-number-stepper-glass')
], NumberStepperGlass);
export { NumberStepperGlass };
