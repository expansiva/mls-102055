var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupenternumber/ml-number-stepper-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// NUMBER STEPPER — GLASSMORPHISM por HERANÇA (mls-102055)
// =============================================================================
// Skill Group: groupEnterNumber
// Herda NumberStepperMolecule (mls-102040): parse/format, clamp, increment/decrement,
// estado (rawValue). Sobrescreve só render().
import { html, nothing } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement } from 'lit/decorators.js';
import { NumberStepperMolecule } from '/_102040_/l2/molecules/groupenternumber/ml-number-stepper.js';
/// **collab_i18n_start**
const message_en = { increment: 'Increment', decrement: 'Decrement', loading: 'Loading...', required: 'Required', emptyValue: '—' };
const messages = {
    en: message_en,
    pt: { increment: 'Incrementar', decrement: 'Decrementar', loading: 'Carregando...', required: 'Obrigatório', emptyValue: '—' },
};
let NumberStepperGlass = class NumberStepperGlass extends NumberStepperMolecule {
    constructor() {
        super(...arguments);
        this.gMsg = messages.en;
        this.gUid = `ns-glass-${Math.random().toString(36).slice(2, 9)}`;
    }
    get gLabelId() { return `${this.gUid}-label`; }
    get gHelperId() { return `${this.gUid}-helper`; }
    get gErrorId() { return `${this.gUid}-error`; }
    get gInputId() { return `${this.gUid}-input`; }
    get x() {
        return this;
    }
    glassInputClasses(hasError) {
        return [
            'glass-ns-input w-full flex-1 px-3 py-2 text-sm outline-none',
            hasError ? 'is-error' : '',
            this.disabled || this.loading ? 'is-disabled' : '',
            this.readonly ? 'is-readonly' : '',
        ].filter(Boolean).join(' ');
    }
    glassButtonClasses() {
        return 'glass-ns-btn h-9 w-9 inline-flex items-center justify-center text-sm';
    }
    glassContainerClasses() {
        return ['w-full', this.disabled || this.loading ? 'is-disabled' : ''].filter(Boolean).join(' ');
    }
    glassLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `<label id="${this.gLabelId}" class="glass-ns-label mb-1 block text-sm">${unsafeHTML(this.getSlotContent('Label'))}</label>`;
    }
    glassHelperOrError(effectiveError) {
        if (String(effectiveError).length > 0) {
            return html `<p id="${this.gErrorId}" class="glass-error-text mt-1 text-xs">${unsafeHTML(String(effectiveError))}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p id="${this.gHelperId}" class="glass-helper mt-1 text-xs">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    glassPrefix() {
        if (!this.hasSlot('Prefix'))
            return html ``;
        return html `<span class="glass-ns-affix text-sm">${unsafeHTML(this.getSlotContent('Prefix'))}</span>`;
    }
    glassSuffix() {
        if (!this.hasSlot('Suffix'))
            return html ``;
        return html `<span class="glass-ns-affix text-sm">${unsafeHTML(this.getSlotContent('Suffix'))}</span>`;
    }
    glassViewMode() {
        const display = this.value === null || this.value === undefined ? this.gMsg.emptyValue : this.x.formatToDisplay(this.value);
        return html `
      <div class="${this.glassContainerClasses()}">
        ${this.glassLabel()}
        <div class="glass-ns-view flex items-center gap-2 text-sm">
          ${this.glassPrefix()}<span>${display}</span>${this.glassSuffix()}
        </div>
      </div>
    `;
    }
    // ===========================================================================
    // RENDER (override)
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.gMsg = messages[lang];
        if (!this.isEditing)
            return this.glassViewMode();
        const effectiveError = this.error || (this.required && (this.value === null || this.value === undefined) ? this.gMsg.required : '');
        const hasError = String(effectiveError).length > 0;
        const ariaDescribedBy = hasError ? this.gErrorId : this.hasSlot('Helper') ? this.gHelperId : undefined;
        const placeholder = this.placeholder || '';
        return html `
      <div class="${this.glassContainerClasses()}">
        ${this.glassLabel()}
        <div class="flex items-center gap-2">
          ${this.glassPrefix()}
          <input
            id="${this.gInputId}"
            class="${this.glassInputClasses(hasError)}"
            type="text"
            inputmode="${this.decimals > 0 ? 'decimal' : 'numeric'}"
            .value=${this.x.rawValue}
            placeholder="${this.value === null ? placeholder : ''}"
            ?disabled=${this.disabled || this.loading}
            ?readonly=${this.readonly}
            aria-labelledby="${this.hasSlot('Label') ? this.gLabelId : nothing}"
            aria-describedby="${ariaDescribedBy || nothing}"
            aria-invalid="${hasError ? 'true' : 'false'}"
            aria-required="${this.required ? 'true' : 'false'}"
            @input=${(e) => this.x.handleInput(e)}
            @blur=${() => this.x.handleBlur()}
            @focus=${() => this.x.handleFocus()}
          />
          ${this.glassSuffix()}
          <button type="button" class="${this.glassButtonClasses()}" aria-label="${this.gMsg.decrement}" ?disabled=${this.disabled || this.readonly || this.loading} @click=${() => this.x.decrement()}>−</button>
          <button type="button" class="${this.glassButtonClasses()}" aria-label="${this.gMsg.increment}" ?disabled=${this.disabled || this.readonly || this.loading} @click=${() => this.x.increment()}>+</button>
        </div>
        ${this.loading ? html `<div class="glass-ns-loading mt-2 text-xs">${this.gMsg.loading}</div>` : this.glassHelperOrError(effectiveError)}
      </div>
    `;
    }
};
NumberStepperGlass = __decorate([
    customElement('groupenternumber--ml-number-stepper-glass')
], NumberStepperGlass);
export { NumberStepperGlass };
