var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupenterboolean/ml-toggle-switch-glass.ts" enhancement="_102020_/l2/enhancementAura" />
// =============================================================================
// TOGGLE SWITCH — GLASSMORPHISM (mls-102055) — Strategy D shell
// =============================================================================
// Skill Group: groupEnterBoolean
// Herda render() e toda a lógica de ToggleSwitchMolecule (mls-102040).
// Toda a aparência vive no .less escopado na tag -glass.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { ToggleSwitchMolecule } from '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch.js';
let ToggleSwitchGlass = class ToggleSwitchGlass extends ToggleSwitchMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupenterboolean--ml-toggle-switch-glass {
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-font-weight-medium: 500;
  --ml-radius-full: 9999px;
  --ml-border-width: 1px;
  --ml-outline-variant: rgba(255, 255, 255, 0.22);
  --ml-outline-focus: rgba(199, 210, 254, 0.9);
  --ml-outline-error: rgba(255, 120, 120, 0.7);
  --ml-primary: rgba(129, 140, 248, 0.65);
  --ml-surface: rgba(255, 255, 255, 0.14);
  --ml-on-surface: #ffffff;
  --ml-on-surface-muted: rgba(255, 255, 255, 0.65);
  --ml-error: #ffb4ab;
  --ml-shadow-1: 0 2px 6px rgba(0, 0, 0, 0.35);
  --ml-transition: 0.2s ease;
  --ml-focus-ring-width: 3px;
  --ml-focus-ring-color: rgba(199, 210, 254, 0.4);
  --ml-disabled-opacity: 0.5;
  --ml-backdrop-blur: 8px;
  display: block;
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupenterboolean--ml-toggle-switch-glass .ml-label {
  color: rgba(255, 255, 255, 0.85);
  font-weight: var(--ml-font-weight-medium, 500);
}
groupenterboolean--ml-toggle-switch-glass .ml-text {
  color: var(--ml-on-surface, #ffffff);
}
groupenterboolean--ml-toggle-switch-glass .ml-helper {
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.65));
}
groupenterboolean--ml-toggle-switch-glass .ml-error-text {
  color: var(--ml-error, #ffb4ab);
}
groupenterboolean--ml-toggle-switch-glass .ml-toggle-track {
  background: var(--ml-surface, rgba(255, 255, 255, 0.14));
  border: var(--ml-border-width, 1px) solid var(--ml-outline-variant, rgba(255, 255, 255, 0.22));
  border-radius: var(--ml-radius-full, 9999px);
  backdrop-filter: blur(var(--ml-backdrop-blur, 8px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur, 8px));
  transition: background var(--ml-transition, 0.2s ease), border-color var(--ml-transition, 0.2s ease), box-shadow var(--ml-transition, 0.2s ease);
}
groupenterboolean--ml-toggle-switch-glass .ml-toggle-track::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  border-top: 1px solid rgba(255, 255, 255, 0.5);
  border-left: 1px solid rgba(255, 255, 255, 0.25);
  pointer-events: none;
}
groupenterboolean--ml-toggle-switch-glass .ml-toggle-track:focus-visible {
  outline: none;
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) var(--ml-focus-ring-color, rgba(199, 210, 254, 0.4));
}
groupenterboolean--ml-toggle-switch-glass .ml-toggle-track-on {
  background: var(--ml-primary, rgba(129, 140, 248, 0.65));
  border-color: var(--ml-outline-focus, rgba(199, 210, 254, 0.9));
}
groupenterboolean--ml-toggle-switch-glass .ml-toggle-track-error {
  border-color: var(--ml-outline-error, rgba(255, 120, 120, 0.7));
}
groupenterboolean--ml-toggle-switch-glass .ml-toggle-thumb {
  background: rgba(255, 255, 255, 0.95);
  border-radius: var(--ml-radius-full, 9999px);
  box-shadow: var(--ml-shadow-1, 0 2px 6px rgba(0, 0, 0, 0.35));
  transition: transform var(--ml-transition, 0.2s ease);
}
groupenterboolean--ml-toggle-switch-glass .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
    }
};
ToggleSwitchGlass = __decorate([
    customElement('groupenterboolean--ml-toggle-switch-glass')
], ToggleSwitchGlass);
export { ToggleSwitchGlass };
