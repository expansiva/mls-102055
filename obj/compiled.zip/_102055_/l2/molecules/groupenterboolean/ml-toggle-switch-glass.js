var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupenterboolean/ml-toggle-switch-glass.ts" enhancement="_102020_/l2/enhancementAura" />
// =============================================================================
// TOGGLE SWITCH — GLASSMORPHISM (mls-102055) — Strategy D shell
// =============================================================================
// Skill Group: groupEnterBoolean
// Herda render() e toda a lógica de ToggleSwitchMolecule (mls-102040).
// Toda a aparência vive no .less escopado na tag -glass.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { ToggleSwitchMolecule } from '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch.js';
let ToggleSwitchGlass = class ToggleSwitchGlass extends ToggleSwitchMolecule {
};
ToggleSwitchGlass = __decorate([
    customElement('groupenterboolean--ml-toggle-switch-glass')
], ToggleSwitchGlass);
export { ToggleSwitchGlass };
