var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupenterboolean/ml-toggle-switch-glass.ts" enhancement="_102020_/l2/enhancementAura" />
// =============================================================================
// TOGGLE SWITCH — GLASSMORPHISM por HERANÇA (mls-102055)
// =============================================================================
// Skill Group: groupEnterBoolean
// Herda toda a lógica de ToggleSwitchMolecule (mls-102040) e sobrescreve apenas
// o render() com o template de vidro. Aparência no .less escopado na tag -glass.
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
// Importar registra a tag do pai (groupenterboolean--ml-toggle-switch); inofensivo: usamos a tag -glass.
import { ToggleSwitchMolecule } from '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch.js';
/// **collab_i18n_start**
const message_en = { yes: 'Yes', no: 'No' };
const messages = {
    en: message_en,
    pt: { yes: 'Sim', no: 'Não' },
};
let ToggleSwitchGlass = class ToggleSwitchGlass extends ToggleSwitchMolecule {
    constructor() {
        super(...arguments);
        // i18n e id próprios (não reaproveita os `private` do pai para evitar conflito de nome)
        this.gMsg = messages.en;
        this.gUid = `tg-glass-${Math.random().toString(36).slice(2, 9)}`;
    }
    get internals() {
        return this;
    }
    // ===========================================================================
    // RENDER HELPERS (glass) — nomes próprios p/ não colidir com os private do pai
    // ===========================================================================
    glassLabel(labelId) {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `<div id=${labelId || ''} class="glass-tg-label mb-2 text-sm font-medium">
      ${unsafeHTML(this.getSlotContent('Label'))}
    </div>`;
    }
    glassHelper(helperId) {
        if (!this.hasSlot('Helper') || this.error)
            return html ``;
        return html `<div id=${helperId || ''} class="glass-helper mt-2 text-xs">
      ${unsafeHTML(this.getSlotContent('Helper'))}
    </div>`;
    }
    glassError(errorId) {
        if (!this.error)
            return html ``;
        return html `<div id=${errorId || ''} class="glass-error-text mt-2 text-xs">
      ${unsafeHTML(String(this.error))}
    </div>`;
    }
    glassTrackClasses() {
        return [
            'glass-tg-track relative inline-flex h-6 w-11 items-center',
            this.value ? 'is-on' : '',
            this.error ? 'is-error' : '',
            this.disabled ? 'is-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    glassThumbClasses() {
        return ['glass-tg-thumb inline-block h-4 w-4', this.value ? 'is-on' : ''].filter(Boolean).join(' ');
    }
    glassViewMode() {
        const labelId = this.hasSlot('Label') ? `${this.gUid}-label` : undefined;
        const viewValue = this.value ? this.gMsg.yes : this.gMsg.no;
        return html `
      <div class="w-full">
        ${this.glassLabel(labelId)}
        <div class="glass-tg-view text-sm">${viewValue}</div>
      </div>
    `;
    }
    // ===========================================================================
    // RENDER (override) — lógica herdada via this.internals
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.gMsg = messages[lang];
        if (!this.isEditing) {
            return this.glassViewMode();
        }
        const labelId = this.hasSlot('Label') ? `${this.gUid}-label` : undefined;
        const helperId = this.hasSlot('Helper') ? `${this.gUid}-helper` : undefined;
        const errorId = this.error ? `${this.gUid}-error` : undefined;
        const describedBy = this.error ? errorId : helperId;
        const self = this.internals;
        return html `
      <div class="w-full">
        ${this.glassLabel(labelId)}
        <button
          type="button"
          class=${this.glassTrackClasses()}
          role="switch"
          aria-checked=${this.value ? 'true' : 'false'}
          aria-labelledby=${labelId || undefined}
          aria-describedby=${describedBy || undefined}
          aria-invalid=${this.error ? 'true' : 'false'}
          aria-disabled=${this.disabled ? 'true' : 'false'}
          ?disabled=${this.disabled}
          tabindex=${this.disabled ? -1 : 0}
          @click=${() => self.handleToggle()}
          @focus=${() => self.handleFocus()}
          @blur=${() => self.handleBlur()}
          @keydown=${(e) => self.handleKeydown(e)}
        >
          <span class=${this.glassThumbClasses()}></span>
        </button>
        ${this.glassError(errorId)}
        ${this.glassHelper(helperId)}
      </div>
    `;
    }
};
ToggleSwitchGlass = __decorate([
    customElement('groupenterboolean--ml-toggle-switch-glass')
], ToggleSwitchGlass);
export { ToggleSwitchGlass };
