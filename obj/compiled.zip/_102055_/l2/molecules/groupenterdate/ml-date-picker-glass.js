var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupenterdate/ml-date-picker-glass.ts" enhancement="_102020_/l2/enhancementAura" />
// =============================================================================
// DATE PICKER — GLASSMORPHISM (mls-102055)
// =============================================================================
// Skill Group: enter + date
// Casca (estratégia D): herda tudo de MlDatePickerMolecule (mls-102040),
// inclusive render() e getPortalTemplate() — o markup base emite classes ml-*;
// a aparência glass vem do .less irmão, escopado sob esta tag e sob o
// data-widget do portal.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlDatePickerMolecule } from '/_102040_/l2/molecules/groupenterdate/ml-date-picker.js';
let MlDatePickerGlass = class MlDatePickerGlass extends MlDatePickerMolecule {
    constructor() {
        super(...arguments);
        // O container do portal (document.body) recebe este data-widget — o .less do
        // tema escopa o calendário por div[data-widget="...-glass"].
        this.portalWidgetName = 'groupenterdate--ml-date-picker-glass';
    }
};
MlDatePickerGlass = __decorate([
    customElement('groupenterdate--ml-date-picker-glass')
], MlDatePickerGlass);
export { MlDatePickerGlass };
