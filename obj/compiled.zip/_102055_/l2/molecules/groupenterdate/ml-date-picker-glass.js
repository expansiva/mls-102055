var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupenterdate/ml-date-picker-glass.ts" enhancement="_102020_/l2/enhancementAura" />
// =============================================================================
// DATE PICKER — GLASSMORPHISM (mls-102055)
// =============================================================================
// Skill Group: enter + date
// Casca (estratégia D): herda tudo de MlDatePickerMolecule (mls-102040),
// inclusive render() e getPortalTemplate() — o markup base emite classes ml-*;
// a aparência glass vem do .less irmão, escopado sob esta tag e sob o
// data-widget do portal.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlDatePickerMolecule } from '/_102040_/l2/molecules/groupenterdate/ml-date-picker.js';
let MlDatePickerGlass = class MlDatePickerGlass extends MlDatePickerMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupenterdate--ml-date-picker-glass,
div[data-widget="groupenterdate--ml-date-picker-glass"] {
  display: block;
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-on-surface: #ffffff;
  --ml-on-surface-muted: rgba(255, 255, 255, 0.6);
  --ml-error: #ffb4ab;
  --ml-surface: rgba(255, 255, 255, 0.08);
  --ml-surface-dim: rgba(30, 27, 75, 0.85);
  --ml-border-width: 1px;
  --ml-border-style: solid;
  --ml-outline-variant: rgba(255, 255, 255, 0.2);
  --ml-outline-focus: rgba(199, 210, 254, 0.9);
  --ml-outline-error: rgba(255, 120, 120, 0.7);
  --ml-radius-md: 10px;
  --ml-radius-lg: 14px;
  --ml-transition: 0.15s ease;
  --ml-focus-ring-width: 3px;
  --ml-focus-ring-color: rgba(199, 210, 254, 0.25);
  --ml-disabled-opacity: 0.5;
  --ml-backdrop-blur: 8px;
  --ml-backdrop-blur-strong: 18px;
}
groupenterdate--ml-date-picker-glass .ml-label,
div[data-widget="groupenterdate--ml-date-picker-glass"] .ml-label {
  color: rgba(255, 255, 255, 0.7);
}
groupenterdate--ml-date-picker-glass .ml-helper,
div[data-widget="groupenterdate--ml-date-picker-glass"] .ml-helper {
  color: rgba(255, 255, 255, 0.65);
}
groupenterdate--ml-date-picker-glass .ml-error-text,
div[data-widget="groupenterdate--ml-date-picker-glass"] .ml-error-text {
  color: var(--ml-error, #ffb4ab);
}
groupenterdate--ml-date-picker-glass .ml-text,
div[data-widget="groupenterdate--ml-date-picker-glass"] .ml-text {
  color: var(--ml-on-surface, #ffffff);
}
groupenterdate--ml-date-picker-glass .ml-text-muted,
div[data-widget="groupenterdate--ml-date-picker-glass"] .ml-text-muted {
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.6));
}
groupenterdate--ml-date-picker-glass .ml-date-picker-trigger > .ml-text-muted:not(:has(svg)),
div[data-widget="groupenterdate--ml-date-picker-glass"] .ml-date-picker-trigger > .ml-text-muted:not(:has(svg)) {
  color: rgba(255, 255, 255, 0.45);
}
groupenterdate--ml-date-picker-glass .ml-calendar-grid .ml-text-muted,
div[data-widget="groupenterdate--ml-date-picker-glass"] .ml-calendar-grid .ml-text-muted {
  color: rgba(255, 255, 255, 0.5);
}
groupenterdate--ml-date-picker-glass .ml-text-muted.w-9,
div[data-widget="groupenterdate--ml-date-picker-glass"] .ml-text-muted.w-9 {
  color: rgba(255, 255, 255, 0.4);
}
groupenterdate--ml-date-picker-glass .ml-disabled,
div[data-widget="groupenterdate--ml-date-picker-glass"] .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupenterdate--ml-date-picker-glass .ml-date-picker-trigger,
div[data-widget="groupenterdate--ml-date-picker-glass"] .ml-date-picker-trigger {
  position: relative;
  background: var(--ml-surface, rgba(255, 255, 255, 0.08));
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, rgba(255, 255, 255, 0.2));
  border-radius: var(--ml-radius-md, 10px);
  color: var(--ml-on-surface, #ffffff);
  backdrop-filter: blur(var(--ml-backdrop-blur, 8px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur, 8px));
  transition: border-color var(--ml-transition, 0.15s ease), box-shadow var(--ml-transition, 0.15s ease), background var(--ml-transition, 0.15s ease);
}
groupenterdate--ml-date-picker-glass .ml-date-picker-trigger::before,
div[data-widget="groupenterdate--ml-date-picker-glass"] .ml-date-picker-trigger::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  border-top: 1px solid rgba(255, 255, 255, 0.5);
  border-left: 1px solid rgba(255, 255, 255, 0.25);
  pointer-events: none;
}
groupenterdate--ml-date-picker-glass .ml-date-picker-trigger:focus,
div[data-widget="groupenterdate--ml-date-picker-glass"] .ml-date-picker-trigger:focus {
  outline: none;
  box-shadow: none;
}
groupenterdate--ml-date-picker-glass .ml-date-picker-trigger:focus-visible,
div[data-widget="groupenterdate--ml-date-picker-glass"] .ml-date-picker-trigger:focus-visible {
  outline: none;
  border-color: var(--ml-outline-focus, rgba(199, 210, 254, 0.9));
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) var(--ml-focus-ring-color, rgba(199, 210, 254, 0.25));
}
groupenterdate--ml-date-picker-glass .ml-date-picker-trigger.select-text,
div[data-widget="groupenterdate--ml-date-picker-glass"] .ml-date-picker-trigger.select-text {
  cursor: default;
}
groupenterdate--ml-date-picker-glass .ml-date-picker-trigger--error,
div[data-widget="groupenterdate--ml-date-picker-glass"] .ml-date-picker-trigger--error {
  border-color: var(--ml-outline-error, rgba(255, 120, 120, 0.7));
}
groupenterdate--ml-date-picker-glass .ml-calendar-container,
div[data-widget="groupenterdate--ml-date-picker-glass"] .ml-calendar-container {
  background: var(--ml-surface-dim, rgba(30, 27, 75, 0.85));
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) rgba(255, 255, 255, 0.18);
  border-radius: var(--ml-radius-lg, 14px);
  box-shadow: 0 16px 40px rgba(0, 0, 0, 0.45);
  backdrop-filter: blur(var(--ml-backdrop-blur-strong, 18px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur-strong, 18px));
}
groupenterdate--ml-date-picker-glass .ml-calendar-nav-btn,
div[data-widget="groupenterdate--ml-date-picker-glass"] .ml-calendar-nav-btn {
  background: rgba(255, 255, 255, 0.06);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) rgba(255, 255, 255, 0.18);
  border-radius: 8px;
  color: rgba(255, 255, 255, 0.75);
  cursor: pointer;
  transition: background 0.12s ease;
}
groupenterdate--ml-date-picker-glass .ml-calendar-nav-btn--enabled:hover,
div[data-widget="groupenterdate--ml-date-picker-glass"] .ml-calendar-nav-btn--enabled:hover {
  background: rgba(255, 255, 255, 0.14);
}
groupenterdate--ml-date-picker-glass .ml-calendar-day,
div[data-widget="groupenterdate--ml-date-picker-glass"] .ml-calendar-day {
  background: transparent;
  border-radius: 8px;
  color: rgba(255, 255, 255, 0.9);
  cursor: pointer;
  transition: background 0.12s ease, border-color 0.12s ease, color 0.12s ease;
}
groupenterdate--ml-date-picker-glass .ml-calendar-day--hoverable:hover,
div[data-widget="groupenterdate--ml-date-picker-glass"] .ml-calendar-day--hoverable:hover {
  background: rgba(255, 255, 255, 0.1);
}
groupenterdate--ml-date-picker-glass .ml-calendar-day-today,
div[data-widget="groupenterdate--ml-date-picker-glass"] .ml-calendar-day-today {
  border-color: rgba(199, 210, 254, 0.7);
}
groupenterdate--ml-date-picker-glass .ml-calendar-day-selected,
div[data-widget="groupenterdate--ml-date-picker-glass"] .ml-calendar-day-selected {
  background: rgba(199, 210, 254, 0.2);
  border-color: rgba(199, 210, 254, 0.9);
  color: #e0e7ff;
}
groupenterdate--ml-date-picker-glass .ml-calendar-day-disabled,
div[data-widget="groupenterdate--ml-date-picker-glass"] .ml-calendar-day-disabled {
  opacity: 0.4;
  cursor: not-allowed;
}
groupenterdate--ml-date-picker-glass .ml-date-picker-clear,
div[data-widget="groupenterdate--ml-date-picker-glass"] .ml-date-picker-clear {
  background: transparent;
  border: none;
  color: rgba(255, 255, 255, 0.7);
  cursor: pointer;
  transition: color 0.12s ease;
}
groupenterdate--ml-date-picker-glass .ml-date-picker-clear:hover,
div[data-widget="groupenterdate--ml-date-picker-glass"] .ml-date-picker-clear:hover {
  color: #ffffff;
}
groupenterdate--ml-date-picker-glass .ml-date-picker-clear:disabled,
div[data-widget="groupenterdate--ml-date-picker-glass"] .ml-date-picker-clear:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
`);
        // O container do portal (document.body) recebe este data-widget — o .less do
        // tema escopa o calendário por div[data-widget="...-glass"].
        this.portalWidgetName = 'groupenterdate--ml-date-picker-glass';
    }
};
MlDatePickerGlass = __decorate([
    customElement('groupenterdate--ml-date-picker-glass')
], MlDatePickerGlass);
export { MlDatePickerGlass };
