var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupexpandcontent/ml-accordion-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ACCORDION — GLASSMORPHISM (mls-102055)
// =============================================================================
// Casca (estratégia D): herda tudo de MlAccordionMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência glass vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlAccordionMolecule } from '/_102040_/l2/molecules/groupexpandcontent/ml-accordion.js';
let MlAccordionGlass = class MlAccordionGlass extends MlAccordionMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupexpandcontent--ml-accordion-glass {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-font-weight-medium: 600;
  --ml-radius-sm: 12px;
  --ml-radius-lg: 14px;
  --ml-outline-variant: rgba(255, 255, 255, 0.18);
  --ml-on-surface: rgba(255, 255, 255, 0.92);
  --ml-on-surface-muted: rgba(255, 255, 255, 0.6);
  --ml-surface: rgba(255, 255, 255, 0.1);
  --ml-primary: rgba(99, 102, 241, 0.38);
  --ml-shadow-1: 0 4px 18px rgba(0, 0, 0, 0.16);
  --ml-transition: 250ms ease;
  --ml-backdrop-blur: 10px;
  --ml-disabled-opacity: 0.5;
}
groupexpandcontent--ml-accordion-glass .ml-label {
  font-family: var(--ml-font-family);
  font-weight: var(--ml-font-weight-medium);
  color: var(--ml-on-surface);
}
groupexpandcontent--ml-accordion-glass .ml-text-muted {
  font-family: var(--ml-font-family);
  color: var(--ml-on-surface-muted);
}
groupexpandcontent--ml-accordion-glass .ml-skeleton {
  border-radius: var(--ml-radius-sm);
  background: var(--ml-surface);
}
groupexpandcontent--ml-accordion-glass div:has(> .ml-accordion-header) {
  border-radius: var(--ml-radius-lg);
  overflow: hidden;
  border: 1px solid var(--ml-outline-variant);
  box-shadow: var(--ml-shadow-1);
}
groupexpandcontent--ml-accordion-glass .ml-accordion-header {
  position: relative;
  color: var(--ml-on-surface);
  background: var(--ml-surface);
  backdrop-filter: blur(var(--ml-backdrop-blur));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur));
  font-family: var(--ml-font-family);
  font-weight: var(--ml-font-weight-medium);
  transition: background var(--ml-transition), color var(--ml-transition);
}
groupexpandcontent--ml-accordion-glass .ml-accordion-header::before {
  content: '';
  position: absolute;
  inset: 0;
  border-top: 1px solid rgba(255, 255, 255, 0.4);
  pointer-events: none;
}
groupexpandcontent--ml-accordion-glass .ml-accordion-header.ml-accordion-header-open {
  background: var(--ml-primary);
  box-shadow: inset 3px 0 0 rgba(199, 210, 254, 0.9);
}
groupexpandcontent--ml-accordion-glass .ml-accordion-header:not(.ml-disabled):not(.ml-accordion-header-open):hover {
  background: rgba(255, 255, 255, 0.16);
}
groupexpandcontent--ml-accordion-glass .ml-accordion-header:focus-visible {
  outline: none;
  box-shadow: inset 0 0 0 2px rgba(255, 255, 255, 0.6);
}
groupexpandcontent--ml-accordion-glass .ml-accordion-chevron {
  color: var(--ml-on-surface-muted);
  transition: transform var(--ml-transition), color var(--ml-transition);
}
groupexpandcontent--ml-accordion-glass .ml-accordion-chevron.ml-accordion-chevron-open {
  color: #c7d2fe;
}
groupexpandcontent--ml-accordion-glass .ml-accordion-content {
  font-family: var(--ml-font-family);
}
groupexpandcontent--ml-accordion-glass .ml-accordion-content.overflow-hidden {
  background: rgba(255, 255, 255, 0.05);
  backdrop-filter: blur(6px);
  -webkit-backdrop-filter: blur(6px);
}
groupexpandcontent--ml-accordion-glass .ml-accordion-content:not(.overflow-hidden) {
  color: rgba(255, 255, 255, 0.82);
}
groupexpandcontent--ml-accordion-glass .ml-disabled {
  opacity: var(--ml-disabled-opacity);
  cursor: not-allowed;
  pointer-events: none;
}
`);
    }
};
MlAccordionGlass = __decorate([
    customElement('groupexpandcontent--ml-accordion-glass')
], MlAccordionGlass);
export { MlAccordionGlass };
