var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupexpandcontent/ml-reveal-overlay-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// REVEAL OVERLAY — GLASSMORPHISM (mls-102055)
// =============================================================================
// Casca (estratégia D): herda tudo de RevealOverlayMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência glass vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { RevealOverlayMolecule } from '/_102040_/l2/molecules/groupexpandcontent/ml-reveal-overlay.js';
let RevealOverlayGlass = class RevealOverlayGlass extends RevealOverlayMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupexpandcontent--ml-reveal-overlay-glass {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
  --ml-radius-sm: 12px;
  --ml-outline-variant: rgba(255, 255, 255, 0.18);
  --ml-on-surface: rgba(255, 255, 255, 0.92);
  --ml-on-surface-muted: rgba(255, 255, 255, 0.6);
  --ml-surface: rgba(255, 255, 255, 0.1);
  --ml-transition: 200ms ease;
  --ml-backdrop-blur: 10px;
  --ml-disabled-opacity: 0.5;
}
groupexpandcontent--ml-reveal-overlay-glass .ml-skeleton {
  border-radius: var(--ml-radius-sm);
  border: 1px solid var(--ml-outline-variant);
  background: rgba(255, 255, 255, 0.08);
}
groupexpandcontent--ml-reveal-overlay-glass .ml-text-muted {
  color: var(--ml-on-surface-muted);
}
groupexpandcontent--ml-reveal-overlay-glass .ml-reveal-trigger .ml-text-muted {
  color: rgba(199, 210, 254, 0.95);
}
groupexpandcontent--ml-reveal-overlay-glass .ml-reveal-trigger {
  position: relative;
  border-radius: var(--ml-radius-sm);
  border: 1px solid rgba(255, 255, 255, 0.22);
  background: var(--ml-surface);
  backdrop-filter: blur(var(--ml-backdrop-blur));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur));
  color: var(--ml-on-surface);
  transition: background var(--ml-transition);
}
groupexpandcontent--ml-reveal-overlay-glass .ml-reveal-trigger:not(.ml-disabled):hover {
  background: rgba(255, 255, 255, 0.16);
}
groupexpandcontent--ml-reveal-overlay-glass .ml-reveal-trigger:focus-visible {
  outline: none;
  box-shadow: 0 0 0 2px rgba(199, 210, 254, 0.6);
}
groupexpandcontent--ml-reveal-overlay-glass .ml-reveal-panel.ml-text-muted {
  border-radius: 10px;
  border: 1px solid var(--ml-outline-variant);
  background: rgba(255, 255, 255, 0.07);
  color: rgba(255, 255, 255, 0.7);
}
groupexpandcontent--ml-reveal-overlay-glass .ml-reveal-panel:has(> .ml-reveal-overlay) {
  border-radius: var(--ml-radius-sm);
  border: 1px solid var(--ml-outline-variant);
  background: rgba(255, 255, 255, 0.05);
  overflow: hidden;
}
groupexpandcontent--ml-reveal-overlay-glass .ml-reveal-panel.p-4 {
  color: rgba(255, 255, 255, 0.9);
}
groupexpandcontent--ml-reveal-overlay-glass .ml-reveal-overlay {
  border-radius: var(--ml-radius-sm);
  background: rgba(20, 18, 50, 0.45);
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
  transition: opacity 300ms ease;
}
groupexpandcontent--ml-reveal-overlay-glass .ml-reveal-close {
  border-radius: 10px;
  border: 1px solid rgba(255, 255, 255, 0.3);
  background: rgba(255, 255, 255, 0.14);
  backdrop-filter: blur(6px);
  -webkit-backdrop-filter: blur(6px);
  color: #fff;
  cursor: pointer;
  transition: background var(--ml-transition);
}
groupexpandcontent--ml-reveal-overlay-glass .ml-reveal-close:not(.ml-disabled):hover {
  background: rgba(255, 255, 255, 0.24);
}
groupexpandcontent--ml-reveal-overlay-glass .ml-disabled {
  opacity: var(--ml-disabled-opacity);
  cursor: not-allowed;
  pointer-events: none;
}
`);
    }
};
RevealOverlayGlass = __decorate([
    customElement('groupexpandcontent--ml-reveal-overlay-glass')
], RevealOverlayGlass);
export { RevealOverlayGlass };
