var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupexpandcontent/ml-collapsible-panel-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// COLLAPSIBLE PANEL — GLASSMORPHISM (mls-102055)
// =============================================================================
// Casca (estratégia D): herda tudo de MlCollapsiblePanelMolecule (mls-102040), inclusive render() — o markup base emite classes semânticas ml-*;
// a aparência glass vem do .less irmão, escopado sob esta tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlCollapsiblePanelMolecule } from '/_102040_/l2/molecules/groupexpandcontent/ml-collapsible-panel.js';
let MlCollapsiblePanelGlass = class MlCollapsiblePanelGlass extends MlCollapsiblePanelMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupexpandcontent--ml-collapsible-panel-glass {
  display: block;
  font-family: 'Inter', system-ui, sans-serif;
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-font-weight-medium: 600;
  --ml-radius-sm: 12px;
  --ml-disabled-opacity: 0.5;
}
groupexpandcontent--ml-collapsible-panel-glass .ml-label {
  font-family: var(--ml-font-family);
}
groupexpandcontent--ml-collapsible-panel-glass .ml-label.mb-2 {
  color: rgba(255, 255, 255, 0.85);
}
groupexpandcontent--ml-collapsible-panel-glass .ml-label:not(.mb-2) {
  color: #fff;
}
groupexpandcontent--ml-collapsible-panel-glass .ml-text-muted {
  color: rgba(255, 255, 255, 0.6);
}
groupexpandcontent--ml-collapsible-panel-glass .ml-text-muted.text-xs {
  color: rgba(255, 255, 255, 0.55);
}
groupexpandcontent--ml-collapsible-panel-glass .ml-panel-header.flex {
  background: transparent;
  border: 1px solid transparent;
  transition: background 150ms ease;
}
groupexpandcontent--ml-collapsible-panel-glass .ml-panel-header.flex.ml-panel-header-open {
  background: rgba(199, 210, 254, 0.14);
}
groupexpandcontent--ml-collapsible-panel-glass .ml-panel-header.flex:not(.ml-disabled):not(.ml-panel-header-open):hover {
  background: rgba(255, 255, 255, 0.08);
}
groupexpandcontent--ml-collapsible-panel-glass .ml-panel-header.flex:focus-visible {
  outline: none;
  box-shadow: 0 0 0 3px rgba(199, 210, 254, 0.4);
}
groupexpandcontent--ml-collapsible-panel-glass .ml-panel-header:not(.flex) {
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.15);
  overflow: hidden;
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  transition: border-color 0.2s ease;
}
groupexpandcontent--ml-collapsible-panel-glass .ml-panel-header:not(.flex):has(> .ml-panel-header-open) {
  border-color: rgba(199, 210, 254, 0.6);
}
groupexpandcontent--ml-collapsible-panel-glass .ml-panel-content {
  font-family: var(--ml-font-family);
  color: rgba(255, 255, 255, 0.8);
}
groupexpandcontent--ml-collapsible-panel-glass .ml-panel-chevron {
  color: rgba(255, 255, 255, 0.6);
}
groupexpandcontent--ml-collapsible-panel-glass .ml-skeleton {
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: var(--ml-radius-sm);
}
groupexpandcontent--ml-collapsible-panel-glass .ml-disabled {
  opacity: var(--ml-disabled-opacity);
  cursor: not-allowed;
  pointer-events: none;
}
`);
    }
};
MlCollapsiblePanelGlass = __decorate([
    customElement('groupexpandcontent--ml-collapsible-panel-glass')
], MlCollapsiblePanelGlass);
export { MlCollapsiblePanelGlass };
