var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupenterdatetime/ml-datetime-picker-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// DATETIME PICKER — GLASSMORPHISM (mls-102055)
// =============================================================================
// Skill Group: enter + datetime
// Casca (estratégia D): herda tudo de MlDatetimePickerMolecule (mls-102040),
// inclusive render() e getPortalTemplate() — o markup base emite classes ml-*;
// a aparência glass vem do .less irmão, escopado sob esta tag e sob o
// data-widget do portal.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlDatetimePickerMolecule } from '/_102040_/l2/molecules/groupenterdatetime/ml-datetime-picker.js';
let DatetimePickerGlass = class DatetimePickerGlass extends MlDatetimePickerMolecule {
    constructor() {
        super(...arguments);
        // O container do portal (document.body) recebe este data-widget — o .less do
        // tema escopa o painel por div[data-widget="...-glass"].
        this.portalWidgetName = 'groupenterdatetime--ml-datetime-picker-glass';
    }
};
DatetimePickerGlass = __decorate([
    customElement('groupenterdatetime--ml-datetime-picker-glass')
], DatetimePickerGlass);
export { DatetimePickerGlass };
