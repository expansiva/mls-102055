var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupenterdatetime/ml-datetime-picker-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// DATETIME PICKER — GLASSMORPHISM (mls-102055)
// =============================================================================
// Skill Group: enter + datetime
// Casca (estratégia D): herda tudo de MlDatetimePickerMolecule (mls-102040),
// inclusive render() e getPortalTemplate() — o markup base emite classes ml-*;
// a aparência glass vem do .less irmão, escopado sob esta tag e sob o
// data-widget do portal.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlDatetimePickerMolecule } from '/_102040_/l2/molecules/groupenterdatetime/ml-datetime-picker.js';
let DatetimePickerGlass = class DatetimePickerGlass extends MlDatetimePickerMolecule {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupenterdatetime--ml-datetime-picker-glass,
div[data-widget="groupenterdatetime--ml-datetime-picker-glass"] {
  display: block;
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-font-weight-medium: 500;
  --ml-on-surface: #ffffff;
  --ml-on-surface-muted: rgba(255, 255, 255, 0.45);
  --ml-error: #ffb4ab;
  --ml-primary: rgba(129, 140, 248, 0.85);
  --ml-on-primary: #ffffff;
  --ml-surface: rgba(255, 255, 255, 0.08);
  --ml-surface-dim: rgba(30, 27, 75, 0.85);
  --ml-border-width: 1px;
  --ml-outline-variant: rgba(255, 255, 255, 0.2);
  --ml-outline-focus: rgba(199, 210, 254, 0.9);
  --ml-outline-error: rgba(255, 120, 120, 0.7);
  --ml-radius-md: 10px;
  --ml-radius-lg: 14px;
  --ml-transition: 0.15s ease;
  --ml-focus-ring-width: 3px;
  --ml-focus-ring-color: rgba(199, 210, 254, 0.25);
  --ml-disabled-opacity: 0.5;
  --ml-backdrop-blur: 8px;
  --ml-backdrop-blur-strong: 18px;
}
groupenterdatetime--ml-datetime-picker-glass .ml-label,
div[data-widget="groupenterdatetime--ml-datetime-picker-glass"] .ml-label {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: rgba(255, 255, 255, 0.7);
}
groupenterdatetime--ml-datetime-picker-glass .ml-helper,
div[data-widget="groupenterdatetime--ml-datetime-picker-glass"] .ml-helper {
  color: rgba(255, 255, 255, 0.65);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupenterdatetime--ml-datetime-picker-glass .ml-error-text,
div[data-widget="groupenterdatetime--ml-datetime-picker-glass"] .ml-error-text {
  color: var(--ml-error, #ffb4ab);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupenterdatetime--ml-datetime-picker-glass .ml-text,
div[data-widget="groupenterdatetime--ml-datetime-picker-glass"] .ml-text {
  color: var(--ml-on-surface, #ffffff);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupenterdatetime--ml-datetime-picker-glass .ml-text-muted,
div[data-widget="groupenterdatetime--ml-datetime-picker-glass"] .ml-text-muted {
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.45));
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupenterdatetime--ml-datetime-picker-glass svg.ml-text-muted,
div[data-widget="groupenterdatetime--ml-datetime-picker-glass"] svg.ml-text-muted {
  color: rgba(255, 255, 255, 0.6);
}
groupenterdatetime--ml-datetime-picker-glass .ml-text-muted.grid-cols-7,
div[data-widget="groupenterdatetime--ml-datetime-picker-glass"] .ml-text-muted.grid-cols-7 {
  color: rgba(255, 255, 255, 0.5);
}
groupenterdatetime--ml-datetime-picker-glass .ml-disabled,
div[data-widget="groupenterdatetime--ml-datetime-picker-glass"] .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupenterdatetime--ml-datetime-picker-glass .ml-spinner,
div[data-widget="groupenterdatetime--ml-datetime-picker-glass"] .ml-spinner {
  border-color: rgba(255, 255, 255, 0.3);
  border-top-color: rgba(255, 255, 255, 0.9);
}
groupenterdatetime--ml-datetime-picker-glass .ml-input-container,
div[data-widget="groupenterdatetime--ml-datetime-picker-glass"] .ml-input-container {
  position: relative;
  background: var(--ml-surface, rgba(255, 255, 255, 0.08));
  border: var(--ml-border-width, 1px) solid var(--ml-outline-variant, rgba(255, 255, 255, 0.2));
  border-radius: var(--ml-radius-md, 10px);
  color: var(--ml-on-surface, #ffffff);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  backdrop-filter: blur(var(--ml-backdrop-blur, 8px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur, 8px));
  transition: border-color var(--ml-transition, 0.15s ease), box-shadow var(--ml-transition, 0.15s ease), background var(--ml-transition, 0.15s ease);
}
groupenterdatetime--ml-datetime-picker-glass .ml-input-container::before,
div[data-widget="groupenterdatetime--ml-datetime-picker-glass"] .ml-input-container::before {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  border-top: 1px solid rgba(255, 255, 255, 0.5);
  border-left: 1px solid rgba(255, 255, 255, 0.25);
  pointer-events: none;
}
groupenterdatetime--ml-datetime-picker-glass .ml-input-container-focused,
div[data-widget="groupenterdatetime--ml-datetime-picker-glass"] .ml-input-container-focused {
  border-color: var(--ml-outline-focus, rgba(199, 210, 254, 0.9));
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) var(--ml-focus-ring-color, rgba(199, 210, 254, 0.25));
}
groupenterdatetime--ml-datetime-picker-glass .ml-input-container-error,
div[data-widget="groupenterdatetime--ml-datetime-picker-glass"] .ml-input-container-error {
  border-color: var(--ml-outline-error, rgba(255, 120, 120, 0.7));
}
groupenterdatetime--ml-datetime-picker-glass .ml-calendar-container,
div[data-widget="groupenterdatetime--ml-datetime-picker-glass"] .ml-calendar-container {
  background: var(--ml-surface-dim, rgba(30, 27, 75, 0.85));
  border: var(--ml-border-width, 1px) solid rgba(255, 255, 255, 0.18);
  border-radius: var(--ml-radius-lg, 14px);
  box-shadow: 0 16px 40px rgba(0, 0, 0, 0.45);
  backdrop-filter: blur(var(--ml-backdrop-blur-strong, 18px));
  -webkit-backdrop-filter: blur(var(--ml-backdrop-blur-strong, 18px));
}
groupenterdatetime--ml-datetime-picker-glass .ml-calendar-nav,
div[data-widget="groupenterdatetime--ml-datetime-picker-glass"] .ml-calendar-nav {
  background: transparent;
  border: none;
  border-radius: 6px;
  color: rgba(255, 255, 255, 0.7);
  cursor: pointer;
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupenterdatetime--ml-datetime-picker-glass .ml-calendar-nav:hover,
div[data-widget="groupenterdatetime--ml-datetime-picker-glass"] .ml-calendar-nav:hover {
  background: rgba(255, 255, 255, 0.1);
  color: #ffffff;
}
groupenterdatetime--ml-datetime-picker-glass .ml-calendar-nav.rounded-md,
div[data-widget="groupenterdatetime--ml-datetime-picker-glass"] .ml-calendar-nav.rounded-md {
  border-radius: 8px;
}
groupenterdatetime--ml-datetime-picker-glass .ml-calendar-nav.rounded-md:hover,
div[data-widget="groupenterdatetime--ml-datetime-picker-glass"] .ml-calendar-nav.rounded-md:hover {
  background: transparent;
}
groupenterdatetime--ml-datetime-picker-glass .ml-calendar-day,
div[data-widget="groupenterdatetime--ml-datetime-picker-glass"] .ml-calendar-day {
  background: transparent;
  border-radius: 8px;
  color: rgba(255, 255, 255, 0.9);
  transition: background 0.12s ease, border-color 0.12s ease, color 0.12s ease;
}
groupenterdatetime--ml-datetime-picker-glass .ml-calendar-day--hoverable:hover,
div[data-widget="groupenterdatetime--ml-datetime-picker-glass"] .ml-calendar-day--hoverable:hover {
  background: rgba(255, 255, 255, 0.1);
}
groupenterdatetime--ml-datetime-picker-glass .ml-calendar-day-today,
div[data-widget="groupenterdatetime--ml-datetime-picker-glass"] .ml-calendar-day-today {
  border-color: rgba(199, 210, 254, 0.6);
}
groupenterdatetime--ml-datetime-picker-glass .ml-calendar-day-selected,
div[data-widget="groupenterdatetime--ml-datetime-picker-glass"] .ml-calendar-day-selected {
  background: rgba(199, 210, 254, 0.2);
  border-color: rgba(199, 210, 254, 0.9);
  color: #e0e7ff;
}
groupenterdatetime--ml-datetime-picker-glass .ml-calendar-day-disabled,
div[data-widget="groupenterdatetime--ml-datetime-picker-glass"] .ml-calendar-day-disabled {
  opacity: 0.4;
  cursor: not-allowed;
}
groupenterdatetime--ml-datetime-picker-glass .ml-calendar-time-btn,
div[data-widget="groupenterdatetime--ml-datetime-picker-glass"] .ml-calendar-time-btn {
  background: transparent;
  border-radius: 8px;
  color: rgba(255, 255, 255, 0.9);
  transition: background 0.12s ease, border-color 0.12s ease, color 0.12s ease;
}
groupenterdatetime--ml-datetime-picker-glass .ml-calendar-time-btn--hoverable:hover,
div[data-widget="groupenterdatetime--ml-datetime-picker-glass"] .ml-calendar-time-btn--hoverable:hover {
  background: rgba(255, 255, 255, 0.1);
}
groupenterdatetime--ml-datetime-picker-glass .ml-calendar-time-btn-selected,
div[data-widget="groupenterdatetime--ml-datetime-picker-glass"] .ml-calendar-time-btn-selected {
  background: rgba(199, 210, 254, 0.2);
  border-color: rgba(199, 210, 254, 0.9);
  color: #e0e7ff;
}
groupenterdatetime--ml-datetime-picker-glass .ml-calendar-time-btn.ml-disabled,
div[data-widget="groupenterdatetime--ml-datetime-picker-glass"] .ml-calendar-time-btn.ml-disabled {
  opacity: 0.4;
}
groupenterdatetime--ml-datetime-picker-glass .ml-calendar-confirm,
div[data-widget="groupenterdatetime--ml-datetime-picker-glass"] .ml-calendar-confirm {
  background: var(--ml-primary, rgba(129, 140, 248, 0.85));
  border: 1px solid rgba(199, 210, 254, 0.6);
  border-radius: 8px;
  color: var(--ml-on-primary, #ffffff);
  cursor: pointer;
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  transition: background 0.12s ease;
}
groupenterdatetime--ml-datetime-picker-glass .ml-calendar-confirm:hover,
div[data-widget="groupenterdatetime--ml-datetime-picker-glass"] .ml-calendar-confirm:hover {
  background: #818cf8;
}
`);
        // O container do portal (document.body) recebe este data-widget — o .less do
        // tema escopa o painel por div[data-widget="...-glass"].
        this.portalWidgetName = 'groupenterdatetime--ml-datetime-picker-glass';
    }
};
DatetimePickerGlass = __decorate([
    customElement('groupenterdatetime--ml-datetime-picker-glass')
], DatetimePickerGlass);
export { DatetimePickerGlass };
