var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102055_/l2/molecules/groupenternumberinterval/ml-number-range-slider-glass.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// NUMBER RANGE SLIDER — GLASSMORPHISM (mls-102055)
// =============================================================================
// Skill Group: groupEnterNumberInterval
// Shell (Strategy D): inherits everything from MlNumberRangeSliderMolecule (mls-102040),
// including render() — the base markup emits semantic ml-* classes; the appearance
// comes from the sibling .less, scoped under this tag.
// This molecule does NOT contain business logic.
import { customElement } from 'lit/decorators.js';
import { MlNumberRangeSliderMolecule } from '/_102040_/l2/molecules/groupenternumberinterval/ml-number-range-slider.js';
let MlNumberRangeSliderMoleculeGlass = class MlNumberRangeSliderMoleculeGlass extends MlNumberRangeSliderMolecule {
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupenternumberinterval--ml-number-range-slider-glass {
  display: block;
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
  --ml-font-family: 'Inter', system-ui, sans-serif;
  --ml-font-weight-medium: 600;
  --ml-radius-sm: 12px;
  --ml-radius-md: 12px;
  --ml-radius-lg: 14px;
  --ml-border-width: 1px;
  --ml-outline-variant: rgba(255, 255, 255, 0.25);
  --ml-outline-focus: rgba(199, 210, 254, 0.9);
  --ml-outline-error: rgba(255, 120, 120, 0.85);
  --ml-primary: rgba(99, 102, 241, 0.55);
  --ml-surface: rgba(255, 255, 255, 0.1);
  --ml-surface-dim: rgba(30, 27, 75, 0.55);
  --ml-on-surface: rgba(255, 255, 255, 0.95);
  --ml-on-surface-muted: rgba(255, 255, 255, 0.55);
  --ml-error: #ffb4ab;
  --ml-shadow-1: 0 4px 18px rgba(0, 0, 0, 0.18);
  --ml-shadow-2: 0 6px 24px rgba(0, 0, 0, 0.26);
  --ml-transition: 250ms ease;
  --ml-focus-ring-width: 3px;
  --ml-focus-ring-color: rgba(255, 255, 255, 0.5);
  --ml-disabled-opacity: 0.5;
}
groupenternumberinterval--ml-number-range-slider-glass .ml-nrs-root {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupenternumberinterval--ml-number-range-slider-glass .ml-nrs-view {
  cursor: default;
}
groupenternumberinterval--ml-number-range-slider-glass .ml-nrs-loading {
  cursor: wait;
}
groupenternumberinterval--ml-number-range-slider-glass .ml-nrs-readonly .ml-nrs-track-area,
groupenternumberinterval--ml-number-range-slider-glass .ml-nrs-readonly .ml-nrs-handle {
  cursor: default;
}
groupenternumberinterval--ml-number-range-slider-glass .ml-nrs-error .ml-nrs-track-fill {
  background: var(--ml-error, #ffb4ab);
}
groupenternumberinterval--ml-number-range-slider-glass .ml-nrs-error .ml-nrs-handle-knob {
  background: var(--ml-error, #ffb4ab);
}
groupenternumberinterval--ml-number-range-slider-glass .ml-nrs-error .ml-nrs-handle-focused .ml-nrs-handle-knob {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) var(--ml-outline-error, rgba(255, 120, 120, 0.85));
}
groupenternumberinterval--ml-number-range-slider-glass .ml-nrs-track-area {
  touch-action: pan-y;
  user-select: none;
}
groupenternumberinterval--ml-number-range-slider-glass .ml-nrs-track {
  height: var(--ml-nrs-handle-size, 20px);
}
groupenternumberinterval--ml-number-range-slider-glass .ml-nrs-track-base {
  position: absolute;
  top: 50%;
  left: 0;
  right: 0;
  height: var(--ml-nrs-track-height, 6px);
  transform: translateY(-50%);
  background: var(--ml-surface-dim, rgba(30, 27, 75, 0.55));
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, rgba(255, 255, 255, 0.25));
  border-radius: var(--ml-radius-full, 9999px);
}
groupenternumberinterval--ml-number-range-slider-glass .ml-nrs-track-fill {
  position: absolute;
  top: 50%;
  height: var(--ml-nrs-track-height, 6px);
  transform: translateY(-50%);
  background: var(--ml-primary, rgba(99, 102, 241, 0.55));
  border-radius: var(--ml-radius-full, 9999px);
}
groupenternumberinterval--ml-number-range-slider-glass .ml-nrs-handle {
  width: var(--ml-nrs-handle-size, 20px);
  height: var(--ml-nrs-handle-size, 20px);
  touch-action: none;
  user-select: none;
  outline: none;
  -webkit-tap-highlight-color: transparent;
}
groupenternumberinterval--ml-number-range-slider-glass .ml-nrs-handle-start {
  z-index: 1;
}
groupenternumberinterval--ml-number-range-slider-glass .ml-nrs-handle-end {
  z-index: 1;
}
groupenternumberinterval--ml-number-range-slider-glass .ml-nrs-handle-active {
  z-index: 2;
}
groupenternumberinterval--ml-number-range-slider-glass .ml-nrs-handle-active .ml-nrs-handle-knob {
  transform: scale(var(--ml-nrs-knob-active-scale, 1.15));
}
groupenternumberinterval--ml-number-range-slider-glass .ml-nrs-handle-focused {
  z-index: 2;
}
groupenternumberinterval--ml-number-range-slider-glass .ml-nrs-handle-focused .ml-nrs-handle-knob {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 3px) var(--ml-focus-ring-color, rgba(255, 255, 255, 0.5)), var(--ml-shadow-1, 0 4px 18px rgba(0, 0, 0, 0.18));
}
groupenternumberinterval--ml-number-range-slider-glass .ml-nrs-handle-knob {
  width: var(--ml-nrs-knob-size, 16px);
  height: var(--ml-nrs-knob-size, 16px);
  background: var(--ml-primary, rgba(99, 102, 241, 0.55));
  border: var(--ml-nrs-knob-border-width, 2px) var(--ml-border-style, solid) var(--ml-surface, rgba(255, 255, 255, 0.1));
  border-radius: var(--ml-radius-full, 9999px);
  box-shadow: var(--ml-shadow-1, 0 4px 18px rgba(0, 0, 0, 0.18));
  transition: transform var(--ml-transition, 250ms ease), box-shadow var(--ml-transition, 250ms ease), background-color var(--ml-transition, 250ms ease);
}
groupenternumberinterval--ml-number-range-slider-glass .ml-nrs-tooltip {
  position: absolute;
  bottom: calc(100% + var(--ml-nrs-tooltip-offset, 6px));
  left: 50%;
  transform: translateX(-50%);
  padding: var(--ml-nrs-tooltip-padding, 2px 6px);
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  font-size: var(--ml-nrs-tooltip-font-size, 12px);
  line-height: var(--ml-nrs-tooltip-line-height, 1.4);
  white-space: nowrap;
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
  background: var(--ml-surface-dim, rgba(30, 27, 75, 0.55));
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, rgba(255, 255, 255, 0.25));
  border-radius: var(--ml-radius-lg, 14px);
  box-shadow: 0 16px 44px rgba(0, 0, 0, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.35);
  pointer-events: none;
  z-index: 3;
}
groupenternumberinterval--ml-number-range-slider-glass .ml-nrs-readout {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupenternumberinterval--ml-number-range-slider-glass .ml-nrs-placeholder {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
}
groupenternumberinterval--ml-number-range-slider-glass .ml-nrs-view-value {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
}
groupenternumberinterval--ml-number-range-slider-glass .ml-nrs-loading-block {
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.55));
}
groupenternumberinterval--ml-number-range-slider-glass .ml-nrs-skeleton-track {
  height: var(--ml-nrs-track-height, 6px);
  border-radius: var(--ml-radius-full, 9999px);
}
groupenternumberinterval--ml-number-range-slider-glass .ml-label {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  font-weight: var(--ml-font-weight-medium, 600);
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
}
groupenternumberinterval--ml-number-range-slider-glass .ml-helper {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.55));
}
groupenternumberinterval--ml-number-range-slider-glass .ml-error-text {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  color: var(--ml-error, #ffb4ab);
}
groupenternumberinterval--ml-number-range-slider-glass .ml-text {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  color: var(--ml-on-surface, rgba(255, 255, 255, 0.95));
}
groupenternumberinterval--ml-number-range-slider-glass .ml-text-muted {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.55));
}
groupenternumberinterval--ml-number-range-slider-glass .ml-text-faint {
  font-family: var(--ml-font-family, 'Inter', system-ui, sans-serif);
  color: var(--ml-on-surface-muted, rgba(255, 255, 255, 0.55));
}
groupenternumberinterval--ml-number-range-slider-glass .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupenternumberinterval--ml-number-range-slider-glass .ml-spinner {
  display: inline-block;
  width: var(--ml-spinner-size, 16px);
  height: var(--ml-spinner-size, 16px);
  border: var(--ml-spinner-border-width, 2px) var(--ml-border-style, solid) var(--ml-outline-variant, rgba(255, 255, 255, 0.25));
  border-top-color: var(--ml-primary, rgba(99, 102, 241, 0.55));
  border-radius: var(--ml-radius-full, 9999px);
  animation: ml-nrs-spin var(--ml-spinner-duration, 0.8s) linear infinite;
}
groupenternumberinterval--ml-number-range-slider-glass .ml-skeleton {
  background: linear-gradient(90deg, var(--ml-surface-dim, rgba(30, 27, 75, 0.55)) 25%, var(--ml-outline-variant, rgba(255, 255, 255, 0.25)) 50%, var(--ml-surface-dim, rgba(30, 27, 75, 0.55)) 75%);
  background-size: 200% 100%;
  border-radius: var(--ml-radius-sm, 12px);
  animation: ml-nrs-skeleton-shimmer var(--ml-skeleton-duration, 1.5s) ease infinite;
}
@keyframes ml-nrs-spin {
  to {
    transform: rotate(360deg);
  }
}
@keyframes ml-nrs-skeleton-shimmer {
  0% {
    background-position: 200% 0;
  }
  100% {
    background-position: -200% 0;
  }
}
`);
    }
};
MlNumberRangeSliderMoleculeGlass = __decorate([
    customElement('groupenternumberinterval--ml-number-range-slider-glass')
], MlNumberRangeSliderMoleculeGlass);
export { MlNumberRangeSliderMoleculeGlass };
